-- MySQL dump 10.13  Distrib 8.0.16, for macos10.14 (x86_64)
--
-- Host: localhost    Database: local
-- ------------------------------------------------------
-- Server version	8.0.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8mb4 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `wp_commentmeta`
--

DROP TABLE IF EXISTS `wp_commentmeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_commentmeta`
--

LOCK TABLES `wp_commentmeta` WRITE;
/*!40000 ALTER TABLE `wp_commentmeta` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_commentmeta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_comments`
--

DROP TABLE IF EXISTS `wp_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'comment',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_comments`
--

LOCK TABLES `wp_comments` WRITE;
/*!40000 ALTER TABLE `wp_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_gf_draft_submissions`
--

DROP TABLE IF EXISTS `wp_gf_draft_submissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `wp_gf_draft_submissions` (
  `uuid` char(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `form_id` mediumint(8) unsigned NOT NULL,
  `date_created` datetime NOT NULL,
  `ip` varchar(39) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `source_url` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `submission` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`uuid`),
  KEY `form_id` (`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_gf_draft_submissions`
--

LOCK TABLES `wp_gf_draft_submissions` WRITE;
/*!40000 ALTER TABLE `wp_gf_draft_submissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_gf_draft_submissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_gf_entry`
--

DROP TABLE IF EXISTS `wp_gf_entry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `wp_gf_entry` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL,
  `post_id` bigint(20) unsigned DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` datetime DEFAULT NULL,
  `is_starred` tinyint(1) NOT NULL DEFAULT '0',
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  `ip` varchar(39) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `source_url` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_agent` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `currency` varchar(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `payment_status` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `payment_date` datetime DEFAULT NULL,
  `payment_amount` decimal(19,2) DEFAULT NULL,
  `payment_method` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `transaction_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `is_fulfilled` tinyint(1) DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `transaction_type` tinyint(1) DEFAULT NULL,
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'active',
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`),
  KEY `form_id_status` (`form_id`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_gf_entry`
--

LOCK TABLES `wp_gf_entry` WRITE;
/*!40000 ALTER TABLE `wp_gf_entry` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_gf_entry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_gf_entry_meta`
--

DROP TABLE IF EXISTS `wp_gf_entry_meta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `wp_gf_entry_meta` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `entry_id` bigint(20) unsigned NOT NULL,
  `meta_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `item_index` varchar(60) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `meta_key` (`meta_key`(191)),
  KEY `entry_id` (`entry_id`),
  KEY `meta_value` (`meta_value`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_gf_entry_meta`
--

LOCK TABLES `wp_gf_entry_meta` WRITE;
/*!40000 ALTER TABLE `wp_gf_entry_meta` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_gf_entry_meta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_gf_entry_notes`
--

DROP TABLE IF EXISTS `wp_gf_entry_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `wp_gf_entry_notes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `entry_id` int(10) unsigned NOT NULL,
  `user_name` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `note_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `sub_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `entry_id` (`entry_id`),
  KEY `entry_user_key` (`entry_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_gf_entry_notes`
--

LOCK TABLES `wp_gf_entry_notes` WRITE;
/*!40000 ALTER TABLE `wp_gf_entry_notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_gf_entry_notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_gf_form`
--

DROP TABLE IF EXISTS `wp_gf_form`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `wp_gf_form` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` datetime DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_trash` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_gf_form`
--

LOCK TABLES `wp_gf_form` WRITE;
/*!40000 ALTER TABLE `wp_gf_form` DISABLE KEYS */;
INSERT INTO `wp_gf_form` VALUES (1,'Newsletter Signup','2020-05-27 23:05:05',NULL,1,0);
INSERT INTO `wp_gf_form` VALUES (2,'Contact','2020-05-27 23:05:05',NULL,1,0);
/*!40000 ALTER TABLE `wp_gf_form` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_gf_form_meta`
--

DROP TABLE IF EXISTS `wp_gf_form_meta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `wp_gf_form_meta` (
  `form_id` mediumint(8) unsigned NOT NULL,
  `display_meta` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `entries_grid_meta` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `confirmations` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `notifications` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_gf_form_meta`
--

LOCK TABLES `wp_gf_form_meta` WRITE;
/*!40000 ALTER TABLE `wp_gf_form_meta` DISABLE KEYS */;
INSERT INTO `wp_gf_form_meta` VALUES (1,'{\"title\":\"Newsletter Signup\",\"description\":\"\",\"labelPlacement\":\"top_label\",\"descriptionPlacement\":\"below\",\"button\":{\"type\":\"text\",\"text\":\"Subscribe\",\"imageUrl\":\"\"},\"fields\":[{\"type\":\"email\",\"id\":1,\"label\":\"Email Address\",\"adminLabel\":\"\",\"isRequired\":true,\"size\":\"medium\",\"errorMessage\":\"\",\"visibility\":\"visible\",\"inputs\":null,\"formId\":1,\"description\":\"\",\"allowsPrepopulate\":false,\"inputMask\":false,\"inputMaskValue\":\"\",\"inputMaskIsCustom\":false,\"maxLength\":\"\",\"inputType\":\"\",\"labelPlacement\":\"\",\"descriptionPlacement\":\"\",\"subLabelPlacement\":\"\",\"placeholder\":\"\",\"cssClass\":\"animated\",\"inputName\":\"\",\"noDuplicates\":false,\"defaultValue\":\"\",\"choices\":\"\",\"conditionalLogic\":\"\",\"productField\":\"\",\"emailConfirmEnabled\":\"\",\"multipleFiles\":false,\"maxFiles\":\"\",\"calculationFormula\":\"\",\"calculationRounding\":\"\",\"enableCalculation\":\"\",\"disableQuantity\":false,\"displayAllCategories\":false,\"useRichTextEditor\":false,\"fields\":\"\",\"displayOnly\":\"\",\"pageNumber\":1}],\"version\":\"2.4.18\",\"id\":1,\"nextFieldId\":2,\"useCurrentUserAsAuthor\":true,\"postContentTemplateEnabled\":false,\"postTitleTemplateEnabled\":false,\"postTitleTemplate\":\"\",\"postContentTemplate\":\"\",\"lastPageButton\":null,\"pagination\":null,\"firstPageCssClass\":null,\"subLabelPlacement\":\"below\",\"cssClass\":\"\",\"enableHoneypot\":false,\"enableAnimation\":false,\"save\":{\"enabled\":false,\"button\":{\"type\":\"link\",\"text\":\"Save and Continue Later\"}},\"limitEntries\":false,\"limitEntriesCount\":\"\",\"limitEntriesPeriod\":\"\",\"limitEntriesMessage\":\"\",\"scheduleForm\":false,\"scheduleStart\":\"\",\"scheduleStartHour\":\"\",\"scheduleStartMinute\":\"\",\"scheduleStartAmpm\":\"\",\"scheduleEnd\":\"\",\"scheduleEndHour\":\"\",\"scheduleEndMinute\":\"\",\"scheduleEndAmpm\":\"\",\"schedulePendingMessage\":\"\",\"scheduleMessage\":\"\",\"requireLogin\":false,\"requireLoginMessage\":\"\"}',NULL,'{\"5ecede9e56ea6\":{\"id\":\"5ecede9e56ea6\",\"name\":\"Default Confirmation\",\"isDefault\":true,\"type\":\"message\",\"message\":\"Thanks for contacting us! We will get in touch with you shortly.\",\"url\":\"\",\"pageId\":\"\",\"queryString\":\"\"}}','{\"5ecede9e56b93\":{\"id\":\"5ecede9e56b93\",\"isActive\":true,\"to\":\"{admin_email}\",\"name\":\"Admin Notification\",\"event\":\"form_submission\",\"toType\":\"email\",\"subject\":\"New submission from {form_title}\",\"message\":\"{all_fields}\"}}');
INSERT INTO `wp_gf_form_meta` VALUES (2,'{\"title\":\"Contact\",\"description\":\"\",\"labelPlacement\":\"top_label\",\"descriptionPlacement\":\"below\",\"button\":{\"type\":\"text\",\"text\":\"Submit\",\"imageUrl\":\"\"},\"fields\":[{\"type\":\"text\",\"id\":1,\"label\":\"First Name\",\"adminLabel\":\"\",\"isRequired\":true,\"size\":\"medium\",\"errorMessage\":\"\",\"visibility\":\"visible\",\"inputs\":null,\"formId\":2,\"description\":\"\",\"allowsPrepopulate\":false,\"inputMask\":false,\"inputMaskValue\":\"\",\"inputMaskIsCustom\":false,\"maxLength\":\"\",\"inputType\":\"\",\"labelPlacement\":\"\",\"descriptionPlacement\":\"\",\"subLabelPlacement\":\"\",\"placeholder\":\"\",\"cssClass\":\"half-width animated\",\"inputName\":\"\",\"noDuplicates\":false,\"defaultValue\":\"\",\"choices\":\"\",\"conditionalLogic\":\"\",\"productField\":\"\",\"enablePasswordInput\":\"\",\"multipleFiles\":false,\"maxFiles\":\"\",\"calculationFormula\":\"\",\"calculationRounding\":\"\",\"enableCalculation\":\"\",\"disableQuantity\":false,\"displayAllCategories\":false,\"useRichTextEditor\":false,\"fields\":\"\",\"pageNumber\":1},{\"type\":\"text\",\"id\":2,\"label\":\"Last Name\",\"adminLabel\":\"\",\"isRequired\":true,\"size\":\"medium\",\"errorMessage\":\"\",\"visibility\":\"visible\",\"inputs\":null,\"formId\":2,\"description\":\"\",\"allowsPrepopulate\":false,\"inputMask\":false,\"inputMaskValue\":\"\",\"inputMaskIsCustom\":false,\"maxLength\":\"\",\"inputType\":\"\",\"labelPlacement\":\"\",\"descriptionPlacement\":\"\",\"subLabelPlacement\":\"\",\"placeholder\":\"\",\"cssClass\":\"half-width animated\",\"inputName\":\"\",\"noDuplicates\":false,\"defaultValue\":\"\",\"choices\":\"\",\"conditionalLogic\":\"\",\"productField\":\"\",\"enablePasswordInput\":\"\",\"multipleFiles\":false,\"maxFiles\":\"\",\"calculationFormula\":\"\",\"calculationRounding\":\"\",\"enableCalculation\":\"\",\"disableQuantity\":false,\"displayAllCategories\":false,\"useRichTextEditor\":false,\"fields\":\"\",\"pageNumber\":1},{\"type\":\"email\",\"id\":3,\"label\":\"Email\",\"adminLabel\":\"\",\"isRequired\":true,\"size\":\"medium\",\"errorMessage\":\"\",\"visibility\":\"visible\",\"inputs\":null,\"formId\":2,\"description\":\"\",\"allowsPrepopulate\":false,\"inputMask\":false,\"inputMaskValue\":\"\",\"inputMaskIsCustom\":false,\"maxLength\":\"\",\"inputType\":\"\",\"labelPlacement\":\"\",\"descriptionPlacement\":\"\",\"subLabelPlacement\":\"\",\"placeholder\":\"\",\"cssClass\":\"half-width animated\",\"inputName\":\"\",\"noDuplicates\":false,\"defaultValue\":\"\",\"choices\":\"\",\"conditionalLogic\":\"\",\"productField\":\"\",\"emailConfirmEnabled\":\"\",\"multipleFiles\":false,\"maxFiles\":\"\",\"calculationFormula\":\"\",\"calculationRounding\":\"\",\"enableCalculation\":\"\",\"disableQuantity\":false,\"displayAllCategories\":false,\"useRichTextEditor\":false,\"fields\":\"\",\"pageNumber\":1},{\"type\":\"phone\",\"id\":4,\"label\":\"Phone\",\"adminLabel\":\"\",\"isRequired\":false,\"size\":\"medium\",\"errorMessage\":\"\",\"visibility\":\"visible\",\"inputs\":null,\"phoneFormat\":\"standard\",\"formId\":2,\"description\":\"\",\"allowsPrepopulate\":false,\"inputMask\":false,\"inputMaskValue\":\"\",\"inputMaskIsCustom\":false,\"maxLength\":\"\",\"inputType\":\"\",\"labelPlacement\":\"\",\"descriptionPlacement\":\"\",\"subLabelPlacement\":\"\",\"placeholder\":\"\",\"cssClass\":\"half-width animated\",\"inputName\":\"\",\"noDuplicates\":false,\"defaultValue\":\"\",\"choices\":\"\",\"conditionalLogic\":\"\",\"productField\":\"\",\"multipleFiles\":false,\"maxFiles\":\"\",\"calculationFormula\":\"\",\"calculationRounding\":\"\",\"enableCalculation\":\"\",\"disableQuantity\":false,\"displayAllCategories\":false,\"useRichTextEditor\":false,\"fields\":\"\",\"pageNumber\":1},{\"type\":\"select\",\"id\":5,\"label\":\"Subject\",\"adminLabel\":\"\",\"isRequired\":false,\"size\":\"medium\",\"errorMessage\":\"\",\"visibility\":\"visible\",\"inputs\":null,\"choices\":[{\"text\":\"\",\"value\":\"\",\"isSelected\":false,\"price\":\"\"},{\"text\":\"First Choice\",\"value\":\"First Choice\",\"isSelected\":false,\"price\":\"\"},{\"text\":\"Second Choice\",\"value\":\"Second Choice\",\"isSelected\":false,\"price\":\"\"},{\"text\":\"Third Choice\",\"value\":\"Third Choice\",\"isSelected\":false,\"price\":\"\"}],\"formId\":2,\"description\":\"\",\"allowsPrepopulate\":false,\"inputMask\":false,\"inputMaskValue\":\"\",\"inputMaskIsCustom\":false,\"maxLength\":\"\",\"inputType\":\"\",\"labelPlacement\":\"\",\"descriptionPlacement\":\"\",\"subLabelPlacement\":\"\",\"placeholder\":\"\",\"cssClass\":\"half-width animated\",\"inputName\":\"\",\"noDuplicates\":false,\"defaultValue\":\"\",\"conditionalLogic\":\"\",\"productField\":\"\",\"enablePrice\":\"\",\"multipleFiles\":false,\"maxFiles\":\"\",\"calculationFormula\":\"\",\"calculationRounding\":\"\",\"enableCalculation\":\"\",\"disableQuantity\":false,\"displayAllCategories\":false,\"useRichTextEditor\":false,\"fields\":\"\",\"pageNumber\":1},{\"type\":\"checkbox\",\"id\":6,\"label\":\"Untitled\",\"adminLabel\":\"\",\"isRequired\":false,\"size\":\"medium\",\"errorMessage\":\"\",\"visibility\":\"visible\",\"choices\":[{\"text\":\"First Choice\",\"value\":\"First Choice\",\"isSelected\":false,\"price\":\"\"},{\"text\":\"Second Choice\",\"value\":\"Second Choice\",\"isSelected\":false,\"price\":\"\"},{\"text\":\"Third Choice\",\"value\":\"Third Choice\",\"isSelected\":false,\"price\":\"\"}],\"inputs\":[{\"id\":\"6.1\",\"label\":\"First Choice\",\"name\":\"\"},{\"id\":\"6.2\",\"label\":\"Second Choice\",\"name\":\"\"},{\"id\":\"6.3\",\"label\":\"Third Choice\",\"name\":\"\"}],\"formId\":2,\"description\":\"\",\"allowsPrepopulate\":false,\"inputMask\":false,\"inputMaskValue\":\"\",\"inputMaskIsCustom\":\"\",\"maxLength\":\"\",\"inputType\":\"\",\"labelPlacement\":\"\",\"descriptionPlacement\":\"\",\"subLabelPlacement\":\"\",\"placeholder\":\"\",\"cssClass\":\"\",\"inputName\":\"\",\"noDuplicates\":false,\"defaultValue\":\"\",\"conditionalLogic\":\"\",\"productField\":\"\",\"enableSelectAll\":\"\",\"enablePrice\":\"\",\"fields\":\"\",\"pageNumber\":1},{\"type\":\"radio\",\"id\":7,\"label\":\"Untitled\",\"adminLabel\":\"\",\"isRequired\":false,\"size\":\"medium\",\"errorMessage\":\"\",\"visibility\":\"visible\",\"inputs\":null,\"choices\":[{\"text\":\"First Choice\",\"value\":\"First Choice\",\"isSelected\":false,\"price\":\"\"},{\"text\":\"Second Choice\",\"value\":\"Second Choice\",\"isSelected\":false,\"price\":\"\"},{\"text\":\"Third Choice\",\"value\":\"Third Choice\",\"isSelected\":false,\"price\":\"\"}],\"formId\":2,\"description\":\"\",\"allowsPrepopulate\":false,\"inputMask\":false,\"inputMaskValue\":\"\",\"inputMaskIsCustom\":\"\",\"maxLength\":\"\",\"inputType\":\"\",\"labelPlacement\":\"\",\"descriptionPlacement\":\"\",\"subLabelPlacement\":\"\",\"placeholder\":\"\",\"cssClass\":\"\",\"inputName\":\"\",\"noDuplicates\":false,\"defaultValue\":\"\",\"conditionalLogic\":\"\",\"productField\":\"\",\"enableOtherChoice\":\"\",\"enablePrice\":\"\",\"fields\":\"\",\"pageNumber\":1},{\"type\":\"textarea\",\"id\":8,\"label\":\"Message\",\"adminLabel\":\"\",\"isRequired\":true,\"size\":\"medium\",\"errorMessage\":\"\",\"visibility\":\"visible\",\"inputs\":null,\"formId\":2,\"description\":\"\",\"allowsPrepopulate\":false,\"inputMask\":false,\"inputMaskValue\":\"\",\"inputMaskIsCustom\":false,\"maxLength\":\"\",\"inputType\":\"\",\"labelPlacement\":\"\",\"descriptionPlacement\":\"\",\"subLabelPlacement\":\"\",\"placeholder\":\"\",\"cssClass\":\"animated\",\"inputName\":\"\",\"noDuplicates\":false,\"defaultValue\":\"\",\"choices\":\"\",\"conditionalLogic\":\"\",\"productField\":\"\",\"form_id\":\"\",\"useRichTextEditor\":false,\"multipleFiles\":false,\"maxFiles\":\"\",\"calculationFormula\":\"\",\"calculationRounding\":\"\",\"enableCalculation\":\"\",\"disableQuantity\":false,\"displayAllCategories\":false,\"fields\":\"\",\"pageNumber\":1}],\"version\":\"2.4.18\",\"id\":2,\"nextFieldId\":9,\"useCurrentUserAsAuthor\":true,\"postContentTemplateEnabled\":false,\"postTitleTemplateEnabled\":false,\"postTitleTemplate\":\"\",\"postContentTemplate\":\"\",\"lastPageButton\":null,\"pagination\":null,\"firstPageCssClass\":null}',NULL,'{\"5ecee34b59cdc\":{\"id\":\"5ecee34b59cdc\",\"name\":\"Default Confirmation\",\"isDefault\":true,\"type\":\"message\",\"message\":\"Thanks for contacting us! We will get in touch with you shortly.\",\"url\":\"\",\"pageId\":\"\",\"queryString\":\"\"}}','{\"5ecee34b58ebe\":{\"id\":\"5ecee34b58ebe\",\"isActive\":true,\"to\":\"{admin_email}\",\"name\":\"Admin Notification\",\"event\":\"form_submission\",\"toType\":\"email\",\"subject\":\"New submission from {form_title}\",\"message\":\"{all_fields}\"}}');
/*!40000 ALTER TABLE `wp_gf_form_meta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_gf_form_revisions`
--

DROP TABLE IF EXISTS `wp_gf_form_revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `wp_gf_form_revisions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL,
  `display_meta` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `date_created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `date_created` (`date_created`),
  KEY `form_id` (`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_gf_form_revisions`
--

LOCK TABLES `wp_gf_form_revisions` WRITE;
/*!40000 ALTER TABLE `wp_gf_form_revisions` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_gf_form_revisions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_gf_form_view`
--

DROP TABLE IF EXISTS `wp_gf_form_view`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `wp_gf_form_view` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL,
  `date_created` datetime NOT NULL,
  `ip` char(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `count` mediumint(8) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `date_created` (`date_created`),
  KEY `form_id` (`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_gf_form_view`
--

LOCK TABLES `wp_gf_form_view` WRITE;
/*!40000 ALTER TABLE `wp_gf_form_view` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_gf_form_view` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_links`
--

DROP TABLE IF EXISTS `wp_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_links`
--

LOCK TABLES `wp_links` WRITE;
/*!40000 ALTER TABLE `wp_links` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_options`
--

DROP TABLE IF EXISTS `wp_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`),
  KEY `autoload` (`autoload`)
) ENGINE=InnoDB AUTO_INCREMENT=1017 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_options`
--

LOCK TABLES `wp_options` WRITE;
/*!40000 ALTER TABLE `wp_options` DISABLE KEYS */;
INSERT INTO `wp_options` VALUES (1,'siteurl','http://localhost:10008','yes');
INSERT INTO `wp_options` VALUES (2,'home','http://localhost:10008','yes');
INSERT INTO `wp_options` VALUES (3,'blogname','Site Name','yes');
INSERT INTO `wp_options` VALUES (4,'blogdescription','','yes');
INSERT INTO `wp_options` VALUES (5,'users_can_register','0','yes');
INSERT INTO `wp_options` VALUES (6,'admin_email','development@factor1studios.com','yes');
INSERT INTO `wp_options` VALUES (7,'start_of_week','1','yes');
INSERT INTO `wp_options` VALUES (8,'use_balanceTags','0','yes');
INSERT INTO `wp_options` VALUES (9,'use_smilies','1','yes');
INSERT INTO `wp_options` VALUES (10,'require_name_email','1','yes');
INSERT INTO `wp_options` VALUES (11,'comments_notify','1','yes');
INSERT INTO `wp_options` VALUES (12,'posts_per_rss','10','yes');
INSERT INTO `wp_options` VALUES (13,'rss_use_excerpt','0','yes');
INSERT INTO `wp_options` VALUES (14,'mailserver_url','mail.example.com','yes');
INSERT INTO `wp_options` VALUES (15,'mailserver_login','login@example.com','yes');
INSERT INTO `wp_options` VALUES (16,'mailserver_pass','password','yes');
INSERT INTO `wp_options` VALUES (17,'mailserver_port','110','yes');
INSERT INTO `wp_options` VALUES (18,'default_category','1','yes');
INSERT INTO `wp_options` VALUES (19,'default_comment_status','open','yes');
INSERT INTO `wp_options` VALUES (20,'default_ping_status','open','yes');
INSERT INTO `wp_options` VALUES (21,'default_pingback_flag','1','yes');
INSERT INTO `wp_options` VALUES (22,'posts_per_page','10','yes');
INSERT INTO `wp_options` VALUES (23,'date_format','F j, Y','yes');
INSERT INTO `wp_options` VALUES (24,'time_format','g:i a','yes');
INSERT INTO `wp_options` VALUES (25,'links_updated_date_format','F j, Y g:i a','yes');
INSERT INTO `wp_options` VALUES (26,'comment_moderation','0','yes');
INSERT INTO `wp_options` VALUES (27,'moderation_notify','1','yes');
INSERT INTO `wp_options` VALUES (28,'permalink_structure','/%postname%/','yes');
INSERT INTO `wp_options` VALUES (30,'hack_file','0','yes');
INSERT INTO `wp_options` VALUES (31,'blog_charset','UTF-8','yes');
INSERT INTO `wp_options` VALUES (32,'moderation_keys','','no');
INSERT INTO `wp_options` VALUES (33,'active_plugins','a:17:{i:0;s:29:\"gravityforms/gravityforms.php\";i:1;s:51:\"acf-gravityforms-add-on/acf-gravityforms-add-on.php\";i:2;s:34:\"advanced-custom-fields-pro/acf.php\";i:3;s:35:\"backupwordpress/backupwordpress.php\";i:4;s:47:\"better-rest-endpoints/better-rest-endpoints.php\";i:5;s:33:\"classic-editor/classic-editor.php\";i:6;s:32:\"duplicate-page/duplicatepage.php\";i:7;s:35:\"google-site-kit/google-site-kit.php\";i:8;s:50:\"gravity-forms-zero-spam/gravityforms-zero-spam.php\";i:9;s:47:\"regenerate-thumbnails/regenerate-thumbnails.php\";i:10;s:21:\"safe-svg/safe-svg.php\";i:11;s:45:\"simple-page-ordering/simple-page-ordering.php\";i:12;s:24:\"wordpress-seo/wp-seo.php\";i:13;s:63:\"wp-migrate-db-pro-media-files/wp-migrate-db-pro-media-files.php\";i:14;s:39:\"wp-migrate-db-pro/wp-migrate-db-pro.php\";i:15;s:25:\"wp-smush-pro/wp-smush.php\";i:16;s:40:\"wpmudev-updates/update-notifications.php\";}','yes');
INSERT INTO `wp_options` VALUES (34,'category_base','','yes');
INSERT INTO `wp_options` VALUES (35,'ping_sites','http://rpc.pingomatic.com/','yes');
INSERT INTO `wp_options` VALUES (36,'comment_max_links','2','yes');
INSERT INTO `wp_options` VALUES (37,'gmt_offset','0','yes');
INSERT INTO `wp_options` VALUES (38,'default_email_category','1','yes');
INSERT INTO `wp_options` VALUES (39,'recently_edited','','no');
INSERT INTO `wp_options` VALUES (40,'template','f1-demo-theme','yes');
INSERT INTO `wp_options` VALUES (41,'stylesheet','f1-demo-theme','yes');
INSERT INTO `wp_options` VALUES (44,'comment_registration','0','yes');
INSERT INTO `wp_options` VALUES (45,'html_type','text/html','yes');
INSERT INTO `wp_options` VALUES (46,'use_trackback','0','yes');
INSERT INTO `wp_options` VALUES (47,'default_role','subscriber','yes');
INSERT INTO `wp_options` VALUES (48,'db_version','49752','yes');
INSERT INTO `wp_options` VALUES (49,'uploads_use_yearmonth_folders','1','yes');
INSERT INTO `wp_options` VALUES (50,'upload_path','','yes');
INSERT INTO `wp_options` VALUES (51,'blog_public','0','yes');
INSERT INTO `wp_options` VALUES (52,'default_link_category','2','yes');
INSERT INTO `wp_options` VALUES (53,'show_on_front','page','yes');
INSERT INTO `wp_options` VALUES (54,'tag_base','','yes');
INSERT INTO `wp_options` VALUES (55,'show_avatars','1','yes');
INSERT INTO `wp_options` VALUES (56,'avatar_rating','G','yes');
INSERT INTO `wp_options` VALUES (57,'upload_url_path','','yes');
INSERT INTO `wp_options` VALUES (58,'thumbnail_size_w','150','yes');
INSERT INTO `wp_options` VALUES (59,'thumbnail_size_h','150','yes');
INSERT INTO `wp_options` VALUES (60,'thumbnail_crop','1','yes');
INSERT INTO `wp_options` VALUES (61,'medium_size_w','300','yes');
INSERT INTO `wp_options` VALUES (62,'medium_size_h','300','yes');
INSERT INTO `wp_options` VALUES (63,'avatar_default','mystery','yes');
INSERT INTO `wp_options` VALUES (64,'large_size_w','1024','yes');
INSERT INTO `wp_options` VALUES (65,'large_size_h','1024','yes');
INSERT INTO `wp_options` VALUES (66,'image_default_link_type','none','yes');
INSERT INTO `wp_options` VALUES (67,'image_default_size','','yes');
INSERT INTO `wp_options` VALUES (68,'image_default_align','','yes');
INSERT INTO `wp_options` VALUES (69,'close_comments_for_old_posts','0','yes');
INSERT INTO `wp_options` VALUES (70,'close_comments_days_old','14','yes');
INSERT INTO `wp_options` VALUES (71,'thread_comments','1','yes');
INSERT INTO `wp_options` VALUES (72,'thread_comments_depth','5','yes');
INSERT INTO `wp_options` VALUES (73,'page_comments','0','yes');
INSERT INTO `wp_options` VALUES (74,'comments_per_page','50','yes');
INSERT INTO `wp_options` VALUES (75,'default_comments_page','newest','yes');
INSERT INTO `wp_options` VALUES (76,'comment_order','asc','yes');
INSERT INTO `wp_options` VALUES (77,'sticky_posts','a:0:{}','yes');
INSERT INTO `wp_options` VALUES (78,'widget_categories','a:2:{i:2;a:4:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:12:\"hierarchical\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}','yes');
INSERT INTO `wp_options` VALUES (79,'widget_text','a:0:{}','yes');
INSERT INTO `wp_options` VALUES (80,'widget_rss','a:0:{}','yes');
INSERT INTO `wp_options` VALUES (81,'uninstall_plugins','a:2:{s:40:\"wpmudev-updates/update-notifications.php\";a:2:{i:0;s:17:\"WPMUDEV_Dashboard\";i:1;s:16:\"uninstall_plugin\";}s:33:\"classic-editor/classic-editor.php\";a:2:{i:0;s:14:\"Classic_Editor\";i:1;s:9:\"uninstall\";}}','no');
INSERT INTO `wp_options` VALUES (82,'timezone_string','','yes');
INSERT INTO `wp_options` VALUES (83,'page_for_posts','87','yes');
INSERT INTO `wp_options` VALUES (84,'page_on_front','2','yes');
INSERT INTO `wp_options` VALUES (85,'default_post_format','0','yes');
INSERT INTO `wp_options` VALUES (86,'link_manager_enabled','0','yes');
INSERT INTO `wp_options` VALUES (87,'finished_splitting_shared_terms','1','yes');
INSERT INTO `wp_options` VALUES (88,'site_icon','0','yes');
INSERT INTO `wp_options` VALUES (89,'medium_large_size_w','768','yes');
INSERT INTO `wp_options` VALUES (90,'medium_large_size_h','0','yes');
INSERT INTO `wp_options` VALUES (91,'wp_page_for_privacy_policy','3','yes');
INSERT INTO `wp_options` VALUES (92,'show_comments_cookies_opt_in','1','yes');
INSERT INTO `wp_options` VALUES (93,'admin_email_lifespan','1630435559','yes');
INSERT INTO `wp_options` VALUES (94,'initial_db_version','47018','yes');
INSERT INTO `wp_options` VALUES (95,'wp_user_roles','a:7:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:62:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;s:20:\"wpseo_manage_options\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:35:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:15:\"wpseo_bulk_edit\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}s:13:\"wpseo_manager\";a:2:{s:4:\"name\";s:11:\"SEO Manager\";s:12:\"capabilities\";a:38:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:15:\"wpseo_bulk_edit\";b:1;s:28:\"wpseo_edit_advanced_metadata\";b:1;s:20:\"wpseo_manage_options\";b:1;s:23:\"view_site_health_checks\";b:1;}}s:12:\"wpseo_editor\";a:2:{s:4:\"name\";s:10:\"SEO Editor\";s:12:\"capabilities\";a:36:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:15:\"wpseo_bulk_edit\";b:1;s:28:\"wpseo_edit_advanced_metadata\";b:1;}}}','yes');
INSERT INTO `wp_options` VALUES (96,'fresh_site','0','yes');
INSERT INTO `wp_options` VALUES (97,'widget_search','a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}','yes');
INSERT INTO `wp_options` VALUES (98,'widget_recent-posts','a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}','yes');
INSERT INTO `wp_options` VALUES (99,'widget_recent-comments','a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}','yes');
INSERT INTO `wp_options` VALUES (100,'widget_archives','a:2:{i:2;a:3:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}','yes');
INSERT INTO `wp_options` VALUES (101,'widget_meta','a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}','yes');
INSERT INTO `wp_options` VALUES (102,'sidebars_widgets','a:7:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:3:{i:0;s:14:\"recent-posts-2\";i:1;s:10:\"archives-2\";i:2;s:12:\"categories-2\";}s:13:\"footer-widget\";a:0:{}s:15:\"footer-widget-2\";a:0:{}s:15:\"footer-widget-3\";a:0:{}s:15:\"footer-widget-4\";a:0:{}s:13:\"array_version\";i:3;}','yes');
INSERT INTO `wp_options` VALUES (103,'cron','a:13:{i:1614887091;a:1:{s:34:\"wp_privacy_delete_old_export_files\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1614890691;a:4:{s:32:\"recovery_mode_clean_expired_keys\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1614890838;a:2:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1614890839;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1614890851;a:1:{s:22:\"wpmudev_scheduled_jobs\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1614890853;a:1:{s:19:\"wpseo-reindex-links\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1614890856;a:1:{s:17:\"gravityforms_cron\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1614898800;a:1:{s:19:\"hmbkp_schedule_hook\";a:1:{s:32:\"9af51faf1ff3c7d0ee4a693530c9e638\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:1:{s:2:\"id\";s:10:\"1590526055\";}s:8:\"interval\";i:86400;}}}i:1614970147;a:2:{s:13:\"wpseo-reindex\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:31:\"wpseo_permalink_structure_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1615086000;a:1:{s:19:\"hmbkp_schedule_hook\";a:1:{s:32:\"9be7c788fae9d8eb3b0e09a376f24de1\";a:3:{s:8:\"schedule\";s:6:\"weekly\";s:4:\"args\";a:1:{s:2:\"id\";s:10:\"1590526056\";}s:8:\"interval\";i:604800;}}}i:1615322851;a:1:{s:16:\"wpseo_ryte_fetch\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"weekly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:604800;}}}i:1615409091;a:1:{s:30:\"wp_site_health_scheduled_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"weekly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:604800;}}}s:7:\"version\";i:2;}','yes');
INSERT INTO `wp_options` VALUES (104,'widget_pages','a:1:{s:12:\"_multiwidget\";i:1;}','yes');
INSERT INTO `wp_options` VALUES (105,'widget_calendar','a:1:{s:12:\"_multiwidget\";i:1;}','yes');
INSERT INTO `wp_options` VALUES (106,'widget_media_audio','a:1:{s:12:\"_multiwidget\";i:1;}','yes');
INSERT INTO `wp_options` VALUES (107,'widget_media_image','a:1:{s:12:\"_multiwidget\";i:1;}','yes');
INSERT INTO `wp_options` VALUES (108,'widget_media_gallery','a:1:{s:12:\"_multiwidget\";i:1;}','yes');
INSERT INTO `wp_options` VALUES (109,'widget_media_video','a:1:{s:12:\"_multiwidget\";i:1;}','yes');
INSERT INTO `wp_options` VALUES (110,'nonce_key','&W9r$|#DOR-:&Wd]jF{JC_8$|~q?7v{pq0{;t9CoS+wfuA_`eSZ5SV!:Z)l@G,ID','no');
INSERT INTO `wp_options` VALUES (111,'nonce_salt','{a`>0=$r>]e.b8bKZgxphM*s?PAA7y9FH^G+7=q%9uIC>}#u8>Et+[Xu~3X0{3@0','no');
INSERT INTO `wp_options` VALUES (112,'widget_tag_cloud','a:1:{s:12:\"_multiwidget\";i:1;}','yes');
INSERT INTO `wp_options` VALUES (113,'widget_nav_menu','a:1:{s:12:\"_multiwidget\";i:1;}','yes');
INSERT INTO `wp_options` VALUES (114,'widget_custom_html','a:1:{s:12:\"_multiwidget\";i:1;}','yes');
INSERT INTO `wp_options` VALUES (117,'recovery_keys','a:0:{}','yes');
INSERT INTO `wp_options` VALUES (143,'recently_activated','a:0:{}','yes');
INSERT INTO `wp_options` VALUES (144,'duplicate_page_options','a:4:{s:21:\"duplicate_post_status\";s:5:\"draft\";s:23:\"duplicate_post_redirect\";s:7:\"to_list\";s:21:\"duplicate_post_suffix\";s:0:\"\";s:21:\"duplicate_post_editor\";s:7:\"classic\";}','yes');
INSERT INTO `wp_options` VALUES (145,'gf_db_version','2.4.23','no');
INSERT INTO `wp_options` VALUES (146,'rg_form_version','2.4.23','no');
INSERT INTO `wp_options` VALUES (147,'gform_enable_background_updates','1','yes');
INSERT INTO `wp_options` VALUES (148,'gform_pending_installation','','yes');
INSERT INTO `wp_options` VALUES (150,'googlesitekit_new_site_posts','0','yes');
INSERT INTO `wp_options` VALUES (151,'wp-smush-settings','a:21:{s:4:\"auto\";b:1;s:5:\"lossy\";b:0;s:10:\"strip_exif\";b:1;s:6:\"resize\";b:0;s:9:\"detection\";b:0;s:8:\"original\";b:0;s:6:\"backup\";b:0;s:10:\"png_to_jpg\";b:0;s:7:\"nextgen\";b:0;s:2:\"s3\";b:0;s:9:\"gutenberg\";b:0;s:10:\"js_builder\";b:0;s:3:\"cdn\";b:0;s:11:\"auto_resize\";b:0;s:4:\"webp\";b:1;s:5:\"usage\";b:0;s:17:\"accessible_colors\";b:0;s:9:\"keep_data\";b:1;s:9:\"lazy_load\";b:0;s:17:\"background_images\";b:1;s:16:\"rest_api_support\";b:0;}','yes');
INSERT INTO `wp_options` VALUES (152,'wp-smush-install-type','existing','no');
INSERT INTO `wp_options` VALUES (153,'wp-smush-version','3.8.3','no');
INSERT INTO `wp_options` VALUES (156,'wdp_un_limit_to_user','a:1:{i:0;s:1:\"1\";}','no');
INSERT INTO `wp_options` VALUES (157,'wdp_un_remote_access','','no');
INSERT INTO `wp_options` VALUES (158,'wdp_un_refresh_remote_flag','0','no');
INSERT INTO `wp_options` VALUES (159,'wdp_un_refresh_profile_flag','0','no');
INSERT INTO `wp_options` VALUES (160,'wdp_un_updates_data','a:5:{s:8:\"projects\";a:15:{i:119;a:26:{s:2:\"id\";i:119;s:4:\"paid\";s:4:\"free\";s:4:\"type\";s:6:\"plugin\";s:4:\"name\";s:18:\"WPMU DEV Dashboard\";s:8:\"released\";i:1261092923;s:7:\"updated\";i:1606911871;s:9:\"downloads\";s:8:\"10681428\";s:10:\"popularity\";s:6:\"397351\";s:17:\"short_description\";s:80:\"Instant access to brilliant support and one-click plugin and theme installation.\";s:8:\"features\";a:33:{i:0;s:23:\"One-click installations\";i:1;s:36:\"Hub and Hosting Single Sign-On (SSO)\";i:2;s:19:\"Unbranded analytics\";i:3;s:35:\"Dashboard plugin browse and install\";i:4;s:34:\"Dashboard theme browse and install\";i:5;s:21:\"Simply login to setup\";i:6;s:30:\"Integrated badge notifications\";i:7;s:17:\"One-click updates\";i:8;s:28:\"WPMU DEV dashboard news feed\";i:9;s:28:\"Dashboard widget quick links\";i:10;s:25:\"New release notifications\";i:11;s:20:\"Update notifications\";i:12;s:29:\"View recent WPMU DEV activity\";i:13;s:18:\"Membership manager\";i:14;s:34:\"Hide/Remove WPMU DEV hero branding\";i:15;s:18:\"Background updates\";i:16;s:18:\"Hide notifications\";i:17;s:30:\"Limit to Multisite Super Admin\";i:18;s:21:\"See reputation points\";i:19;s:27:\"Built-in conflict avoidance\";i:20;s:39:\"Occasional special membership discounts\";i:21;s:33:\"Participate in WPMU DEV community\";i:22;s:19:\"Access forum search\";i:23;s:22:\"Fast access to Q&amp;A\";i:24;s:39:\"Grant temporary access to support staff\";i:25;s:34:\"Direct links to usage instructions\";i:26;s:35:\"Installed theme version information\";i:27;s:36:\"Installed plugin version information\";i:28;s:22:\"Post support questions\";i:29;s:29:\"System information quick view\";i:30;s:29:\"PHP configuration information\";i:31;s:17:\"MySQL information\";i:32;s:18:\"Server information\";}s:7:\"version\";s:6:\"4.10.6\";s:17:\"free_version_slug\";s:0:\"\";s:10:\"autoupdate\";s:1:\"1\";s:6:\"active\";b:1;s:10:\"compatible\";s:50:\"WordPress 5.6.2, Multisite 5.6.2, BuddyPress 7.2.0\";s:8:\"requires\";s:2:\"wp\";s:3:\"url\";s:55:\"https://premium.wpmudev.org/project/wpmu-dev-dashboard/\";s:9:\"thumbnail\";s:76:\"https://premium.wpmudev.org/wp-content/uploads/2009/12/Dashboard-280x158.png\";s:16:\"thumbnail_square\";s:74:\"https://premium.wpmudev.org/wp-content/uploads/2009/12/Dashboard-90x90.png\";s:15:\"thumbnail_large\";s:68:\"https://premium.wpmudev.org/wp-content/uploads/2009/12/Dashboard.png\";s:5:\"video\";s:41:\"//fast.wistia.net/embed/iframe/irz1r2ze9m\";s:13:\"wp_config_url\";s:31:\"admin.php?page=wpmudev-settings\";s:13:\"ms_config_url\";s:31:\"admin.php?page=wpmudev-settings\";s:7:\"package\";i:0;s:11:\"screenshots\";a:3:{i:0;a:2:{s:3:\"url\";s:93:\"https://premium.wpmudev.org/wp-content/uploads/projects/119/screenshots/dashboard-support.png\";s:4:\"desc\";s:21:\"Secure support access\";}i:1;a:2:{s:3:\"url\";s:92:\"https://premium.wpmudev.org/wp-content/uploads/projects/119/screenshots/dashboard-access.png\";s:4:\"desc\";s:41:\"Quick access from the WordPress dashboard\";}i:2;a:2:{s:3:\"url\";s:94:\"https://premium.wpmudev.org/wp-content/uploads/projects/119/screenshots/96343734_analitics.png\";s:4:\"desc\";s:19:\"Unbranded Analytics\";}}s:6:\"_order\";i:1;}i:3779636;a:26:{s:2:\"id\";i:3779636;s:4:\"paid\";s:4:\"paid\";s:4:\"type\";s:6:\"plugin\";s:4:\"name\";s:14:\"The Hub Client\";s:8:\"released\";i:1597667386;s:7:\"updated\";i:1607610438;s:9:\"downloads\";s:4:\"9127\";s:10:\"popularity\";s:4:\"2877\";s:17:\"short_description\";s:102:\"White label WPMU DEV and give your clients their own Hub experience on your site, with your branding. \";s:8:\"features\";a:7:{i:0;s:30:\"Completely white label The Hub\";i:1;s:31:\"Run entirely on your own domain\";i:2;s:30:\"Control all user access levels\";i:3;s:34:\"Free with your WPMU DEV membership\";i:4;s:39:\"Easy to set up, just install the plugin\";i:5;s:20:\"Use any host (or us)\";i:6;s:51:\"Sell your clients different levels of subscriptions\";}s:7:\"version\";s:5:\"1.0.4\";s:17:\"free_version_slug\";s:0:\"\";s:10:\"autoupdate\";s:1:\"1\";s:6:\"active\";b:1;s:10:\"compatible\";s:0:\"\";s:8:\"requires\";s:2:\"wp\";s:3:\"url\";s:51:\"https://premium.wpmudev.org/project/the-hub-client/\";s:9:\"thumbnail\";s:84:\"https://premium.wpmudev.org/wp-content/uploads/2020/08/gfx-project-thumb-280x158.png\";s:16:\"thumbnail_square\";s:82:\"https://premium.wpmudev.org/wp-content/uploads/2020/08/gfx-project-thumb-90x90.png\";s:15:\"thumbnail_large\";s:76:\"https://premium.wpmudev.org/wp-content/uploads/2020/08/gfx-project-thumb.png\";s:5:\"video\";b:0;s:13:\"wp_config_url\";s:26:\"admin.php?page=wpmudev-hub\";s:13:\"ms_config_url\";s:26:\"admin.php?page=wpmudev-hub\";s:7:\"package\";i:0;s:11:\"screenshots\";a:4:{i:0;a:2:{s:3:\"url\";s:88:\"https://premium.wpmudev.org/wp-content/uploads/projects/3779636/screenshots/gfx-hero.png\";s:4:\"desc\";s:0:\"\";}i:1;a:2:{s:3:\"url\";s:90:\"https://premium.wpmudev.org/wp-content/uploads/projects/3779636/screenshots/gfx-styled.png\";s:4:\"desc\";s:0:\"\";}i:2;a:2:{s:3:\"url\";s:95:\"https://premium.wpmudev.org/wp-content/uploads/projects/3779636/screenshots/gfx-user-access.png\";s:4:\"desc\";s:0:\"\";}i:3;a:2:{s:3:\"url\";s:89:\"https://premium.wpmudev.org/wp-content/uploads/projects/3779636/screenshots/gfx-roles.png\";s:4:\"desc\";s:0:\"\";}}s:6:\"_order\";i:2;}i:912164;a:26:{s:2:\"id\";i:912164;s:4:\"paid\";s:4:\"paid\";s:4:\"type\";s:6:\"plugin\";s:4:\"name\";s:9:\"Smush Pro\";s:8:\"released\";i:1416874433;s:7:\"updated\";i:1612957299;s:9:\"downloads\";s:7:\"2577523\";s:10:\"popularity\";s:6:\"354437\";s:17:\"short_description\";s:101:\"User\'s choice, award-winning, and benchmark tested – The best image optimizer plugin for WordPress.\";s:8:\"features\";a:28:{i:0;s:31:\"Double savings with Super-Smush\";i:1;s:28:\"Automatic optimize on upload\";i:2;s:20:\"Smush Pro global CDN\";i:3;s:31:\"Compress huge photos up to 32MB\";i:4;s:29:\"Perfect-fit auto image resize\";i:5;s:33:\"Lazy Loading for offscreen images\";i:6;s:29:\"WebP next-gen file conversion\";i:7;s:31:\"PNG to lossy JPEG smart convert\";i:8;s:34:\"One-click compress existing images\";i:9;s:35:\"Retain rights to every file forever\";i:10;s:29:\"Optimize images in any folder\";i:11;s:34:\"Smush or save original image files\";i:12;s:37:\"Multisite global and subsite settings\";i:13;s:42:\"Lossy compression with little quality loss\";i:14;s:28:\"Amazon S3 plugin integration\";i:15;s:26:\"NextGEN Gallery compatible\";i:16;s:18:\"Preserve EXIF data\";i:17;s:27:\"WP Retina 2x plugin support\";i:18;s:22:\"Envira Gallery Support\";i:19;s:28:\"Avada Fusion Builder Support\";i:20;s:26:\"Dedicated smushing servers\";i:21;s:35:\"HTTPS encrypted browsing compatible\";i:22;s:21:\"WPML media compatible\";i:23;s:20:\"Lossless compression\";i:24;s:39:\"Strip unused colors from indexed images\";i:25;s:30:\"Progress and savings reporting\";i:26;s:26:\"Compress individual images\";i:27;s:32:\"Instant asynchronous compression\";}s:7:\"version\";s:5:\"3.8.3\";s:17:\"free_version_slug\";s:23:\"wp-smushit/wp-smush.php\";s:10:\"autoupdate\";s:1:\"1\";s:6:\"active\";b:1;s:10:\"compatible\";s:65:\"WordPress 5.6.2, Multisite 5.6.2, BuddyPress 7.2.0, Upfront 1.9.4\";s:8:\"requires\";s:2:\"wp\";s:3:\"url\";s:49:\"https://premium.wpmudev.org/project/wp-smush-pro/\";s:9:\"thumbnail\";s:80:\"https://premium.wpmudev.org/wp-content/uploads/2014/11/Smush_2016_02-280x158.png\";s:16:\"thumbnail_square\";s:78:\"https://premium.wpmudev.org/wp-content/uploads/2014/11/Smush_2016_02-90x90.png\";s:15:\"thumbnail_large\";s:72:\"https://premium.wpmudev.org/wp-content/uploads/2014/11/Smush_2016_02.png\";s:5:\"video\";b:0;s:13:\"wp_config_url\";s:20:\"admin.php?page=smush\";s:13:\"ms_config_url\";s:20:\"admin.php?page=smush\";s:7:\"package\";i:0;s:11:\"screenshots\";a:4:{i:0;a:2:{s:3:\"url\";s:108:\"https://premium.wpmudev.org/wp-content/uploads/projects/912164/screenshots/1554180963_smush-pro-bulk-new.png\";s:4:\"desc\";s:14:\"Bulk Smush Now\";}i:1;a:2:{s:3:\"url\";s:109:\"https://premium.wpmudev.org/wp-content/uploads/projects/912164/screenshots/918101858_smush-pro-bulk-smush.png\";s:4:\"desc\";s:20:\"Smush Pro Bulk Smush\";}i:2;a:2:{s:3:\"url\";s:107:\"https://premium.wpmudev.org/wp-content/uploads/projects/912164/screenshots/158049080_smush-pro-settings.png\";s:4:\"desc\";s:18:\"Smush Pro Settings\";}i:3;a:2:{s:3:\"url\";s:107:\"https://premium.wpmudev.org/wp-content/uploads/projects/912164/screenshots/665647559_image-zoom-735x470.jpg\";s:4:\"desc\";s:29:\"Smush without loss of quality\";}}s:6:\"_order\";i:3;}i:1081721;a:26:{s:2:\"id\";i:1081721;s:4:\"paid\";s:4:\"full\";s:4:\"type\";s:6:\"plugin\";s:4:\"name\";s:15:\"Hummingbird Pro\";s:8:\"released\";i:1456236462;s:7:\"updated\";i:1614806255;s:9:\"downloads\";s:7:\"1527886\";s:10:\"popularity\";s:6:\"130908\";s:17:\"short_description\";s:56:\"Everything you need to get your site running super fast.\";s:8:\"features\";a:16:{i:0;s:28:\"Generate performance reports\";i:1;s:30:\"Recommended speed improvements\";i:2;s:15:\"Browser caching\";i:3;s:17:\"Full-page caching\";i:4;s:16:\"Gravatar caching\";i:5;s:11:\"RSS caching\";i:6;s:12:\"Minify files\";i:7;s:13:\"Combine files\";i:8;s:17:\"Set load position\";i:9;s:21:\"Included output graph\";i:10;s:25:\"Simple GZIP configuration\";i:11;s:30:\"Advanced Minification controls\";i:12;s:31:\"Bonus: Sync with Uptime monitor\";i:13;s:32:\"Down and slow load notifications\";i:14;s:23:\"Track average pagespeed\";i:15;s:32:\"Better search engine positioning\";}s:7:\"version\";s:5:\"2.7.2\";s:17:\"free_version_slug\";s:42:\"hummingbird-performance/wp-hummingbird.php\";s:10:\"autoupdate\";s:1:\"1\";s:6:\"active\";b:1;s:10:\"compatible\";s:47:\"WordPress 5.6.2, Multisite 5.6.2, Upfront 1.9.4\";s:8:\"requires\";s:2:\"wp\";s:3:\"url\";s:51:\"https://premium.wpmudev.org/project/wp-hummingbird/\";s:9:\"thumbnail\";s:78:\"https://premium.wpmudev.org/wp-content/uploads/2016/02/HummingBird-280x158.png\";s:16:\"thumbnail_square\";s:76:\"https://premium.wpmudev.org/wp-content/uploads/2016/02/HummingBird-90x90.png\";s:15:\"thumbnail_large\";s:70:\"https://premium.wpmudev.org/wp-content/uploads/2016/02/HummingBird.png\";s:5:\"video\";s:41:\"//fast.wistia.net/embed/iframe/cdpqnbvssg\";s:13:\"wp_config_url\";s:19:\"admin.php?page=wphb\";s:13:\"ms_config_url\";s:19:\"admin.php?page=wphb\";s:7:\"package\";i:0;s:11:\"screenshots\";a:4:{i:0;a:2:{s:3:\"url\";s:119:\"https://premium.wpmudev.org/wp-content/uploads/projects/1081721/screenshots/1355502351_hum-gcompress-compressor-new.png\";s:4:\"desc\";s:5:\"G-zip\";}i:1;a:2:{s:3:\"url\";s:108:\"https://premium.wpmudev.org/wp-content/uploads/projects/1081721/screenshots/1686427142_hum-browser-cache.png\";s:4:\"desc\";s:13:\"Browser Cache\";}i:2;a:2:{s:3:\"url\";s:105:\"https://premium.wpmudev.org/wp-content/uploads/projects/1081721/screenshots/355595470_hum-pro-testing.png\";s:4:\"desc\";s:31:\"Hummingbird Performance Testing\";}i:3;a:2:{s:3:\"url\";s:108:\"https://premium.wpmudev.org/wp-content/uploads/projects/1081721/screenshots/2090545727_hum-inline-minify.png\";s:4:\"desc\";s:13:\"inline minify\";}}s:6:\"_order\";i:4;}i:1081723;a:26:{s:2:\"id\";i:1081723;s:4:\"paid\";s:4:\"full\";s:4:\"type\";s:6:\"plugin\";s:4:\"name\";s:12:\"Defender Pro\";s:8:\"released\";i:1456855142;s:7:\"updated\";i:1614584470;s:9:\"downloads\";s:7:\"1408645\";s:10:\"popularity\";s:6:\"139399\";s:17:\"short_description\";s:104:\"Regular security scans, vulnerability reports, safety recommendations and security tweaks for WordPress.\";s:8:\"features\";a:20:{i:0;s:21:\"Analyze site security\";i:1;s:30:\"Security tweak recommendations\";i:2;s:27:\"Resolve issues with a click\";i:3;s:31:\"Manual and automatic IP lockout\";i:4;s:18:\"Filterable IP logs\";i:5;s:27:\"Scan core files for changes\";i:6;s:25:\"2-Factor Authentification\";i:7;s:24:\"Customize 2-factor email\";i:8;s:19:\"Vulnerability scans\";i:9;s:14:\"Schedule scans\";i:10;s:28:\"Repair/restore changed files\";i:11;s:25:\"Choose file types to scan\";i:12;s:29:\"Skip files based on file size\";i:13;s:21:\"Receive email reports\";i:14;s:21:\"Set report recipients\";i:15;s:27:\"Google blocklist monitoring\";i:16;s:17:\"Automated backups\";i:17;s:20:\"Full website backups\";i:18;s:13:\"Cloud backups\";i:19;s:30:\"Site interactions with logging\";}s:7:\"version\";s:5:\"2.4.7\";s:17:\"free_version_slug\";s:33:\"defender-security/wp-defender.php\";s:10:\"autoupdate\";s:1:\"1\";s:6:\"active\";b:1;s:10:\"compatible\";s:65:\"WordPress 5.6.2, Multisite 5.6.2, BuddyPress 7.2.0, Upfront 1.9.4\";s:8:\"requires\";s:2:\"wp\";s:3:\"url\";s:48:\"https://premium.wpmudev.org/project/wp-defender/\";s:9:\"thumbnail\";s:75:\"https://premium.wpmudev.org/wp-content/uploads/2016/02/Defender-280x158.png\";s:16:\"thumbnail_square\";s:73:\"https://premium.wpmudev.org/wp-content/uploads/2016/02/Defender-90x90.png\";s:15:\"thumbnail_large\";s:67:\"https://premium.wpmudev.org/wp-content/uploads/2016/02/Defender.png\";s:5:\"video\";s:41:\"//fast.wistia.net/embed/iframe/ps9y7nphu1\";s:13:\"wp_config_url\";s:26:\"admin.php?page=wp-defender\";s:13:\"ms_config_url\";s:26:\"admin.php?page=wp-defender\";s:7:\"package\";i:0;s:11:\"screenshots\";a:4:{i:0;a:2:{s:3:\"url\";s:102:\"https://premium.wpmudev.org/wp-content/uploads/projects/1081723/screenshots/675480798_6-ip-lockout.jpg\";s:4:\"desc\";s:10:\"ip-lockout\";}i:1;a:2:{s:3:\"url\";s:102:\"https://premium.wpmudev.org/wp-content/uploads/projects/1081723/screenshots/1734340993_5-blacklist.jpg\";s:4:\"desc\";s:20:\"Blacklist Monitoring\";}i:2;a:2:{s:3:\"url\";s:103:\"https://premium.wpmudev.org/wp-content/uploads/projects/1081723/screenshots/1971221549_4-audit-logs.jpg\";s:4:\"desc\";s:10:\"Audit Logs\";}i:3;a:2:{s:3:\"url\";s:97:\"https://premium.wpmudev.org/wp-content/uploads/projects/1081723/screenshots/1252355198_3-scan.jpg\";s:4:\"desc\";s:12:\"Scan Reports\";}}s:6:\"_order\";i:5;}i:1107020;a:26:{s:2:\"id\";i:1107020;s:4:\"paid\";s:4:\"paid\";s:4:\"type\";s:6:\"plugin\";s:4:\"name\";s:10:\"Hustle Pro\";s:8:\"released\";i:1471315160;s:7:\"updated\";i:1613482629;s:9:\"downloads\";s:6:\"257630\";s:10:\"popularity\";s:5:\"24015\";s:17:\"short_description\";s:100:\"Grow your business and audience with this super easy, super slick email opt-in and marketing plugin.\";s:8:\"features\";a:12:{i:0;s:59:\"Pop-ups, slide-ins, widgets, embeds, and after post opt-ins\";i:1;s:35:\"All the social share icons you need\";i:2;s:46:\"Easily customize designs with in built editing\";i:3;s:34:\"Color match your brand, like magic\";i:4;s:64:\"Show your stuff in style with smooth built-in display animations\";i:5;s:223:\"Integrate with your favorite providers including: Aweber, MailChimp, Constant Contacts, Sendy, ActiveCampaign, SendInBlue, Hubspot, Infusionsoft, Mad Mimi, ConvertKit, MailerLite, iContact, GetResponse, and Campaign Monitor\";i:6;s:58:\"Manage who sees your hustle with super powerful conditions\";i:7;s:47:\"Track how many times your material is displayed\";i:8;s:42:\"See submissions straight through WordPress\";i:9;s:55:\"Conversion rates overview to make your clients ecstatic\";i:10;s:36:\"Great default layouts to choose from\";i:11;s:25:\"Easy management dashboard\";}s:7:\"version\";s:5:\"4.4.2\";s:17:\"free_version_slug\";s:27:\"wordpress-popup/popover.php\";s:10:\"autoupdate\";s:1:\"1\";s:6:\"active\";b:1;s:10:\"compatible\";s:60:\"WordPress 5.6.2, Multisite 5.6.2, BuddyPress 7.2.0, bbPress \";s:8:\"requires\";s:2:\"wp\";s:3:\"url\";s:43:\"https://premium.wpmudev.org/project/hustle/\";s:9:\"thumbnail\";s:76:\"https://premium.wpmudev.org/wp-content/uploads/2016/08/hustle-01-280x158.png\";s:16:\"thumbnail_square\";s:74:\"https://premium.wpmudev.org/wp-content/uploads/2016/08/hustle-01-90x90.png\";s:15:\"thumbnail_large\";s:68:\"https://premium.wpmudev.org/wp-content/uploads/2016/08/hustle-01.png\";s:5:\"video\";b:0;s:13:\"wp_config_url\";s:21:\"admin.php?page=hustle\";s:13:\"ms_config_url\";s:0:\"\";s:7:\"package\";i:0;s:11:\"screenshots\";a:4:{i:0;a:2:{s:3:\"url\";s:110:\"https://premium.wpmudev.org/wp-content/uploads/projects/1107020/screenshots/960353611_hustle-social-design.png\";s:4:\"desc\";s:18:\"Hustle Social Bars\";}i:1;a:2:{s:3:\"url\";s:108:\"https://premium.wpmudev.org/wp-content/uploads/projects/1107020/screenshots/1653524749_2-style-options-1.jpg\";s:4:\"desc\";s:21:\"Hustle Layout Options\";}i:2;a:2:{s:3:\"url\";s:109:\"https://premium.wpmudev.org/wp-content/uploads/projects/1107020/screenshots/469638973_premadecolorschemes.png\";s:4:\"desc\";s:20:\"Hustle Color Schemes\";}i:3;a:2:{s:3:\"url\";s:106:\"https://premium.wpmudev.org/wp-content/uploads/projects/1107020/screenshots/938384474_layoutvariations.png\";s:4:\"desc\";s:24:\"Hustle Design Variations\";}}s:6:\"_order\";i:6;}i:2097296;a:26:{s:2:\"id\";i:2097296;s:4:\"paid\";s:4:\"paid\";s:4:\"type\";s:6:\"plugin\";s:4:\"name\";s:14:\"Forminator Pro\";s:8:\"released\";i:1519137568;s:7:\"updated\";i:1614268936;s:9:\"downloads\";s:6:\"308611\";s:10:\"popularity\";s:5:\"32840\";s:17:\"short_description\";s:135:\"Drag and drop WordPress form builder plugin with interactive polls and quizzes for increasing user engagement and building a following.\";s:8:\"features\";a:42:{i:0;s:31:\"Responsive fit for every screen\";i:1;s:13:\"Developer API\";i:2;s:15:\"Stripe Payments\";i:3;s:18:\"PayPal integration\";i:4;s:22:\"SCA Compliant Payments\";i:5;s:12:\"Calculations\";i:6;s:16:\"Google ReCAPTCHA\";i:7;s:26:\"Drag-and-drop form builder\";i:8;s:26:\"Forms  for every situation\";i:9;s:15:\"+15 Form blocks\";i:10;s:36:\"Email routing and conditional emails\";i:11;s:17:\"Form pre-populate\";i:12;s:22:\"Toggle styling options\";i:13;s:16:\"Campaign Monitor\";i:14;s:7:\"HubSpot\";i:15;s:14:\"ActiveCampaign\";i:16;s:13:\"Google Sheets\";i:17;s:31:\"Zapier (connects to +1000 apps)\";i:18;s:18:\"Trello Integration\";i:19;s:9:\"MailChimp\";i:20;s:6:\"AWeber\";i:21;s:17:\"Interactive polls\";i:22;s:18:\"Pagination options\";i:23;s:23:\"Collect and track stats\";i:24;s:23:\"No wrong answer quizzes\";i:25;s:21:\"Submissions dashboard\";i:26;s:15:\"Knowledge tests\";i:27;s:12:\"Live preview\";i:28;s:15:\"Knowledge tests\";i:29;s:24:\"Gutenberg block included\";i:30;s:10:\"GDPR ready\";i:31;s:13:\"Hidden fields\";i:32;s:27:\"Customized submission forms\";i:33;s:32:\"Schedule form submission reports\";i:34;s:16:\"Privacy settings\";i:35;s:29:\"Advanced email configurations\";i:36;s:35:\"Custom login and registration forms\";i:37;s:37:\"Instant migration from Contact Form 7\";i:38;s:42:\"Pass form data (variables) to another page\";i:39;s:26:\"Add E-signature form field\";i:40;s:35:\"Multiple file, drag and drop upload\";i:41;s:34:\"Advanced Datepicker field settings\";}s:7:\"version\";s:6:\"1.14.9\";s:17:\"free_version_slug\";s:0:\"\";s:10:\"autoupdate\";s:1:\"1\";s:6:\"active\";b:1;s:10:\"compatible\";s:0:\"\";s:8:\"requires\";s:2:\"wp\";s:3:\"url\";s:51:\"https://premium.wpmudev.org/project/forminator-pro/\";s:9:\"thumbnail\";s:85:\"https://premium.wpmudev.org/wp-content/uploads/2018/02/forminator-feature-280x158.png\";s:16:\"thumbnail_square\";s:83:\"https://premium.wpmudev.org/wp-content/uploads/2018/02/forminator-feature-90x90.png\";s:15:\"thumbnail_large\";s:77:\"https://premium.wpmudev.org/wp-content/uploads/2018/02/forminator-feature.png\";s:5:\"video\";b:0;s:13:\"wp_config_url\";s:25:\"admin.php?page=forminator\";s:13:\"ms_config_url\";s:0:\"\";s:7:\"package\";i:0;s:11:\"screenshots\";a:4:{i:0;a:2:{s:3:\"url\";s:113:\"https://premium.wpmudev.org/wp-content/uploads/projects/2097296/screenshots/1276807337_forminator-recaptcha-4.gif\";s:4:\"desc\";s:32:\"Forminator ReCAPTCHA Integration\";}i:1;a:2:{s:3:\"url\";s:106:\"https://premium.wpmudev.org/wp-content/uploads/projects/2097296/screenshots/1690180223_forminator-quiz.png\";s:4:\"desc\";s:15:\"Forminator quiz\";}i:2;a:2:{s:3:\"url\";s:109:\"https://premium.wpmudev.org/wp-content/uploads/projects/2097296/screenshots/1437585076_forminator-polls-2.png\";s:4:\"desc\";s:23:\"Forminator Poll results\";}i:3;a:2:{s:3:\"url\";s:105:\"https://premium.wpmudev.org/wp-content/uploads/projects/2097296/screenshots/1414388846_contact-form-5.png\";s:4:\"desc\";s:23:\"Forminator contact form\";}}s:6:\"_order\";i:7;}i:167;a:26:{s:2:\"id\";i:167;s:4:\"paid\";s:4:\"paid\";s:4:\"type\";s:6:\"plugin\";s:4:\"name\";s:14:\"SmartCrawl Pro\";s:8:\"released\";i:1298584937;s:7:\"updated\";i:1614863065;s:9:\"downloads\";s:6:\"678235\";s:10:\"popularity\";s:5:\"69898\";s:17:\"short_description\";s:100:\"Boost your PageRank and drive more traffic to your site with little effort and simple configuration.\";s:8:\"features\";a:33:{i:0;s:22:\"Simple guided settings\";i:1;s:30:\"Offer SEO options by user role\";i:2;s:39:\"Direct interaction with Google and Bing\";i:3;s:48:\"Send sitemap updates automatic to search engines\";i:4;s:63:\"Custom post titles and meta descriptions (per custom post type)\";i:5;s:32:\"Title and meta data optimization\";i:6;s:26:\"Automatic sitewide linking\";i:7;s:24:\"Complete Moz integration\";i:8;s:38:\"Multisite and BuddyPress compatibility\";i:9;s:36:\"Process posts and pages individually\";i:10;s:17:\"Process RSS feeds\";i:11;s:31:\"Conduct case sensitive matching\";i:12;s:23:\"Prevent duplicate links\";i:13;s:28:\"Open links in new tab/window\";i:14;s:35:\"Exclude posts or pages from sitemap\";i:15;s:40:\"Exclude custom post types and taxonomies\";i:16;s:27:\"Exclude categories and tags\";i:17;s:41:\"Include or exclude images and stylesheets\";i:18;s:46:\"Include or remove the sitemap dashboard widget\";i:19;s:33:\"Disable automatic sitemap updates\";i:20;s:65:\"Post categories, tags and custom taxonomy title and meta defaults\";i:21;s:17:\"Custom home title\";i:22;s:21:\"Home meta description\";i:23;s:8:\"Keywords\";i:24;s:51:\"Import/export to quickly add SmartCrawl to any site\";i:25;s:39:\"Yoast SEO settings and content importer\";i:26;s:44:\"All in One SEO settings and content importer\";i:27;s:37:\"Main blog archive meta robots options\";i:28;s:29:\"Post and media title defaults\";i:29;s:40:\"Post and media meta description defaults\";i:30;s:53:\"Post categories, tags and custom taxonomy robots tags\";i:31;s:24:\"Author and date archives\";i:32;s:39:\"404 page title and description defaults\";}s:7:\"version\";s:4:\"2.10\";s:17:\"free_version_slug\";s:31:\"smartcrawl-seo/wpmu-dev-seo.php\";s:10:\"autoupdate\";s:1:\"1\";s:6:\"active\";b:1;s:10:\"compatible\";s:65:\"WordPress 5.6.2, Multisite 5.6.2, BuddyPress 7.2.0, Upfront 1.9.4\";s:8:\"requires\";s:2:\"wp\";s:3:\"url\";s:61:\"https://premium.wpmudev.org/project/smartcrawl-wordpress-seo/\";s:9:\"thumbnail\";s:106:\"https://premium.wpmudev.org/wp-content/uploads/2011/02/SEO_Webcrawler_1470_SEO_Webcrawler_1470-280x158.png\";s:16:\"thumbnail_square\";s:104:\"https://premium.wpmudev.org/wp-content/uploads/2011/02/SEO_Webcrawler_1470_SEO_Webcrawler_1470-90x90.png\";s:15:\"thumbnail_large\";s:98:\"https://premium.wpmudev.org/wp-content/uploads/2011/02/SEO_Webcrawler_1470_SEO_Webcrawler_1470.png\";s:5:\"video\";s:41:\"//fast.wistia.net/embed/iframe/w6t8a9mq8j\";s:13:\"wp_config_url\";s:25:\"admin.php?page=wds_wizard\";s:13:\"ms_config_url\";s:25:\"admin.php?page=wds_wizard\";s:7:\"package\";i:0;s:11:\"screenshots\";a:4:{i:0;a:2:{s:3:\"url\";s:104:\"https://premium.wpmudev.org/wp-content/uploads/projects/167/screenshots/906662147_smartcrawl-checkup.png\";s:4:\"desc\";s:18:\"SmartCrawl Checkup\";}i:1;a:2:{s:3:\"url\";s:105:\"https://premium.wpmudev.org/wp-content/uploads/projects/167/screenshots/1008740409_smartcrawl-sitemap.png\";s:4:\"desc\";s:18:\"SmartCrawl Sitemap\";}i:2;a:2:{s:3:\"url\";s:109:\"https://premium.wpmudev.org/wp-content/uploads/projects/167/screenshots/1267268902_smartcrawl-autolinking.png\";s:4:\"desc\";s:22:\"SmartCrawl autolinking\";}i:3;a:2:{s:3:\"url\";s:119:\"https://premium.wpmudev.org/wp-content/uploads/projects/167/screenshots/205500292_smartcrawl-readability-compressor.png\";s:4:\"desc\";s:22:\"SmartCrawl Readability\";}}s:6:\"_order\";i:8;}i:3760011;a:26:{s:2:\"id\";i:3760011;s:4:\"paid\";s:4:\"paid\";s:4:\"type\";s:6:\"plugin\";s:4:\"name\";s:12:\"Snapshot Pro\";s:8:\"released\";i:1592204194;s:7:\"updated\";i:1612230704;s:9:\"downloads\";s:5:\"75804\";s:10:\"popularity\";s:5:\"28399\";s:17:\"short_description\";s:104:\"Make and schedule incremental backups of your WordPress websites and store them on secure cloud storage.\";s:8:\"features\";a:15:{i:0;s:30:\"10GB of WPMU DEV cloud storage\";i:1;s:32:\"Manage your backups from The Hub\";i:2;s:17:\"Redundant backups\";i:3;s:32:\"Multisite Global file exclusions\";i:4;s:17:\"Scheduled backups\";i:5;s:19:\"Set backup interval\";i:6;s:13:\"Manual backup\";i:7;s:20:\"Multisite compatible\";i:8;s:18:\"Backup entire site\";i:9;s:34:\"Exclude specific files and folders\";i:10;s:22:\"Downloadable log files\";i:11;s:24:\"Simple one-click restore\";i:12;s:31:\"30 backups automatically stored\";i:13;s:15:\"Dynamic scaling\";i:14;s:19:\"Backup zipstreaming\";}s:7:\"version\";s:3:\"4.3\";s:17:\"free_version_slug\";s:0:\"\";s:10:\"autoupdate\";s:1:\"1\";s:6:\"active\";b:1;s:10:\"compatible\";s:0:\"\";s:8:\"requires\";s:2:\"wp\";s:3:\"url\";s:45:\"https://premium.wpmudev.org/project/snapshot/\";s:9:\"thumbnail\";s:82:\"https://premium.wpmudev.org/wp-content/uploads/2012/02/Snapshot_plugin-280x158.png\";s:16:\"thumbnail_square\";s:80:\"https://premium.wpmudev.org/wp-content/uploads/2012/02/Snapshot_plugin-90x90.png\";s:15:\"thumbnail_large\";s:74:\"https://premium.wpmudev.org/wp-content/uploads/2012/02/Snapshot_plugin.png\";s:5:\"video\";b:0;s:13:\"wp_config_url\";s:31:\"admin.php?page=snapshot-backups\";s:13:\"ms_config_url\";s:31:\"admin.php?page=snapshot-backups\";s:7:\"package\";i:0;s:11:\"screenshots\";a:4:{i:0;a:2:{s:3:\"url\";s:95:\"https://premium.wpmudev.org/wp-content/uploads/projects/3760011/screenshots/Snapshot-4-dash.png\";s:4:\"desc\";s:80:\"Control every aspect of your backups, right down to the time and day they occur.\";}i:1;a:2:{s:3:\"url\";s:104:\"https://premium.wpmudev.org/wp-content/uploads/projects/3760011/screenshots/snapshot4-manage-backups.png\";s:4:\"desc\";s:51:\"Manage your backups from one easy-to-use dashboard.\";}i:2;a:2:{s:3:\"url\";s:107:\"https://premium.wpmudev.org/wp-content/uploads/projects/3760011/screenshots/Snaphot-4-available-backups.png\";s:4:\"desc\";s:35:\"Track the progress of your backups.\";}i:3;a:2:{s:3:\"url\";s:106:\"https://premium.wpmudev.org/wp-content/uploads/projects/3760011/screenshots/Snapshot4-schedule-backups.png\";s:4:\"desc\";s:54:\"Automate the time, day, and frequency of your backups.\";}}s:6:\"_order\";i:9;}i:257;a:26:{s:2:\"id\";i:257;s:4:\"paid\";s:4:\"paid\";s:4:\"type\";s:6:\"plugin\";s:4:\"name\";s:12:\"Snapshot Pro\";s:8:\"released\";i:1328745252;s:7:\"updated\";i:1594799224;s:9:\"downloads\";s:6:\"725500\";s:10:\"popularity\";s:5:\"37992\";s:17:\"short_description\";s:96:\"The automated, on-demand time-traveler that snaps and stores backups for one-click restoration. \";s:8:\"features\";a:28:{i:0;s:30:\"10GB of WPMU DEV cloud storage\";i:1;s:22:\"The Hub backup manager\";i:2;s:17:\"Redundant backups\";i:3;s:22:\"Server info quick view\";i:4;s:19:\"Manage memory usage\";i:5;s:32:\"Multisite Global file exclusions\";i:6;s:10:\"ZipArchive\";i:7;s:6:\"PclZip\";i:8;s:35:\"Size segmenting eliminates timeouts\";i:9;s:17:\"Scheduled backups\";i:10;s:19:\"Set backup interval\";i:11;s:13:\"Manual backup\";i:12;s:20:\"Multisite compatible\";i:13;s:18:\"Backup entire site\";i:14;s:19:\"Include media files\";i:15;s:22:\"Exclude specific files\";i:16;s:18:\"Annotate snapshots\";i:17;s:25:\"Set custom backup folders\";i:18;s:22:\"Downloadable log files\";i:19;s:24:\"Simple one-click restore\";i:20;s:26:\"Utilize standard WP tables\";i:21;s:11:\"Mirror sync\";i:22;s:30:\"Set number of backups to store\";i:23;s:34:\"Automatically remove oldest backup\";i:24;s:19:\"Dropbox integration\";i:25;s:21:\"Amazon S3 integration\";i:26;s:24:\"FTP and SFTP integration\";i:27;s:24:\"Google Drive integration\";}s:7:\"version\";s:3:\"3.3\";s:17:\"free_version_slug\";s:0:\"\";s:10:\"autoupdate\";s:1:\"1\";s:6:\"active\";b:1;s:10:\"compatible\";s:65:\"WordPress 5.6.2, Multisite 5.6.2, BuddyPress 7.2.0, Upfront 1.9.4\";s:8:\"requires\";s:2:\"wp\";s:3:\"url\";s:48:\"https://premium.wpmudev.org/project/snapshot-v3/\";s:9:\"thumbnail\";s:82:\"https://premium.wpmudev.org/wp-content/uploads/2012/02/Snapshot_plugin-280x158.png\";s:16:\"thumbnail_square\";s:80:\"https://premium.wpmudev.org/wp-content/uploads/2012/02/Snapshot_plugin-90x90.png\";s:15:\"thumbnail_large\";s:74:\"https://premium.wpmudev.org/wp-content/uploads/2012/02/Snapshot_plugin.png\";s:5:\"video\";s:41:\"//fast.wistia.net/embed/iframe/7x4kcv4j15\";s:13:\"wp_config_url\";s:37:\"admin.php?page=snapshot_pro_dashboard\";s:13:\"ms_config_url\";s:37:\"admin.php?page=snapshot_pro_dashboard\";s:7:\"package\";i:0;s:11:\"screenshots\";a:4:{i:0;a:2:{s:3:\"url\";s:102:\"https://premium.wpmudev.org/wp-content/uploads/projects/257/screenshots/1315522110_schedule-backup.jpg\";s:4:\"desc\";s:30:\"Schedule backups with Snapshot\";}i:1;a:2:{s:3:\"url\";s:105:\"https://premium.wpmudev.org/wp-content/uploads/projects/257/screenshots/882714582_destinations-backup.jpg\";s:4:\"desc\";s:20:\"Choose a destination\";}i:2;a:2:{s:3:\"url\";s:99:\"https://premium.wpmudev.org/wp-content/uploads/projects/257/screenshots/905771522_snapshot-dash.jpg\";s:4:\"desc\";s:18:\"Snapshot Dashboard\";}i:3;a:2:{s:3:\"url\";s:102:\"https://premium.wpmudev.org/wp-content/uploads/projects/257/screenshots/1953204640_managed-backups.jpg\";s:4:\"desc\";s:15:\"Managed Backups\";}}s:6:\"_order\";i:10;}i:2175128;a:26:{s:2:\"id\";i:2175128;s:4:\"paid\";s:4:\"full\";s:4:\"type\";s:6:\"plugin\";s:4:\"name\";s:11:\"Shipper Pro\";s:8:\"released\";i:1548285368;s:7:\"updated\";i:1614756258;s:9:\"downloads\";s:5:\"96482\";s:10:\"popularity\";s:5:\"13042\";s:17:\"short_description\";s:146:\"Shipper Pro moves WordPress websites with one-click, from host to host, local to production, development to live, top to bottom without using FTP.\";s:8:\"features\";a:20:{i:0;s:17:\"Import and export\";i:1;s:18:\"No FTP/SFTP needed\";i:2;s:23:\"Secure dedicated server\";i:3;s:16:\"Pre-flight check\";i:4;s:21:\"Zip package migration\";i:5;s:21:\"File find and replace\";i:6;s:21:\"Files-by-file porting\";i:7;s:20:\"Large file detection\";i:8;s:22:\"Move from host to host\";i:9;s:23:\"Push from local to live\";i:10;s:21:\"Detailed Shipper Logs\";i:11;s:26:\"Display system Information\";i:12;s:22:\"Runs in the background\";i:13;s:38:\"Destination server configuration check\";i:14;s:18:\"Package size check\";i:15;s:12:\"Source check\";i:16;s:14:\"Location check\";i:17;s:13:\"Package check\";i:18;s:17:\"Migration Filters\";i:19;s:0:\"\";}s:7:\"version\";s:5:\"1.2.6\";s:17:\"free_version_slug\";s:0:\"\";s:10:\"autoupdate\";s:1:\"1\";s:6:\"active\";b:1;s:10:\"compatible\";s:79:\"WordPress 5.6.2, Multisite 5.6.2, BuddyPress 7.2.0, bbPress , WooCommerce 5.0.0\";s:8:\"requires\";s:2:\"wp\";s:3:\"url\";s:48:\"https://premium.wpmudev.org/project/shipper-pro/\";s:9:\"thumbnail\";s:82:\"https://premium.wpmudev.org/wp-content/uploads/2019/01/Shipper-Feature-280x158.png\";s:16:\"thumbnail_square\";s:80:\"https://premium.wpmudev.org/wp-content/uploads/2019/01/Shipper-Feature-90x90.png\";s:15:\"thumbnail_large\";s:74:\"https://premium.wpmudev.org/wp-content/uploads/2019/01/Shipper-Feature.png\";s:5:\"video\";b:0;s:13:\"wp_config_url\";s:22:\"admin.php?page=shipper\";s:13:\"ms_config_url\";s:22:\"admin.php?page=shipper\";s:7:\"package\";i:0;s:11:\"screenshots\";a:4:{i:0;a:2:{s:3:\"url\";s:114:\"https://premium.wpmudev.org/wp-content/uploads/projects/2175128/screenshots/1130594245_shipper-getting-started.png\";s:4:\"desc\";s:23:\"Shipper getting started\";}i:1;a:2:{s:3:\"url\";s:117:\"https://premium.wpmudev.org/wp-content/uploads/projects/2175128/screenshots/1631499311_shipper-system information.png\";s:4:\"desc\";s:33:\"Shipper server system information\";}i:2;a:2:{s:3:\"url\";s:110:\"https://premium.wpmudev.org/wp-content/uploads/projects/2175128/screenshots/36952669_shipper-import-export.png\";s:4:\"desc\";s:25:\"Shipper import and export\";}i:3;a:2:{s:3:\"url\";s:116:\"https://premium.wpmudev.org/wp-content/uploads/projects/2175128/screenshots/1684527269_shipper-migration-options.png\";s:4:\"desc\";s:25:\"Shipper migration options\";}}s:6:\"_order\";i:11;}i:9135;a:26:{s:2:\"id\";i:9135;s:4:\"paid\";s:4:\"paid\";s:4:\"type\";s:6:\"plugin\";s:4:\"name\";s:10:\"Branda Pro\";s:8:\"released\";i:1339280384;s:7:\"updated\";i:1611653906;s:9:\"downloads\";s:6:\"583998\";s:10:\"popularity\";s:5:\"53428\";s:17:\"short_description\";s:87:\"White label WordPress branding for both the front and back end of your site or network.\";s:8:\"features\";a:43:{i:0;s:25:\"Remove WordPress branding\";i:1;s:21:\"Highlight your design\";i:2;s:32:\"Add custom logo to the Admin Bar\";i:3;s:33:\"Simple WordPress logo replacement\";i:4;s:26:\"Create custom login screen\";i:5;s:28:\"Replace the word \"WordPress\"\";i:6;s:21:\"Simple brand matching\";i:7;s:21:\"Import/Export setting\";i:8;s:26:\"Reorganize Admin Bar menus\";i:9;s:26:\"Set custom Admin Bar menus\";i:10;s:28:\"Add a direct link to support\";i:11;s:16:\"Add help buttons\";i:12;s:29:\"Send system emails using SMTP\";i:13;s:29:\"Remove core Dashboard widgets\";i:14;s:32:\"Hide 3rd-party dashboard widgets\";i:15;s:29:\"Replace the WordPress \'Howdy\'\";i:16;s:28:\"Coming Soon/Maintenance Mode\";i:17;s:30:\"Customize \'Admin Help Content\'\";i:18;s:32:\"Increase site security and speed\";i:19;s:27:\"One plugin for all settings\";i:20;s:25:\"Create a custom admin bar\";i:21;s:24:\"Set \"From\" Email address\";i:22;s:15:\"Multisite ready\";i:23;s:26:\"Customize/add help content\";i:24;s:20:\"Custom global footer\";i:25;s:20:\"Custom global header\";i:26;s:23:\"Custom dashboard footer\";i:27;s:23:\"Rebrand the meta widget\";i:28;s:22:\"Protect site structure\";i:29;s:28:\"Custom DB error landing page\";i:30;s:27:\"Hide \'Permalinks\' menu item\";i:31;s:25:\"Replace WordPress in HTML\";i:32;s:26:\"Replace any word or phrase\";i:33;s:20:\"Set a custom Favicon\";i:34;s:28:\"Easily insert tracking codes\";i:35;s:25:\"Custom Multisite Favicons\";i:36;s:19:\"Customize admin CSS\";i:37;s:21:\"Uses CSS child fields\";i:38;s:22:\"Hide WordPress welcome\";i:39;s:34:\"Add custom dashboard color schemes\";i:40;s:29:\"Display custom admin messages\";i:41;s:30:\"Add Author Boxes to your posts\";i:42;s:31:\"Fully customize your admin menu\";}s:7:\"version\";s:5:\"3.4.3\";s:17:\"free_version_slug\";s:0:\"\";s:10:\"autoupdate\";s:1:\"1\";s:6:\"active\";b:1;s:10:\"compatible\";s:65:\"WordPress 5.6.2, Multisite 5.6.2, BuddyPress 7.2.0, Upfront 1.9.4\";s:8:\"requires\";s:2:\"wp\";s:3:\"url\";s:54:\"https://premium.wpmudev.org/project/ultimate-branding/\";s:9:\"thumbnail\";s:79:\"https://premium.wpmudev.org/wp-content/uploads/2012/06/branda-large-280x158.png\";s:16:\"thumbnail_square\";s:77:\"https://premium.wpmudev.org/wp-content/uploads/2012/06/branda-large-90x90.png\";s:15:\"thumbnail_large\";s:71:\"https://premium.wpmudev.org/wp-content/uploads/2012/06/branda-large.png\";s:5:\"video\";s:41:\"//fast.wistia.net/embed/iframe/v9l5fs1cgs\";s:13:\"wp_config_url\";s:23:\"admin.php?page=branding\";s:13:\"ms_config_url\";s:23:\"admin.php?page=branding\";s:7:\"package\";i:0;s:11:\"screenshots\";a:4:{i:0;a:2:{s:3:\"url\";s:104:\"https://premium.wpmudev.org/wp-content/uploads/projects/9135/screenshots/branda-custom-login-screens.png\";s:4:\"desc\";s:27:\"Branda custom login screens\";}i:1;a:2:{s:3:\"url\";s:99:\"https://premium.wpmudev.org/wp-content/uploads/projects/9135/screenshots/branda-email-templates.png\";s:4:\"desc\";s:22:\"Branda email templates\";}i:2;a:2:{s:3:\"url\";s:105:\"https://premium.wpmudev.org/wp-content/uploads/projects/9135/screenshots/branda-feed-dashboard-widget.png\";s:4:\"desc\";s:22:\"Branda dashboard feeds\";}i:3;a:2:{s:3:\"url\";s:90:\"https://premium.wpmudev.org/wp-content/uploads/projects/9135/screenshots/branda-social.png\";s:4:\"desc\";s:27:\"Branda social share options\";}}s:6:\"_order\";i:12;}i:51;a:26:{s:2:\"id\";i:51;s:4:\"paid\";s:4:\"paid\";s:4:\"type\";s:6:\"plugin\";s:4:\"name\";s:11:\"Beehive Pro\";s:8:\"released\";i:1235347220;s:7:\"updated\";i:1614860424;s:9:\"downloads\";s:6:\"450134\";s:10:\"popularity\";s:5:\"48557\";s:17:\"short_description\";s:94:\"Customizable Google Analytics dashboards, statistics, and reports for WordPress and Multisite.\";s:8:\"features\";a:18:{i:0;s:29:\"Simple one-click setup wizard\";i:1;s:30:\"Powerful Multisite integration\";i:2;s:39:\"One tracking code for an entire network\";i:3;s:38:\"Individual post/page statistics viewer\";i:4;s:17:\"Customize reports\";i:5;s:20:\"Anonymize IP masking\";i:6;s:26:\"Analytics dashboard widget\";i:7;s:38:\"Google Display Advertising integration\";i:8;s:26:\"Statistics overview screen\";i:9;s:31:\"Limit access based on user role\";i:10;s:28:\"Toggle statistics date range\";i:11;s:35:\"Track visits, page views and trends\";i:12;s:34:\"See visit duration and bounce rate\";i:13;s:41:\"Track top post, pages and referring links\";i:14;s:34:\"World map with visitors by country\";i:15;s:32:\"Graphs for fast visual reference\";i:16;s:23:\"Collect sub-domain data\";i:17;s:21:\"Tracks mapped domains\";}s:7:\"version\";s:5:\"3.3.8\";s:17:\"free_version_slug\";s:17:\"beehive-analytics\";s:10:\"autoupdate\";s:1:\"1\";s:6:\"active\";b:1;s:10:\"compatible\";s:50:\"WordPress 5.6.2, Multisite 5.6.2, BuddyPress 7.2.0\";s:8:\"requires\";s:2:\"wp\";s:3:\"url\";s:58:\"https://premium.wpmudev.org/project/beehive-analytics-pro/\";s:9:\"thumbnail\";s:95:\"https://premium.wpmudev.org/wp-content/uploads/2019/10/beehive-featured-placeholder-280x158.png\";s:16:\"thumbnail_square\";s:93:\"https://premium.wpmudev.org/wp-content/uploads/2019/10/beehive-featured-placeholder-90x90.png\";s:15:\"thumbnail_large\";s:87:\"https://premium.wpmudev.org/wp-content/uploads/2019/10/beehive-featured-placeholder.png\";s:5:\"video\";s:41:\"//fast.wistia.net/embed/iframe/iu6g2umvu8\";s:13:\"wp_config_url\";s:31:\"admin.php?page=beehive-settings\";s:13:\"ms_config_url\";s:31:\"admin.php?page=beehive-settings\";s:7:\"package\";i:0;s:11:\"screenshots\";a:4:{i:0;a:2:{s:3:\"url\";s:93:\"https://premium.wpmudev.org/wp-content/uploads/projects/51/screenshots/beehive-comparison.png\";s:4:\"desc\";s:17:\"analytic overview\";}i:1;a:2:{s:3:\"url\";s:89:\"https://premium.wpmudev.org/wp-content/uploads/projects/51/screenshots/beehive-medium.png\";s:4:\"desc\";s:14:\"Beehive medium\";}i:2;a:2:{s:3:\"url\";s:92:\"https://premium.wpmudev.org/wp-content/uploads/projects/51/screenshots/beehive-user-data.png\";s:4:\"desc\";s:23:\"Beehive comparison data\";}i:3;a:2:{s:3:\"url\";s:92:\"https://premium.wpmudev.org/wp-content/uploads/projects/51/screenshots/beehive-user-role.png\";s:4:\"desc\";s:22:\"User roles for beehive\";}}s:6:\"_order\";i:13;}i:248;a:26:{s:2:\"id\";i:248;s:4:\"paid\";s:4:\"full\";s:4:\"type\";s:6:\"plugin\";s:4:\"name\";s:26:\"Integrated Video Tutorials\";s:8:\"released\";i:1318459013;s:7:\"updated\";i:1611692121;s:9:\"downloads\";s:6:\"149255\";s:10:\"popularity\";s:5:\"10388\";s:17:\"short_description\";s:81:\"Complete, quality, always up-to-date list of unbranded WordPress training videos.\";s:8:\"features\";a:23:{i:0;s:20:\"Register your domain\";i:1;s:32:\"+45 included WordPress tutorials\";i:2;s:32:\"Automatically add videos to help\";i:3;s:17:\"Verify connection\";i:4;s:14:\"Hide menu item\";i:5;s:19:\"Customize menu name\";i:6;s:30:\"Give setup permission to users\";i:7;s:32:\"Hide access to individual videos\";i:8;s:17:\"Add custom videos\";i:9;s:14:\"Wistia support\";i:10;s:15:\"YouTube support\";i:11;s:13:\"Vimeo support\";i:12;s:21:\"Shortcode embed codes\";i:13;s:22:\"Customizable playlists\";i:14;s:11:\"Group embed\";i:15;s:15:\"Front end embed\";i:16;s:18:\"Quality production\";i:17;s:25:\"Automatic content updates\";i:18;s:20:\"White label branding\";i:19;s:19:\"Unlimited bandwidth\";i:20;s:15:\"Unlimited plays\";i:21;s:14:\"SSL compatible\";i:22;s:21:\"Multisite integration\";}s:7:\"version\";s:5:\"1.8.5\";s:17:\"free_version_slug\";s:0:\"\";s:10:\"autoupdate\";s:1:\"1\";s:6:\"active\";b:1;s:10:\"compatible\";s:50:\"WordPress 5.6.2, Multisite 5.6.2, BuddyPress 7.2.0\";s:8:\"requires\";s:2:\"wp\";s:3:\"url\";s:62:\"https://premium.wpmudev.org/project/unbranded-video-tutorials/\";s:9:\"thumbnail\";s:94:\"https://premium.wpmudev.org/wp-content/uploads/2011/10/Integration-Video-Tutorials-280x158.png\";s:16:\"thumbnail_square\";s:92:\"https://premium.wpmudev.org/wp-content/uploads/2011/10/Integration-Video-Tutorials-90x90.png\";s:15:\"thumbnail_large\";s:86:\"https://premium.wpmudev.org/wp-content/uploads/2011/10/Integration-Video-Tutorials.png\";s:5:\"video\";s:41:\"//fast.wistia.net/embed/iframe/c5b01yf5xw\";s:13:\"wp_config_url\";s:39:\"options-general.php?page=wpmudev-videos\";s:13:\"ms_config_url\";s:32:\"settings.php?page=wpmudev-videos\";s:7:\"package\";i:0;s:11:\"screenshots\";a:3:{i:0;a:2:{s:3:\"url\";s:108:\"https://premium.wpmudev.org/wp-content/uploads/projects/248/screenshots/843594149_video-settings-735x470.jpg\";s:4:\"desc\";s:10:\"Easy setup\";}i:1;a:2:{s:3:\"url\";s:100:\"https://premium.wpmudev.org/wp-content/uploads/projects/248/screenshots/1005196382_icons-735x470.jpg\";s:4:\"desc\";s:15:\"A ton of videos\";}i:2;a:2:{s:3:\"url\";s:107:\"https://premium.wpmudev.org/wp-content/uploads/projects/248/screenshots/1978520080_video-player-735x470.jpg\";s:4:\"desc\";s:19:\"Videos in dashboard\";}}s:6:\"_order\";i:14;}i:938297;a:25:{s:2:\"id\";i:938297;s:4:\"paid\";s:4:\"paid\";s:4:\"type\";s:5:\"theme\";s:4:\"name\";s:7:\"Upfront\";s:8:\"released\";i:1421124646;s:7:\"updated\";i:1524768151;s:9:\"downloads\";s:6:\"121696\";s:10:\"popularity\";s:4:\"3239\";s:17:\"short_description\";s:145:\"A versatile and infinitely customizable drag-and-drop WordPress theme platform for use with any child theme in the growing Upfront theme library.\";s:8:\"features\";a:0:{}s:7:\"version\";s:5:\"1.9.4\";s:17:\"free_version_slug\";s:0:\"\";s:10:\"autoupdate\";s:1:\"1\";s:6:\"active\";b:1;s:10:\"compatible\";s:32:\"WordPress 5.6.2, Multisite 5.6.2\";s:8:\"requires\";s:2:\"wp\";s:3:\"url\";s:44:\"https://premium.wpmudev.org/project/upfront/\";s:9:\"thumbnail\";s:74:\"https://premium.wpmudev.org/wp-content/uploads/2015/01/upfront-280x158.jpg\";s:16:\"thumbnail_square\";s:72:\"https://premium.wpmudev.org/wp-content/uploads/2015/01/upfront-90x90.jpg\";s:15:\"thumbnail_large\";s:66:\"https://premium.wpmudev.org/wp-content/uploads/2015/01/upfront.jpg\";s:5:\"video\";b:0;s:13:\"wp_config_url\";s:0:\"\";s:13:\"ms_config_url\";s:0:\"\";s:7:\"package\";i:0;s:6:\"_order\";i:15;}}s:11:\"plugin_tags\";a:6:{i:489;a:3:{s:4:\"name\";s:31:\"BuddyPress Plugins &amp; Themes\";s:5:\"count\";i:5;s:4:\"pids\";a:5:{i:0;s:3:\"167\";i:1;s:4:\"9135\";i:2;s:3:\"257\";i:3;s:2:\"51\";i:4;s:3:\"248\";}}i:32;a:3:{s:4:\"name\";s:26:\"WordPress Business Plugins\";s:5:\"count\";i:5;s:4:\"pids\";a:5:{i:0;s:7:\"1107020\";i:1;s:3:\"167\";i:2;s:4:\"9135\";i:3;s:3:\"248\";i:4;s:7:\"2097296\";}}i:498;a:3:{s:4:\"name\";s:27:\"WordPress Marketing Plugins\";s:5:\"count\";i:3;s:4:\"pids\";a:3:{i:0;s:7:\"1107020\";i:1;s:3:\"167\";i:2;s:7:\"2097296\";}}i:16;a:3:{s:4:\"name\";s:27:\"WordPress Multisite Plugins\";s:5:\"count\";i:9;s:4:\"pids\";a:9:{i:0;s:6:\"912164\";i:1;s:7:\"1081721\";i:2;s:7:\"1081723\";i:3;s:3:\"167\";i:4;s:3:\"257\";i:5;s:7:\"1107020\";i:6;s:4:\"9135\";i:7;s:2:\"51\";i:8;s:3:\"248\";}}i:31;a:3:{s:4:\"name\";s:28:\"WordPress Publishing Plugins\";s:5:\"count\";i:3;s:4:\"pids\";a:3:{i:0;s:6:\"912164\";i:1;s:3:\"167\";i:2;s:3:\"257\";}}i:50;a:3:{s:4:\"name\";s:21:\"WordPress SEO Plugins\";s:5:\"count\";i:5;s:4:\"pids\";a:5:{i:0;s:7:\"1107020\";i:1;s:3:\"167\";i:2;s:7:\"1081721\";i:3;s:4:\"9135\";i:4;s:2:\"51\";}}}s:11:\"free_notice\";N;s:13:\"single_notice\";N;s:11:\"full_notice\";a:3:{s:4:\"time\";i:1509947375;s:3:\"msg\";s:270:\"<strong>We\'ve pushed all-new updates to The Hub!</strong><br />What\'s The Hub? Only the best way to manage all your sites in one place! Login to your WPMU DEV account to check out the new features. <a href=\"https://premium.wpmudev.org/hub/my-websites/\">Go to The Hub</a>\";s:6:\"author\";i:164650;}}','no');
INSERT INTO `wp_options` VALUES (161,'wdp_un_profile_data','a:3:{s:5:\"forum\";a:1:{s:15:\"support_threads\";a:5:{i:0;a:7:{s:5:\"title\";s:43:\"clone content to replace existing page copy\";s:4:\"link\";s:85:\"https://premium.wpmudev.org/forums/topic/clone-content-to-replace-existing-page-copy/\";s:9:\"timestamp\";s:10:\"1450387398\";s:4:\"user\";s:4:\"Jude\";s:6:\"status\";s:12:\"not_resolved\";s:6:\"unread\";b:1;s:5:\"posts\";i:1;}i:1;a:7:{s:5:\"title\";s:46:\"Is it possible to restart smush server request\";s:4:\"link\";s:88:\"https://premium.wpmudev.org/forums/topic/is-it-possible-to-restart-smush-server-request/\";s:9:\"timestamp\";s:10:\"1422550914\";s:4:\"user\";s:7:\"Vaughan\";s:6:\"status\";s:12:\"not_resolved\";s:6:\"unread\";b:1;s:5:\"posts\";i:1;}i:2;a:7:{s:5:\"title\";s:66:\"Migrating blog content from one multisite to the other selectively\";s:4:\"link\";s:108:\"https://premium.wpmudev.org/forums/topic/migrating-blog-content-from-one-multisite-to-the-other-selectively/\";s:9:\"timestamp\";s:10:\"1416024640\";s:4:\"user\";s:10:\"Matt Adams\";s:6:\"status\";s:8:\"resolved\";s:6:\"unread\";b:0;s:5:\"posts\";i:4;}i:3;a:7:{s:5:\"title\";s:50:\"moving a multisite install redirection loop errors\";s:4:\"link\";s:92:\"https://premium.wpmudev.org/forums/topic/moving-a-multisite-install-redirection-loop-errors/\";s:9:\"timestamp\";s:10:\"1413727409\";s:4:\"user\";s:8:\"aristath\";s:6:\"status\";s:8:\"resolved\";s:6:\"unread\";b:1;s:5:\"posts\";i:4;}i:4;a:7:{s:5:\"title\";s:56:\"Can we bulk import thousands of giftcards? We would like\";s:4:\"link\";s:97:\"https://premium.wpmudev.org/forums/topic/can-we-bulk-import-thousands-of-giftcards-we-would-like/\";s:9:\"timestamp\";s:10:\"1413410421\";s:4:\"user\";s:11:\"Vinod Dalvi\";s:6:\"status\";s:12:\"not_resolved\";s:6:\"unread\";b:1;s:5:\"posts\";i:1;}}}s:7:\"profile\";a:5:{s:4:\"name\";s:4:\"Matt\";s:9:\"user_name\";s:28:\"mattadams@factor1studios.com\";s:12:\"member_since\";i:1390328333;s:6:\"avatar\";s:185:\"https://premium.wpmudev.org/avatar/0ab18c7f77efd9222037b41eacdbdd4d?s=150&d=https%3A%2F%2Fpremium.wpmudev.org%2Fwp-content%2Fthemes%2Fwpmudev-2015-1%2Fassets%2Fimg%2Favatars%2F0.png&r=g\";s:5:\"title\";s:4:\"Gold\";}s:6:\"points\";a:4:{s:10:\"rep_points\";i:26;s:7:\"history\";a:4:{i:0;a:7:{s:4:\"type\";s:3:\"rep\";s:9:\"timestamp\";s:10:\"1522432778\";s:6:\"points\";s:1:\"1\";s:11:\"reason_code\";s:13:\"forum_comment\";s:6:\"reason\";s:164:\"You commented on the discussion <a href=\'https://premium.wpmudev.org/forums/topic/ab-split-testing-a-couple-pages#post-1311204\'>A/B split testing a couple pages</a>\";s:9:\"object_id\";s:7:\"3587927\";s:9:\"from_user\";s:1:\"0\";}i:1;a:7:{s:4:\"type\";s:3:\"rep\";s:9:\"timestamp\";s:10:\"1467129405\";s:6:\"points\";s:1:\"1\";s:11:\"reason_code\";s:13:\"forum_comment\";s:6:\"reason\";s:136:\"You commented on the discussion <a href=\'https://premium.wpmudev.org/forums/topic/i-love-wpmud-but#post-1103952\'>I love WPMUD but...</a>\";s:9:\"object_id\";s:7:\"3429193\";s:9:\"from_user\";s:1:\"0\";}i:2;a:7:{s:4:\"type\";s:3:\"rep\";s:9:\"timestamp\";s:10:\"1458328290\";s:6:\"points\";s:1:\"1\";s:11:\"reason_code\";s:13:\"forum_comment\";s:6:\"reason\";s:209:\"You commented on the discussion <a href=\'https://premium.wpmudev.org/forums/topic/what-affilate-plugins-should-i-use-what-are-you-using#post-1049456\'>What Affilate Plugins should I use? What are you using?</a>\";s:9:\"object_id\";s:7:\"3385108\";s:9:\"from_user\";s:1:\"0\";}i:3;a:7:{s:4:\"type\";s:3:\"rep\";s:9:\"timestamp\";s:10:\"1456857613\";s:6:\"points\";s:1:\"1\";s:11:\"reason_code\";s:13:\"forum_comment\";s:6:\"reason\";s:190:\"You commented on the discussion <a href=\'https://premium.wpmudev.org/forums/topic/do-you-use-any-wordpress-maintenance-service#post-1040515\'>Do you use any WordPress maintenance service?</a>\";s:9:\"object_id\";s:7:\"3362689\";s:9:\"from_user\";s:1:\"0\";}}s:11:\"hero_points\";i:120;s:9:\"rep_level\";a:4:{s:4:\"base\";i:25;s:5:\"level\";i:2;s:4:\"name\";s:72:\"Unlock <a href=\"/hub/profile\" target=\"_blank\">custom community title</a>\";s:5:\"title\";s:11:\"Flash Drive\";}}}','no');
INSERT INTO `wp_options` VALUES (162,'wdp_un_farm133_themes','a:0:{}','no');
INSERT INTO `wp_options` VALUES (163,'wdp_un_updates_available','a:0:{}','no');
INSERT INTO `wp_options` VALUES (164,'wdp_un_last_run_updates','1614883496','no');
INSERT INTO `wp_options` VALUES (165,'wdp_un_last_run_profile','1590529810','no');
INSERT INTO `wp_options` VALUES (166,'wdp_un_last_check_upfront','0','no');
INSERT INTO `wp_options` VALUES (167,'wdp_un_staff_notes','','no');
INSERT INTO `wp_options` VALUES (168,'wdp_un_redirected_v4','1','no');
INSERT INTO `wp_options` VALUES (169,'wdp_un_autoupdate_dashboard','1','no');
INSERT INTO `wp_options` VALUES (170,'wdp_un_notifications','a:0:{}','no');
INSERT INTO `wp_options` VALUES (171,'wdp_un_auth_user','mattadams@factor1studios.com','no');
INSERT INTO `wp_options` VALUES (172,'wdp_un_whitelabel_enabled','','no');
INSERT INTO `wp_options` VALUES (173,'wdp_un_whitelabel_branding_enabled','','no');
INSERT INTO `wp_options` VALUES (174,'wdp_un_whitelabel_branding_image','','no');
INSERT INTO `wp_options` VALUES (175,'wdp_un_whitelabel_footer_enabled','','no');
INSERT INTO `wp_options` VALUES (176,'wdp_un_whitelabel_footer_text','','no');
INSERT INTO `wp_options` VALUES (177,'wdp_un_whitelabel_doc_links_enabled','','no');
INSERT INTO `wp_options` VALUES (178,'wdp_un_analytics_enabled','','no');
INSERT INTO `wp_options` VALUES (179,'wdp_un_analytics_role','administrator','no');
INSERT INTO `wp_options` VALUES (180,'wpseo','a:42:{s:8:\"tracking\";b:0;s:22:\"license_server_version\";i:2;s:15:\"ms_defaults_set\";b:0;s:40:\"ignore_search_engines_discouraged_notice\";b:1;s:19:\"indexing_first_time\";b:1;s:16:\"indexing_started\";b:0;s:15:\"indexing_reason\";s:0:\"\";s:29:\"indexables_indexing_completed\";b:1;s:7:\"version\";s:6:\"15.9.1\";s:16:\"previous_version\";s:4:\"14.2\";s:20:\"disableadvanced_meta\";b:1;s:30:\"enable_headless_rest_endpoints\";b:1;s:17:\"ryte_indexability\";b:1;s:11:\"baiduverify\";s:0:\"\";s:12:\"googleverify\";s:0:\"\";s:8:\"msverify\";s:0:\"\";s:12:\"yandexverify\";s:0:\"\";s:9:\"site_type\";s:0:\"\";s:20:\"has_multiple_authors\";s:0:\"\";s:16:\"environment_type\";s:0:\"\";s:23:\"content_analysis_active\";b:1;s:23:\"keyword_analysis_active\";b:1;s:21:\"enable_admin_bar_menu\";b:1;s:26:\"enable_cornerstone_content\";b:1;s:18:\"enable_xml_sitemap\";b:1;s:24:\"enable_text_link_counter\";b:1;s:22:\"show_onboarding_notice\";b:1;s:18:\"first_activated_on\";i:1590526051;s:13:\"myyoast-oauth\";b:0;s:26:\"semrush_integration_active\";b:1;s:14:\"semrush_tokens\";a:0:{}s:20:\"semrush_country_code\";s:2:\"us\";s:19:\"permalink_structure\";s:12:\"/%postname%/\";s:8:\"home_url\";s:22:\"http://localhost:10008\";s:18:\"dynamic_permalinks\";b:0;s:17:\"category_base_url\";s:0:\"\";s:12:\"tag_base_url\";s:0:\"\";s:21:\"custom_taxonomy_slugs\";a:0:{}s:29:\"enable_enhanced_slack_sharing\";b:1;s:25:\"zapier_integration_active\";b:0;s:19:\"zapier_subscription\";a:0:{}s:14:\"zapier_api_key\";s:0:\"\";}','yes');
INSERT INTO `wp_options` VALUES (181,'wpseo_titles','a:70:{s:17:\"forcerewritetitle\";b:0;s:9:\"separator\";s:7:\"sc-dash\";s:16:\"title-home-wpseo\";s:42:\"%%sitename%% %%page%% %%sep%% %%sitedesc%%\";s:18:\"title-author-wpseo\";s:41:\"%%name%%, Author at %%sitename%% %%page%%\";s:19:\"title-archive-wpseo\";s:38:\"%%date%% %%page%% %%sep%% %%sitename%%\";s:18:\"title-search-wpseo\";s:63:\"You searched for %%searchphrase%% %%page%% %%sep%% %%sitename%%\";s:15:\"title-404-wpseo\";s:35:\"Page not found %%sep%% %%sitename%%\";s:19:\"metadesc-home-wpseo\";s:0:\"\";s:21:\"metadesc-author-wpseo\";s:0:\"\";s:22:\"metadesc-archive-wpseo\";s:0:\"\";s:9:\"rssbefore\";s:0:\"\";s:8:\"rssafter\";s:53:\"The post %%POSTLINK%% appeared first on %%BLOGLINK%%.\";s:20:\"noindex-author-wpseo\";b:0;s:28:\"noindex-author-noposts-wpseo\";b:1;s:21:\"noindex-archive-wpseo\";b:1;s:14:\"disable-author\";b:0;s:12:\"disable-date\";b:0;s:19:\"disable-post_format\";b:0;s:18:\"disable-attachment\";b:1;s:23:\"is-media-purge-relevant\";b:0;s:20:\"breadcrumbs-404crumb\";s:25:\"Error 404: Page not found\";s:29:\"breadcrumbs-display-blog-page\";b:1;s:20:\"breadcrumbs-boldlast\";b:0;s:25:\"breadcrumbs-archiveprefix\";s:12:\"Archives for\";s:18:\"breadcrumbs-enable\";b:0;s:16:\"breadcrumbs-home\";s:4:\"Home\";s:18:\"breadcrumbs-prefix\";s:0:\"\";s:24:\"breadcrumbs-searchprefix\";s:16:\"You searched for\";s:15:\"breadcrumbs-sep\";s:7:\"&raquo;\";s:12:\"website_name\";s:0:\"\";s:11:\"person_name\";s:0:\"\";s:11:\"person_logo\";s:0:\"\";s:14:\"person_logo_id\";i:0;s:22:\"alternate_website_name\";s:0:\"\";s:12:\"company_logo\";s:0:\"\";s:15:\"company_logo_id\";i:0;s:12:\"company_name\";s:0:\"\";s:17:\"company_or_person\";s:7:\"company\";s:25:\"company_or_person_user_id\";b:0;s:17:\"stripcategorybase\";b:0;s:10:\"title-post\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:13:\"metadesc-post\";s:0:\"\";s:12:\"noindex-post\";b:0;s:13:\"showdate-post\";b:0;s:23:\"display-metabox-pt-post\";b:1;s:23:\"post_types-post-maintax\";i:0;s:10:\"title-page\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:13:\"metadesc-page\";s:0:\"\";s:12:\"noindex-page\";b:0;s:13:\"showdate-page\";b:0;s:23:\"display-metabox-pt-page\";b:1;s:23:\"post_types-page-maintax\";i:0;s:16:\"title-attachment\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:19:\"metadesc-attachment\";s:0:\"\";s:18:\"noindex-attachment\";b:0;s:19:\"showdate-attachment\";b:0;s:29:\"display-metabox-pt-attachment\";b:1;s:29:\"post_types-attachment-maintax\";i:0;s:18:\"title-tax-category\";s:53:\"%%term_title%% Archives %%page%% %%sep%% %%sitename%%\";s:21:\"metadesc-tax-category\";s:0:\"\";s:28:\"display-metabox-tax-category\";b:1;s:20:\"noindex-tax-category\";b:0;s:18:\"title-tax-post_tag\";s:53:\"%%term_title%% Archives %%page%% %%sep%% %%sitename%%\";s:21:\"metadesc-tax-post_tag\";s:0:\"\";s:28:\"display-metabox-tax-post_tag\";b:1;s:20:\"noindex-tax-post_tag\";b:0;s:21:\"title-tax-post_format\";s:53:\"%%term_title%% Archives %%page%% %%sep%% %%sitename%%\";s:24:\"metadesc-tax-post_format\";s:0:\"\";s:31:\"display-metabox-tax-post_format\";b:1;s:23:\"noindex-tax-post_format\";b:1;}','yes');
INSERT INTO `wp_options` VALUES (182,'wpseo_social','a:18:{s:13:\"facebook_site\";s:0:\"\";s:13:\"instagram_url\";s:0:\"\";s:12:\"linkedin_url\";s:0:\"\";s:11:\"myspace_url\";s:0:\"\";s:16:\"og_default_image\";s:0:\"\";s:19:\"og_default_image_id\";s:0:\"\";s:18:\"og_frontpage_title\";s:0:\"\";s:17:\"og_frontpage_desc\";s:0:\"\";s:18:\"og_frontpage_image\";s:0:\"\";s:21:\"og_frontpage_image_id\";s:0:\"\";s:9:\"opengraph\";b:1;s:13:\"pinterest_url\";s:0:\"\";s:15:\"pinterestverify\";s:0:\"\";s:7:\"twitter\";b:1;s:12:\"twitter_site\";s:0:\"\";s:17:\"twitter_card_type\";s:19:\"summary_large_image\";s:11:\"youtube_url\";s:0:\"\";s:13:\"wikipedia_url\";s:0:\"\";}','yes');
INSERT INTO `wp_options` VALUES (183,'wpseo_flush_rewrite','1','yes');
INSERT INTO `wp_options` VALUES (188,'smush_global_stats','a:9:{s:11:\"size_before\";i:0;s:10:\"size_after\";i:0;s:7:\"percent\";d:0;s:5:\"human\";s:5:\"0.0 B\";s:5:\"bytes\";i:0;s:12:\"total_images\";i:0;s:12:\"resize_count\";i:0;s:14:\"resize_savings\";i:0;s:18:\"conversion_savings\";i:0;}','no');
INSERT INTO `wp_options` VALUES (189,'wdp_un_membership_data','a:6:{s:10:\"membership\";s:4:\"full\";s:21:\"membership_full_level\";s:4:\"gold\";s:28:\"membership_excluded_projects\";a:0:{}s:17:\"membership_access\";b:1;s:8:\"services\";a:3:{s:6:\"uptime\";i:0;s:8:\"automate\";b:1;s:7:\"reports\";i:0;}s:11:\"hub_site_id\";s:7:\"1637441\";}','no');
INSERT INTO `wp_options` VALUES (190,'wdp_un_last_run_sync','a:3:{s:4:\"time\";i:1614883954;s:4:\"hash\";s:32:\"1a8ce3c8aa3feef7e987343a940af369\";s:5:\"fails\";i:0;}','no');
INSERT INTO `wp_options` VALUES (191,'wdp_un_translation_updates_available','a:0:{}','no');
INSERT INTO `wp_options` VALUES (192,'wpmdb_settings','a:13:{s:3:\"key\";s:40:\"dco6qDRXGL9zcWUzZ/ORFN4sE4ndiIs9l1U9oi/P\";s:10:\"allow_pull\";b:0;s:10:\"allow_push\";b:0;s:8:\"profiles\";a:0:{}s:7:\"licence\";s:36:\"ffc6795e-b75f-4fbc-b274-7a6c0c97864e\";s:10:\"verify_ssl\";b:0;s:17:\"whitelist_plugins\";a:0:{}s:11:\"max_request\";i:1048576;s:22:\"delay_between_requests\";i:0;s:18:\"prog_tables_hidden\";b:1;s:21:\"pause_before_finalize\";b:0;s:14:\"allow_tracking\";N;s:28:\"compatibility_plugin_version\";s:3:\"1.2\";}','no');
INSERT INTO `wp_options` VALUES (193,'yoast_migrations_free','a:1:{s:7:\"version\";s:6:\"15.9.1\";}','yes');
INSERT INTO `wp_options` VALUES (194,'_transient_timeout_wpseo_link_table_inaccessible','1622062053','no');
INSERT INTO `wp_options` VALUES (195,'_transient_wpseo_link_table_inaccessible','0','no');
INSERT INTO `wp_options` VALUES (196,'_transient_timeout_wpseo_meta_table_inaccessible','1622062053','no');
INSERT INTO `wp_options` VALUES (197,'_transient_wpseo_meta_table_inaccessible','0','no');
INSERT INTO `wp_options` VALUES (198,'widget_gform_widget','a:1:{s:12:\"_multiwidget\";i:1;}','yes');
INSERT INTO `wp_options` VALUES (200,'gravityformsaddon_gravityformswebapi_version','1.0','yes');
INSERT INTO `wp_options` VALUES (203,'gform_version_info','a:11:{s:12:\"is_valid_key\";b:1;s:6:\"reason\";s:0:\"\";s:7:\"version\";s:6:\"2.4.23\";s:3:\"url\";s:166:\"https://s3.amazonaws.com/gravityforms/releases/gravityforms_2.4.23.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=3O8GYqWIAQoKEPbcxvUxbTJBzWE%3D\";s:15:\"expiration_time\";i:1620230400;s:9:\"offerings\";a:58:{s:12:\"gravityforms\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:6:\"2.4.23\";s:14:\"version_latest\";s:6:\"2.4.23\";s:3:\"url\";s:166:\"https://s3.amazonaws.com/gravityforms/releases/gravityforms_2.4.23.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=3O8GYqWIAQoKEPbcxvUxbTJBzWE%3D\";s:10:\"url_latest\";s:166:\"https://s3.amazonaws.com/gravityforms/releases/gravityforms_2.4.23.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=3O8GYqWIAQoKEPbcxvUxbTJBzWE%3D\";}s:21:\"gravityforms2checkout\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"2.0\";s:14:\"version_latest\";s:5:\"2.0.1\";s:3:\"url\";s:184:\"https://s3.amazonaws.com/gravityforms/addons/2checkout/gravityforms2checkout_2.0.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=SLaFHbrygI1%2Ba9HXLwZlfO%2BExgY%3D\";s:10:\"url_latest\";s:184:\"https://s3.amazonaws.com/gravityforms/addons/2checkout/gravityforms2checkout_2.0.1.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=i%2BmHMFa0VOowokrU4k9JvyAg9u0%3D\";}s:26:\"gravityformsactivecampaign\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"1.8\";s:14:\"version_latest\";s:3:\"1.8\";s:3:\"url\";s:190:\"https://s3.amazonaws.com/gravityforms/addons/activecampaign/gravityformsactivecampaign_1.8.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=tZVo0pQYUmsyiZPjqrRqi3ZJNxU%3D\";s:10:\"url_latest\";s:190:\"https://s3.amazonaws.com/gravityforms/addons/activecampaign/gravityformsactivecampaign_1.8.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=tZVo0pQYUmsyiZPjqrRqi3ZJNxU%3D\";}s:32:\"gravityformsadvancedpostcreation\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:10:\"1.0-beta-7\";s:14:\"version_latest\";s:12:\"1.0-beta-7.2\";s:3:\"url\";s:211:\"https://s3.amazonaws.com/gravityforms/addons/advancedpostcreation/gravityformsadvancedpostcreation_1.0-beta-7.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=KFZO6Xgu5QZfkHtUOBAOR%2BWeL5o%3D\";s:10:\"url_latest\";s:211:\"https://s3.amazonaws.com/gravityforms/addons/advancedpostcreation/gravityformsadvancedpostcreation_1.0-beta-7.2.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=luXnaYe3jbfHC6jhymkcdhEAVU4%3D\";}s:20:\"gravityformsagilecrm\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"1.4\";s:14:\"version_latest\";s:3:\"1.4\";s:3:\"url\";s:178:\"https://s3.amazonaws.com/gravityforms/addons/agilecrm/gravityformsagilecrm_1.4.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=sTtuAVgucYL8mdvZCMYqROeoN0I%3D\";s:10:\"url_latest\";s:178:\"https://s3.amazonaws.com/gravityforms/addons/agilecrm/gravityformsagilecrm_1.4.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=sTtuAVgucYL8mdvZCMYqROeoN0I%3D\";}s:24:\"gravityformsauthorizenet\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:4:\"2.10\";s:14:\"version_latest\";s:6:\"2.10.1\";s:3:\"url\";s:191:\"https://s3.amazonaws.com/gravityforms/addons/authorizenet/gravityformsauthorizenet_2.10.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=D26mzrUZxmGsLiHQ%2BJihe%2BUzHoE%3D\";s:10:\"url_latest\";s:191:\"https://s3.amazonaws.com/gravityforms/addons/authorizenet/gravityformsauthorizenet_2.10.1.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=ugzQR7HSlq2qyCcsgxo%2FbbmISiE%3D\";}s:18:\"gravityformsaweber\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:4:\"2.11\";s:14:\"version_latest\";s:4:\"2.11\";s:3:\"url\";s:175:\"https://s3.amazonaws.com/gravityforms/addons/aweber/gravityformsaweber_2.11.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=nmIMDYY0Gr1GC3MDlXbN0Pbgaak%3D\";s:10:\"url_latest\";s:175:\"https://s3.amazonaws.com/gravityforms/addons/aweber/gravityformsaweber_2.11.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=nmIMDYY0Gr1GC3MDlXbN0Pbgaak%3D\";}s:21:\"gravityformsbatchbook\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"1.3\";s:14:\"version_latest\";s:3:\"1.3\";s:3:\"url\";s:182:\"https://s3.amazonaws.com/gravityforms/addons/batchbook/gravityformsbatchbook_1.3.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=XvJ%2BykTAOLFzxzankLSGboVOeZw%3D\";s:10:\"url_latest\";s:182:\"https://s3.amazonaws.com/gravityforms/addons/batchbook/gravityformsbatchbook_1.3.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=XvJ%2BykTAOLFzxzankLSGboVOeZw%3D\";}s:18:\"gravityformsbreeze\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"1.5\";s:14:\"version_latest\";s:3:\"1.5\";s:3:\"url\";s:176:\"https://s3.amazonaws.com/gravityforms/addons/breeze/gravityformsbreeze_1.5.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=l1Qdq4FAJ84JvUtSQ%2B9goYuTjmQ%3D\";s:10:\"url_latest\";s:176:\"https://s3.amazonaws.com/gravityforms/addons/breeze/gravityformsbreeze_1.5.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=l1Qdq4FAJ84JvUtSQ%2B9goYuTjmQ%3D\";}s:27:\"gravityformscampaignmonitor\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"3.9\";s:14:\"version_latest\";s:3:\"3.9\";s:3:\"url\";s:194:\"https://s3.amazonaws.com/gravityforms/addons/campaignmonitor/gravityformscampaignmonitor_3.9.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=M8HhnA16%2F8agv5Y0Q1xc8xhm4WU%3D\";s:10:\"url_latest\";s:194:\"https://s3.amazonaws.com/gravityforms/addons/campaignmonitor/gravityformscampaignmonitor_3.9.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=M8HhnA16%2F8agv5Y0Q1xc8xhm4WU%3D\";}s:20:\"gravityformscampfire\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"1.1\";s:14:\"version_latest\";s:5:\"1.2.2\";s:3:\"url\";s:178:\"https://s3.amazonaws.com/gravityforms/addons/campfire/gravityformscampfire_1.1.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=roEe6zqdV05ZsPS3YSx4CUDaCoE%3D\";s:10:\"url_latest\";s:182:\"https://s3.amazonaws.com/gravityforms/addons/campfire/gravityformscampfire_1.2.2.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=cs0%2Fivw824vT9wBZOrClY9nlork%3D\";}s:22:\"gravityformscapsulecrm\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"1.5\";s:14:\"version_latest\";s:5:\"1.5.1\";s:3:\"url\";s:182:\"https://s3.amazonaws.com/gravityforms/addons/capsulecrm/gravityformscapsulecrm_1.5.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=J5qBxMhOGi0i3uotsiQpMIOXl1U%3D\";s:10:\"url_latest\";s:184:\"https://s3.amazonaws.com/gravityforms/addons/capsulecrm/gravityformscapsulecrm_1.5.1.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=NaU5f5GoKfKeRFppnKjRNULV1oA%3D\";}s:26:\"gravityformschainedselects\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"1.5\";s:14:\"version_latest\";s:3:\"1.5\";s:3:\"url\";s:194:\"https://s3.amazonaws.com/gravityforms/addons/chainedselects/gravityformschainedselects_1.5.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=lsZoIDGhM89o5i%2BLzbYX%2BZT2G7I%3D\";s:10:\"url_latest\";s:194:\"https://s3.amazonaws.com/gravityforms/addons/chainedselects/gravityformschainedselects_1.5.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=lsZoIDGhM89o5i%2BLzbYX%2BZT2G7I%3D\";}s:23:\"gravityformscleverreach\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"1.7\";s:14:\"version_latest\";s:3:\"1.7\";s:3:\"url\";s:184:\"https://s3.amazonaws.com/gravityforms/addons/cleverreach/gravityformscleverreach_1.7.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=GJpuo9PFGsEuxmblEIa4dZXflyo%3D\";s:10:\"url_latest\";s:184:\"https://s3.amazonaws.com/gravityforms/addons/cleverreach/gravityformscleverreach_1.7.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=GJpuo9PFGsEuxmblEIa4dZXflyo%3D\";}s:15:\"gravityformscli\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:0:\"\";s:14:\"version_latest\";s:3:\"1.4\";s:3:\"url\";s:0:\"\";s:10:\"url_latest\";s:168:\"https://s3.amazonaws.com/gravityforms/addons/cli/gravityformscli_1.4.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=ogdLG7pSatHAGK8YvXGpnlaTbNA%3D\";}s:27:\"gravityformsconstantcontact\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"1.5\";s:14:\"version_latest\";s:3:\"1.5\";s:3:\"url\";s:196:\"https://s3.amazonaws.com/gravityforms/addons/constantcontact/gravityformsconstantcontact_1.5.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=XJ%2BlFnNJbGEl5%2B4T6bFkyjIY0UM%3D\";s:10:\"url_latest\";s:196:\"https://s3.amazonaws.com/gravityforms/addons/constantcontact/gravityformsconstantcontact_1.5.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=XJ%2BlFnNJbGEl5%2B4T6bFkyjIY0UM%3D\";}s:19:\"gravityformscoupons\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:4:\"2.11\";s:14:\"version_latest\";s:6:\"2.11.1\";s:3:\"url\";s:179:\"https://s3.amazonaws.com/gravityforms/addons/coupons/gravityformscoupons_2.11.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=aQF2MOVUW%2FixqQRsmHaQuZ1uKrk%3D\";s:10:\"url_latest\";s:179:\"https://s3.amazonaws.com/gravityforms/addons/coupons/gravityformscoupons_2.11.1.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=0tipNNNgPVoL8aHsBdotfYVtyMg%3D\";}s:17:\"gravityformsdebug\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:0:\"\";s:14:\"version_latest\";s:10:\"1.0.beta12\";s:3:\"url\";s:0:\"\";s:10:\"url_latest\";s:179:\"https://s3.amazonaws.com/gravityforms/addons/debug/gravityformsdebug_1.0.beta12.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=Vji2X9BU3FHaOZMfeD3EHVQilFc%3D\";}s:19:\"gravityformsdropbox\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"2.8\";s:14:\"version_latest\";s:5:\"2.8.1\";s:3:\"url\";s:178:\"https://s3.amazonaws.com/gravityforms/addons/dropbox/gravityformsdropbox_2.8.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=Ew%2FGP0KqeBhdlizYJ3RHGgo2SUw%3D\";s:10:\"url_latest\";s:182:\"https://s3.amazonaws.com/gravityforms/addons/dropbox/gravityformsdropbox_2.8.1.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=4d%2Ff1obsI%2B6PRcrJexh93OGImY8%3D\";}s:24:\"gravityformsemailoctopus\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"1.2\";s:14:\"version_latest\";s:3:\"1.2\";s:3:\"url\";s:186:\"https://s3.amazonaws.com/gravityforms/addons/emailoctopus/gravityformsemailoctopus_1.2.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=VAqsJTlJflx2816b9U7s7TXroWc%3D\";s:10:\"url_latest\";s:186:\"https://s3.amazonaws.com/gravityforms/addons/emailoctopus/gravityformsemailoctopus_1.2.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=VAqsJTlJflx2816b9U7s7TXroWc%3D\";}s:16:\"gravityformsemma\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"1.4\";s:14:\"version_latest\";s:5:\"1.4.1\";s:3:\"url\";s:172:\"https://s3.amazonaws.com/gravityforms/addons/emma/gravityformsemma_1.4.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=59D%2BVAfBrrurFbvsYjH7zIV3ZKs%3D\";s:10:\"url_latest\";s:172:\"https://s3.amazonaws.com/gravityforms/addons/emma/gravityformsemma_1.4.1.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=UpGxX7jiEE6sXmjJHVEbtolFAgU%3D\";}s:22:\"gravityformsfreshbooks\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"2.7\";s:14:\"version_latest\";s:5:\"2.7.1\";s:3:\"url\";s:182:\"https://s3.amazonaws.com/gravityforms/addons/freshbooks/gravityformsfreshbooks_2.7.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=u4mvJUikcADaocv2hn3nghvhEcc%3D\";s:10:\"url_latest\";s:184:\"https://s3.amazonaws.com/gravityforms/addons/freshbooks/gravityformsfreshbooks_2.7.1.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=w1eyGbvwQ0pDdj7IwY2T8q6Vxug%3D\";}s:23:\"gravityformsgetresponse\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"1.5\";s:14:\"version_latest\";s:5:\"1.5.1\";s:3:\"url\";s:184:\"https://s3.amazonaws.com/gravityforms/addons/getresponse/gravityformsgetresponse_1.5.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=LnvddMJdMkEoKqx8yCS5wYBr1nk%3D\";s:10:\"url_latest\";s:190:\"https://s3.amazonaws.com/gravityforms/addons/getresponse/gravityformsgetresponse_1.5.1.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=U6kRqQ%2BKah6Sqf%2FtWNKvBkZj7jI%3D\";}s:21:\"gravityformsgutenberg\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:10:\"1.0-rc-1.4\";s:14:\"version_latest\";s:10:\"1.0-rc-1.5\";s:3:\"url\";s:187:\"https://s3.amazonaws.com/gravityforms/addons/gutenberg/gravityformsgutenberg_1.0-rc-1.4.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=g8fyHEiV5pbnvFebv4VhIALJckc%3D\";s:10:\"url_latest\";s:189:\"https://s3.amazonaws.com/gravityforms/addons/gutenberg/gravityformsgutenberg_1.0-rc-1.5.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=uuxqAiI%2BR0UZbOIKB3ecj4xvYc4%3D\";}s:21:\"gravityformshelpscout\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:4:\"1.15\";s:14:\"version_latest\";s:6:\"1.15.1\";s:3:\"url\";s:181:\"https://s3.amazonaws.com/gravityforms/addons/helpscout/gravityformshelpscout_1.15.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=KGJjImSEgbAcCyo0l1X7m7TODhA%3D\";s:10:\"url_latest\";s:183:\"https://s3.amazonaws.com/gravityforms/addons/helpscout/gravityformshelpscout_1.15.1.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=2uqKWER2vXq75wVftMutCzQNnOQ%3D\";}s:20:\"gravityformshighrise\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"1.3\";s:14:\"version_latest\";s:3:\"1.3\";s:3:\"url\";s:180:\"https://s3.amazonaws.com/gravityforms/addons/highrise/gravityformshighrise_1.3.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=CEky8lI56TPXhqEVndrjlfCH%2BkU%3D\";s:10:\"url_latest\";s:180:\"https://s3.amazonaws.com/gravityforms/addons/highrise/gravityformshighrise_1.3.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=CEky8lI56TPXhqEVndrjlfCH%2BkU%3D\";}s:19:\"gravityformshipchat\";a:3:{s:12:\"is_available\";b:0;s:7:\"version\";s:3:\"1.2\";s:14:\"version_latest\";s:3:\"1.2\";}s:19:\"gravityformshubspot\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"1.5\";s:14:\"version_latest\";s:5:\"1.5.2\";s:3:\"url\";s:178:\"https://s3.amazonaws.com/gravityforms/addons/hubspot/gravityformshubspot_1.5.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=QG8Ts%2BahbjDNwD6tJ5OVKC7lGhM%3D\";s:10:\"url_latest\";s:182:\"https://s3.amazonaws.com/gravityforms/addons/hubspot/gravityformshubspot_1.5.2.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=GTPf%2BN2FveZxN13%2BTYP7fx0juaU%3D\";}s:20:\"gravityformsicontact\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"1.5\";s:14:\"version_latest\";s:3:\"1.5\";s:3:\"url\";s:178:\"https://s3.amazonaws.com/gravityforms/addons/icontact/gravityformsicontact_1.5.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=LZzfJQeb3GLqIzrdFm2eFJTr1Js%3D\";s:10:\"url_latest\";s:178:\"https://s3.amazonaws.com/gravityforms/addons/icontact/gravityformsicontact_1.5.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=LZzfJQeb3GLqIzrdFm2eFJTr1Js%3D\";}s:19:\"gravityformslogging\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"1.3\";s:14:\"version_latest\";s:5:\"1.3.1\";s:3:\"url\";s:178:\"https://s3.amazonaws.com/gravityforms/addons/logging/gravityformslogging_1.3.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=V8WNCZRvkPYkVj6ErA3%2BLViehXk%3D\";s:10:\"url_latest\";s:178:\"https://s3.amazonaws.com/gravityforms/addons/logging/gravityformslogging_1.3.1.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=n6znZFxXrDtG2xuvEgzvBFnrzqY%3D\";}s:19:\"gravityformsmadmimi\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"1.4\";s:14:\"version_latest\";s:3:\"1.4\";s:3:\"url\";s:178:\"https://s3.amazonaws.com/gravityforms/addons/madmimi/gravityformsmadmimi_1.4.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=qt28n54fUxxCKhKIoH0NjjlYg%2Fw%3D\";s:10:\"url_latest\";s:178:\"https://s3.amazonaws.com/gravityforms/addons/madmimi/gravityformsmadmimi_1.4.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=qt28n54fUxxCKhKIoH0NjjlYg%2Fw%3D\";}s:21:\"gravityformsmailchimp\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"4.8\";s:14:\"version_latest\";s:3:\"4.8\";s:3:\"url\";s:182:\"https://s3.amazonaws.com/gravityforms/addons/mailchimp/gravityformsmailchimp_4.8.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=yfjt2gPwgGBwvxcd%2F2xMNFrUnX4%3D\";s:10:\"url_latest\";s:182:\"https://s3.amazonaws.com/gravityforms/addons/mailchimp/gravityformsmailchimp_4.8.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=yfjt2gPwgGBwvxcd%2F2xMNFrUnX4%3D\";}s:19:\"gravityformsmailgun\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"1.3\";s:14:\"version_latest\";s:3:\"1.3\";s:3:\"url\";s:176:\"https://s3.amazonaws.com/gravityforms/addons/mailgun/gravityformsmailgun_1.3.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=ZtGBI8Gr92nCFynE65hvFkBVdmQ%3D\";s:10:\"url_latest\";s:176:\"https://s3.amazonaws.com/gravityforms/addons/mailgun/gravityformsmailgun_1.3.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=ZtGBI8Gr92nCFynE65hvFkBVdmQ%3D\";}s:18:\"gravityformsmollie\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"1.1\";s:14:\"version_latest\";s:5:\"1.1.1\";s:3:\"url\";s:174:\"https://s3.amazonaws.com/gravityforms/addons/mollie/gravityformsmollie_1.1.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=CmX96MEM3NEAe3R558EL2LapZrk%3D\";s:10:\"url_latest\";s:176:\"https://s3.amazonaws.com/gravityforms/addons/mollie/gravityformsmollie_1.1.1.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=lRT7qTySc9EUP9FUcVA5eZj1obk%3D\";}s:26:\"gravityformspartialentries\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"1.6\";s:14:\"version_latest\";s:3:\"1.6\";s:3:\"url\";s:190:\"https://s3.amazonaws.com/gravityforms/addons/partialentries/gravityformspartialentries_1.6.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=UiV30oqzo3vQYGhxLWsKaeqwcZI%3D\";s:10:\"url_latest\";s:190:\"https://s3.amazonaws.com/gravityforms/addons/partialentries/gravityformspartialentries_1.6.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=UiV30oqzo3vQYGhxLWsKaeqwcZI%3D\";}s:18:\"gravityformspaypal\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"3.4\";s:14:\"version_latest\";s:5:\"3.4.1\";s:3:\"url\";s:174:\"https://s3.amazonaws.com/gravityforms/addons/paypal/gravityformspaypal_3.4.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=pVokAfX2SzBAvIf4FuIsdeYUlFE%3D\";s:10:\"url_latest\";s:176:\"https://s3.amazonaws.com/gravityforms/addons/paypal/gravityformspaypal_3.4.1.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=B2RFsnnO9uiSv5h0lBq8HHshJnc%3D\";}s:33:\"gravityformspaypalexpresscheckout\";a:3:{s:12:\"is_available\";b:0;s:7:\"version\";s:0:\"\";s:14:\"version_latest\";N;}s:29:\"gravityformspaypalpaymentspro\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"2.6\";s:14:\"version_latest\";s:5:\"2.6.1\";s:3:\"url\";s:198:\"https://s3.amazonaws.com/gravityforms/addons/paypalpaymentspro/gravityformspaypalpaymentspro_2.6.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=hFa1siP%2FYd78GmHRobziLfE5Dvw%3D\";s:10:\"url_latest\";s:198:\"https://s3.amazonaws.com/gravityforms/addons/paypalpaymentspro/gravityformspaypalpaymentspro_2.6.1.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=ZfHlhBDZdvALENhfWu8gZRDik1s%3D\";}s:21:\"gravityformspaypalpro\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:5:\"1.8.1\";s:14:\"version_latest\";s:5:\"1.8.4\";s:3:\"url\";s:186:\"https://s3.amazonaws.com/gravityforms/addons/paypalpro/gravityformspaypalpro_1.8.1.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=N%2B9lP2Vz8bxCAX0yumby%2FCezkVQ%3D\";s:10:\"url_latest\";s:186:\"https://s3.amazonaws.com/gravityforms/addons/paypalpro/gravityformspaypalpro_1.8.4.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=9G7le6B87%2BddxV9T%2BrgCedaUz5g%3D\";}s:20:\"gravityformspicatcha\";a:3:{s:12:\"is_available\";b:0;s:7:\"version\";s:3:\"2.0\";s:14:\"version_latest\";s:3:\"2.0\";}s:16:\"gravityformspipe\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"1.2\";s:14:\"version_latest\";s:3:\"1.3\";s:3:\"url\";s:170:\"https://s3.amazonaws.com/gravityforms/addons/pipe/gravityformspipe_1.2.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=8aKVdt9jQAnNTriAtghwwM6GZu4%3D\";s:10:\"url_latest\";s:170:\"https://s3.amazonaws.com/gravityforms/addons/pipe/gravityformspipe_1.3.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=m7OQ4LkmIIdrknvtsNHNl4JVK6k%3D\";}s:17:\"gravityformspolls\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"3.7\";s:14:\"version_latest\";s:5:\"3.7.1\";s:3:\"url\";s:174:\"https://s3.amazonaws.com/gravityforms/addons/polls/gravityformspolls_3.7.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=AKEmAndvZm%2FjOavlC9d8yNKTZEA%3D\";s:10:\"url_latest\";s:174:\"https://s3.amazonaws.com/gravityforms/addons/polls/gravityformspolls_3.7.1.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=Ti8sTXMzJFshSng0VxC8lPu6l2M%3D\";}s:20:\"gravityformspostmark\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"1.3\";s:14:\"version_latest\";s:3:\"1.3\";s:3:\"url\";s:182:\"https://s3.amazonaws.com/gravityforms/addons/postmark/gravityformspostmark_1.3.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=ccsiZhPm9%2BaX%2F260AJMDMnFOts8%3D\";s:10:\"url_latest\";s:182:\"https://s3.amazonaws.com/gravityforms/addons/postmark/gravityformspostmark_1.3.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=ccsiZhPm9%2BaX%2F260AJMDMnFOts8%3D\";}s:16:\"gravityformsppcp\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"1.4\";s:14:\"version_latest\";s:5:\"1.4.7\";s:3:\"url\";s:172:\"https://s3.amazonaws.com/gravityforms/addons/ppcp/gravityformsppcp_1.4.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=cYQsP9peLYwn4PO4%2Foh1KTIj0A4%3D\";s:10:\"url_latest\";s:174:\"https://s3.amazonaws.com/gravityforms/addons/ppcp/gravityformsppcp_1.4.7.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=Rg4X%2FQM5M9SyEg8LCwjkydlbRik%3D\";}s:16:\"gravityformsquiz\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"3.6\";s:14:\"version_latest\";s:5:\"3.6.2\";s:3:\"url\";s:170:\"https://s3.amazonaws.com/gravityforms/addons/quiz/gravityformsquiz_3.6.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=awueYwdORIugw1iTMclHek6mSjU%3D\";s:10:\"url_latest\";s:172:\"https://s3.amazonaws.com/gravityforms/addons/quiz/gravityformsquiz_3.6.2.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=zexjmwg6ejpROVG92k5rfeX3AG8%3D\";}s:19:\"gravityformsrestapi\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:10:\"2.0-beta-2\";s:14:\"version_latest\";s:10:\"2.0-beta-2\";s:3:\"url\";s:185:\"https://s3.amazonaws.com/gravityforms/addons/restapi/gravityformsrestapi_2.0-beta-2.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=GU1cQi%2Buhs7ShPKF5dCyksZWA0E%3D\";s:10:\"url_latest\";s:185:\"https://s3.amazonaws.com/gravityforms/addons/restapi/gravityformsrestapi_2.0-beta-2.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=GU1cQi%2Buhs7ShPKF5dCyksZWA0E%3D\";}s:20:\"gravityformssendgrid\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"1.4\";s:14:\"version_latest\";s:5:\"1.4.1\";s:3:\"url\";s:178:\"https://s3.amazonaws.com/gravityforms/addons/sendgrid/gravityformssendgrid_1.4.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=bIXFlAP2lLoBWoZlfsgY6dZFeOU%3D\";s:10:\"url_latest\";s:182:\"https://s3.amazonaws.com/gravityforms/addons/sendgrid/gravityformssendgrid_1.4.1.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=p8NcMVcvEAdAKjA4MfOF%2FrWP8tQ%3D\";}s:21:\"gravityformssignature\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"4.0\";s:14:\"version_latest\";s:5:\"4.0.2\";s:3:\"url\";s:182:\"https://s3.amazonaws.com/gravityforms/addons/signature/gravityformssignature_4.0.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=ngiNm%2F6A7CgcDghcWHmIankblPc%3D\";s:10:\"url_latest\";s:186:\"https://s3.amazonaws.com/gravityforms/addons/signature/gravityformssignature_4.0.2.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=hwWLuaN%2FHlEcyU%2Fj4W90yC4oZbo%3D\";}s:17:\"gravityformsslack\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:4:\"1.13\";s:14:\"version_latest\";s:6:\"1.13.2\";s:3:\"url\";s:175:\"https://s3.amazonaws.com/gravityforms/addons/slack/gravityformsslack_1.13.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=OyuV%2FwkdrA70Iw6EceBkFEcmhnM%3D\";s:10:\"url_latest\";s:181:\"https://s3.amazonaws.com/gravityforms/addons/slack/gravityformsslack_1.13.2.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=B0t5GpXYofU%2FQqcu%2FNGpvj%2BQpXI%3D\";}s:18:\"gravityformssquare\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"1.4\";s:14:\"version_latest\";s:5:\"1.4.1\";s:3:\"url\";s:174:\"https://s3.amazonaws.com/gravityforms/addons/square/gravityformssquare_1.4.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=4TWOyC6SrmHbkUFZSxdyjE29tt4%3D\";s:10:\"url_latest\";s:178:\"https://s3.amazonaws.com/gravityforms/addons/square/gravityformssquare_1.4.1.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=M%2FuNTiJEDK5rZUPwXIq4EWNId8c%3D\";}s:18:\"gravityformsstripe\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"3.9\";s:14:\"version_latest\";s:5:\"3.9.2\";s:3:\"url\";s:174:\"https://s3.amazonaws.com/gravityforms/addons/stripe/gravityformsstripe_3.9.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=ryCsknPPYCL7j3tHtTbAr6rAzDM%3D\";s:10:\"url_latest\";s:176:\"https://s3.amazonaws.com/gravityforms/addons/stripe/gravityformsstripe_3.9.2.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=l6MEyUX0UzM0Nh9lELzpDazlaiw%3D\";}s:18:\"gravityformssurvey\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"3.6\";s:14:\"version_latest\";s:5:\"3.6.3\";s:3:\"url\";s:174:\"https://s3.amazonaws.com/gravityforms/addons/survey/gravityformssurvey_3.6.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=YY5xhUBIWZmzHte6UhUEJz3C9BY%3D\";s:10:\"url_latest\";s:178:\"https://s3.amazonaws.com/gravityforms/addons/survey/gravityformssurvey_3.6.3.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=JkRO19POUvHCp3KReXSXoH3%2FaZI%3D\";}s:18:\"gravityformstrello\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"1.4\";s:14:\"version_latest\";s:3:\"1.4\";s:3:\"url\";s:176:\"https://s3.amazonaws.com/gravityforms/addons/trello/gravityformstrello_1.4.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=icHGGZ5AF1%2BlsJLZHzN3nLpBnmE%3D\";s:10:\"url_latest\";s:176:\"https://s3.amazonaws.com/gravityforms/addons/trello/gravityformstrello_1.4.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=icHGGZ5AF1%2BlsJLZHzN3nLpBnmE%3D\";}s:18:\"gravityformstwilio\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"2.8\";s:14:\"version_latest\";s:3:\"2.8\";s:3:\"url\";s:174:\"https://s3.amazonaws.com/gravityforms/addons/twilio/gravityformstwilio_2.8.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=G9peHPHZawgx2xyeWBGsayzUOOQ%3D\";s:10:\"url_latest\";s:174:\"https://s3.amazonaws.com/gravityforms/addons/twilio/gravityformstwilio_2.8.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=G9peHPHZawgx2xyeWBGsayzUOOQ%3D\";}s:28:\"gravityformsuserregistration\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"4.7\";s:14:\"version_latest\";s:5:\"4.7.1\";s:3:\"url\";s:196:\"https://s3.amazonaws.com/gravityforms/addons/userregistration/gravityformsuserregistration_4.7.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=GzmoPmZu%2BC3tqvnOFitfOxEgvd4%3D\";s:10:\"url_latest\";s:196:\"https://s3.amazonaws.com/gravityforms/addons/userregistration/gravityformsuserregistration_4.7.1.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=nc0rHECbRLoMuo20xWhy0zaGE4Q%3D\";}s:20:\"gravityformswebhooks\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"1.4\";s:14:\"version_latest\";s:5:\"1.4.1\";s:3:\"url\";s:182:\"https://s3.amazonaws.com/gravityforms/addons/webhooks/gravityformswebhooks_1.4.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=eeOw1YLCvASfoqXiZ%2Fw%2BfwYU2JA%3D\";s:10:\"url_latest\";s:180:\"https://s3.amazonaws.com/gravityforms/addons/webhooks/gravityformswebhooks_1.4.1.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=Ci54KpzRjNBVXFN5SYeApHQBl1g%3D\";}s:18:\"gravityformszapier\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"4.0\";s:14:\"version_latest\";s:3:\"4.0\";s:3:\"url\";s:178:\"https://s3.amazonaws.com/gravityforms/addons/zapier/gravityformszapier_4.0.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=0A%2Bxshyau8OqOiT%2BVvjAoROhc5g%3D\";s:10:\"url_latest\";s:178:\"https://s3.amazonaws.com/gravityforms/addons/zapier/gravityformszapier_4.0.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=0A%2Bxshyau8OqOiT%2BVvjAoROhc5g%3D\";}s:19:\"gravityformszohocrm\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:4:\"1.12\";s:14:\"version_latest\";s:6:\"1.12.3\";s:3:\"url\";s:179:\"https://s3.amazonaws.com/gravityforms/addons/zohocrm/gravityformszohocrm_1.12.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=%2BRrLWayGtnsIbomSa1L7t4B0lxY%3D\";s:10:\"url_latest\";s:185:\"https://s3.amazonaws.com/gravityforms/addons/zohocrm/gravityformszohocrm_1.12.3.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=yIcm0%2Bhnu3%2FCUp%2Be8lRAcVzMC08%3D\";}}s:9:\"is_active\";s:1:\"1\";s:12:\"product_code\";s:5:\"GFDEV\";s:14:\"version_latest\";s:6:\"2.4.23\";s:10:\"url_latest\";s:166:\"https://s3.amazonaws.com/gravityforms/releases/gravityforms_2.4.23.zip?AWSAccessKeyId=AKIA5U3GBHC5S55R7EU5&Expires=1615056292&Signature=3O8GYqWIAQoKEPbcxvUxbTJBzWE%3D\";s:9:\"timestamp\";i:1614883492;}','no');
INSERT INTO `wp_options` VALUES (205,'acf_version','5.9.5','yes');
INSERT INTO `wp_options` VALUES (206,'hmbkp_plugin_version','3.10','yes');
INSERT INTO `wp_options` VALUES (207,'wpmdb_schema_version','2','no');
INSERT INTO `wp_options` VALUES (208,'googlesitekit_db_version','1.3.0','yes');
INSERT INTO `wp_options` VALUES (211,'hmbkp_schedule_1590526055','a:7:{s:11:\"max_backups\";i:7;s:8:\"excludes\";a:0:{}s:4:\"type\";s:8:\"database\";s:12:\"reoccurrence\";s:5:\"daily\";s:19:\"schedule_start_time\";i:1590534000;s:14:\"duration_total\";i:4796102410;s:16:\"backup_run_count\";i:3;}','yes');
INSERT INTO `wp_options` VALUES (212,'hmbkp_schedule_1590526056','a:7:{s:11:\"max_backups\";i:3;s:8:\"excludes\";a:0:{}s:4:\"type\";s:8:\"complete\";s:12:\"reoccurrence\";s:6:\"weekly\";s:19:\"schedule_start_time\";i:1590894000;s:14:\"duration_total\";i:1614883501;s:16:\"backup_run_count\";i:1;}','yes');
INSERT INTO `wp_options` VALUES (215,'wpseo_ryte','a:2:{s:6:\"status\";i:-1;s:10:\"last_fetch\";i:1614883503;}','yes');
INSERT INTO `wp_options` VALUES (243,'rg_gforms_key','bb423c588de5cfc0f4fe26794b36b19d','yes');
INSERT INTO `wp_options` VALUES (244,'gf_site_key','180ef567-d7c6-4d61-816d-053f514c2377','yes');
INSERT INTO `wp_options` VALUES (245,'gf_site_secret','f244a179-0de0-47b9-a364-b77c78890c8a','yes');
INSERT INTO `wp_options` VALUES (246,'rg_gforms_enable_akismet','1','yes');
INSERT INTO `wp_options` VALUES (247,'rg_gforms_currency','','yes');
INSERT INTO `wp_options` VALUES (248,'gform_enable_toolbar_menu','1','yes');
INSERT INTO `wp_options` VALUES (261,'WPLANG','','yes');
INSERT INTO `wp_options` VALUES (262,'new_admin_email','development@factor1studios.com','yes');
INSERT INTO `wp_options` VALUES (272,'wdp_un_enable_sso','1','no');
INSERT INTO `wp_options` VALUES (273,'wdp_un_sso_userid','1','no');
INSERT INTO `wp_options` VALUES (275,'wpmudev_apikey','af3a00924938d6a2c920c1a9408d9e67614b06d4','no');
INSERT INTO `wp_options` VALUES (276,'wp-smush-last_run_sync','a:2:{s:4:\"time\";i:1614883491;s:5:\"fails\";i:0;}','no');
INSERT INTO `wp_options` VALUES (277,'wp_smush_api_auth','a:1:{s:40:\"af3a00924938d6a2c920c1a9408d9e67614b06d4\";a:2:{s:8:\"validity\";s:5:\"valid\";s:9:\"timestamp\";i:1614883491;}}','no');
INSERT INTO `wp_options` VALUES (289,'theme_mods_twentytwenty','a:1:{s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1590526926;s:4:\"data\";a:3:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:3:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";}s:9:\"sidebar-2\";a:3:{i:0;s:10:\"archives-2\";i:1;s:12:\"categories-2\";i:2;s:6:\"meta-2\";}}}}','yes');
INSERT INTO `wp_options` VALUES (290,'current_theme','Demo Theme Name','yes');
INSERT INTO `wp_options` VALUES (291,'theme_mods_f1-demo-theme','a:3:{i:0;b:0;s:18:\"nav_menu_locations\";a:4:{s:7:\"primary\";i:5;s:6:\"mobile\";i:5;s:6:\"footer\";i:6;s:6:\"social\";i:7;}s:18:\"custom_css_post_id\";i:-1;}','yes');
INSERT INTO `wp_options` VALUES (292,'theme_switched','','yes');
INSERT INTO `wp_options` VALUES (293,'responsive_media_option','a:11:{s:7:\"youtube\";s:2:\"on\";s:5:\"vimeo\";s:2:\"on\";s:11:\"wordpresstv\";s:2:\"on\";s:10:\"soundcloud\";s:2:\"on\";s:10:\"slideshare\";s:2:\"on\";s:3:\"ted\";s:2:\"on\";s:11:\"kickstarter\";s:2:\"on\";s:10:\"videopress\";s:2:\"on\";s:11:\"speakerdeck\";s:2:\"on\";s:4:\"vine\";s:2:\"on\";s:6:\"flickr\";s:2:\"on\";}','yes');
INSERT INTO `wp_options` VALUES (313,'_site_transient_update_themes','O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1614883948;s:7:\"checked\";a:2:{s:13:\"f1-demo-theme\";s:5:\"0.0.1\";s:15:\"twentytwentyone\";s:3:\"1.1\";}s:8:\"response\";a:0:{}s:9:\"no_update\";a:1:{s:15:\"twentytwentyone\";a:6:{s:5:\"theme\";s:15:\"twentytwentyone\";s:11:\"new_version\";s:3:\"1.1\";s:3:\"url\";s:45:\"https://wordpress.org/themes/twentytwentyone/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/theme/twentytwentyone.1.1.zip\";s:8:\"requires\";s:3:\"5.3\";s:12:\"requires_php\";s:3:\"5.6\";}}s:12:\"translations\";a:0:{}}','no');
INSERT INTO `wp_options` VALUES (417,'_transient_googlesitekit_verification_meta_tags','a:0:{}','yes');
INSERT INTO `wp_options` VALUES (474,'category_children','a:0:{}','yes');
INSERT INTO `wp_options` VALUES (527,'options_header_logo','','no');
INSERT INTO `wp_options` VALUES (528,'_options_header_logo','field_5ecd923d8321b','no');
INSERT INTO `wp_options` VALUES (529,'options_footer_logo','','no');
INSERT INTO `wp_options` VALUES (530,'_options_footer_logo','field_5ecd92958321e','no');
INSERT INTO `wp_options` VALUES (531,'options_blog_meta_data','a:4:{i:0;s:6:\"author\";i:1;s:4:\"date\";i:2;s:10:\"categories\";i:3;s:4:\"tags\";}','no');
INSERT INTO `wp_options` VALUES (532,'_options_blog_meta_data','field_5eceaa207df18','no');
INSERT INTO `wp_options` VALUES (533,'options_404_content','<h1 style=\"text-align: center;\">404</h1>\r\n<h3 style=\"text-align: center;\">Page Not Found</h3>\r\n<p style=\"text-align: center;\">Looks like the page you are looking for doesn\'t exist.</p>','no');
INSERT INTO `wp_options` VALUES (534,'_options_404_content','field_5ecd92c683220','no');
INSERT INTO `wp_options` VALUES (742,'nav_menu_options','a:2:{i:0;b:0;s:8:\"auto_add\";a:0:{}}','yes');
INSERT INTO `wp_options` VALUES (771,'wp-smush-cdn_status','O:8:\"stdClass\":8:{s:5:\"limit\";i:32;s:11:\"cdn_enabled\";b:1;s:7:\"site_id\";b:0;s:12:\"endpoint_url\";s:19:\"292869.smushcdn.com\";s:14:\"bandwidth_plan\";i:10;s:9:\"bandwidth\";s:9:\"292514218\";s:4:\"hits\";s:5:\"40574\";s:12:\"cache_misses\";s:4:\"7436\";}','no');
INSERT INTO `wp_options` VALUES (776,'_transient_health-check-site-status-result','{\"good\":\"10\",\"recommended\":\"6\",\"critical\":\"1\"}','yes');
INSERT INTO `wp_options` VALUES (836,'_site_transient_timeout_theme_roots','1614885314','no');
INSERT INTO `wp_options` VALUES (837,'_site_transient_theme_roots','a:2:{s:13:\"f1-demo-theme\";s:7:\"/themes\";s:15:\"twentytwentyone\";s:7:\"/themes\";}','no');
INSERT INTO `wp_options` VALUES (841,'_site_transient_timeout_php_check_472f71d2a071d463a95f84346288dc89','1615488303','no');
INSERT INTO `wp_options` VALUES (842,'_site_transient_php_check_472f71d2a071d463a95f84346288dc89','a:5:{s:19:\"recommended_version\";s:3:\"7.4\";s:15:\"minimum_version\";s:6:\"5.6.20\";s:12:\"is_supported\";b:1;s:9:\"is_secure\";b:1;s:13:\"is_acceptable\";b:1;}','no');
INSERT INTO `wp_options` VALUES (843,'_transient_timeout_hmbkp_schedules','1615488304','no');
INSERT INTO `wp_options` VALUES (844,'_transient_hmbkp_schedules','a:2:{i:0;s:25:\"hmbkp_schedule_1590526055\";i:1;s:25:\"hmbkp_schedule_1590526056\";}','no');
INSERT INTO `wp_options` VALUES (847,'disallowed_keys','','no');
INSERT INTO `wp_options` VALUES (848,'comment_previously_approved','1','yes');
INSERT INTO `wp_options` VALUES (849,'auto_plugin_theme_update_emails','a:0:{}','no');
INSERT INTO `wp_options` VALUES (850,'auto_update_core_dev','enabled','yes');
INSERT INTO `wp_options` VALUES (851,'auto_update_core_minor','enabled','yes');
INSERT INTO `wp_options` VALUES (852,'auto_update_core_major','unset','yes');
INSERT INTO `wp_options` VALUES (853,'finished_updating_comment_type','1','yes');
INSERT INTO `wp_options` VALUES (854,'db_upgraded','','yes');
INSERT INTO `wp_options` VALUES (856,'_site_transient_update_core','O:8:\"stdClass\":4:{s:7:\"updates\";a:1:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:6:\"latest\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.6.2.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.6.2.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-5.6.2-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-5.6.2-new-bundled.zip\";s:7:\"partial\";s:0:\"\";s:8:\"rollback\";s:0:\"\";}s:7:\"current\";s:5:\"5.6.2\";s:7:\"version\";s:5:\"5.6.2\";s:11:\"php_version\";s:6:\"5.6.20\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.6\";s:15:\"partial_version\";s:0:\"\";}}s:12:\"last_checked\";i:1614884070;s:15:\"version_checked\";s:5:\"5.6.2\";s:12:\"translations\";a:0:{}}','no');
INSERT INTO `wp_options` VALUES (857,'_site_transient_timeout_wpmdb_upgrade_data','1614926759','no');
INSERT INTO `wp_options` VALUES (858,'_site_transient_wpmdb_upgrade_data','a:5:{s:17:\"wp-migrate-db-pro\";a:4:{s:7:\"version\";s:6:\"1.9.14\";s:6:\"tested\";s:5:\"5.6.1\";s:12:\"requires_php\";s:3:\"5.4\";s:12:\"beta_version\";s:5:\"2.0b8\";}s:29:\"wp-migrate-db-pro-media-files\";a:4:{s:7:\"version\";s:6:\"1.4.16\";s:6:\"tested\";s:5:\"5.6.1\";s:12:\"requires_php\";s:3:\"5.4\";s:12:\"beta_version\";s:5:\"2.0b4\";}s:21:\"wp-migrate-db-pro-cli\";a:3:{s:7:\"version\";s:5:\"1.3.5\";s:6:\"tested\";s:5:\"5.6.1\";s:12:\"beta_version\";s:5:\"1.4b2\";}s:33:\"wp-migrate-db-pro-multisite-tools\";a:3:{s:7:\"version\";s:5:\"1.2.6\";s:6:\"tested\";s:5:\"5.6.1\";s:12:\"beta_version\";s:5:\"1.3b1\";}s:36:\"wp-migrate-db-pro-theme-plugin-files\";a:4:{s:7:\"version\";s:5:\"1.0.6\";s:6:\"tested\";s:5:\"5.6.1\";s:12:\"requires_php\";s:3:\"5.4\";s:12:\"beta_version\";s:5:\"1.1b3\";}}','no');
INSERT INTO `wp_options` VALUES (859,'_site_transient_timeout_browser_5308a756e7c49869b0397a45d7f666ed','1615488360','no');
INSERT INTO `wp_options` VALUES (860,'_site_transient_browser_5308a756e7c49869b0397a45d7f666ed','a:10:{s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:13:\"88.0.4324.192\";s:8:\"platform\";s:9:\"Macintosh\";s:10:\"update_url\";s:29:\"https://www.google.com/chrome\";s:7:\"img_src\";s:43:\"http://s.w.org/images/browsers/chrome.png?1\";s:11:\"img_src_ssl\";s:44:\"https://s.w.org/images/browsers/chrome.png?1\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}','no');
INSERT INTO `wp_options` VALUES (862,'_transient_timeout_wp-smush-conflict_check','1614887553','no');
INSERT INTO `wp_options` VALUES (863,'_transient_wp-smush-conflict_check','a:0:{}','no');
INSERT INTO `wp_options` VALUES (864,'_transient_timeout_wpseo-statistics-totals','1614969961','no');
INSERT INTO `wp_options` VALUES (865,'_transient_wpseo-statistics-totals','a:1:{i:1;a:2:{s:6:\"scores\";a:1:{i:0;a:4:{s:8:\"seo_rank\";s:2:\"na\";s:5:\"label\";s:48:\"Posts <strong>without</strong> a focus keyphrase\";s:5:\"count\";i:2;s:4:\"link\";s:99:\"http://localhost:10008/wp-admin/edit.php?post_status=publish&#038;post_type=post&#038;seo_filter=na\";}}s:8:\"division\";a:5:{s:3:\"bad\";i:0;s:2:\"ok\";i:0;s:4:\"good\";i:0;s:2:\"na\";i:1;s:7:\"noindex\";i:0;}}}','no');
INSERT INTO `wp_options` VALUES (866,'can_compress_scripts','0','no');
INSERT INTO `wp_options` VALUES (867,'_site_transient_timeout_wpmdb_licence_response','1614926767','no');
INSERT INTO `wp_options` VALUES (868,'_site_transient_wpmdb_licence_response','{\"addons_available\":\"1\",\"addons_available_list\":{\"wp-migrate-db-pro-media-files\":2351,\"wp-migrate-db-pro-cli\":3948,\"wp-migrate-db-pro-multisite-tools\":7999,\"wp-migrate-db-pro-theme-plugin-files\":36287},\"addon_list\":{\"wp-migrate-db-pro-media-files\":{\"type\":\"feature\",\"name\":\"Media Files\",\"desc\":\"Allows you to push and pull your files in the Media Library between two WordPress installs. It can compare both libraries and only migrate those missing or updated, or it can do a complete copy of one site\\u2019s library to another. <a href=\\\"https:\\/\\/deliciousbrains.com\\/wp-migrate-db-pro\\/doc\\/media-files-addon\\/?utm_campaign=addons%252Binstall&utm_source=MDB%252BPaid&utm_medium=insideplugin\\\">More Details &rarr;<\\/a>\",\"version\":\"1.4.16\",\"beta_version\":\"2.0b4\",\"tested\":\"5.6.1\"},\"wp-migrate-db-pro-cli\":{\"type\":\"feature\",\"name\":\"CLI\",\"desc\":\"Integrates WP Migrate DB Pro with WP-CLI allowing you to run migrations from the command line: <code>wp migratedb &lt;push|pull&gt; &lt;url&gt; &lt;secret-key&gt;<\\/code> <code>[--find=&lt;strings&gt;] [--replace=&lt;strings&gt;] ...<\\/code> <a href=\\\"https:\\/\\/deliciousbrains.com\\/wp-migrate-db-pro\\/doc\\/cli-addon\\/?utm_campaign=addons%252Binstall&utm_source=MDB%252BPaid&utm_medium=insideplugin\\\">More Details &rarr;<\\/a>\",\"required\":\"1.4b1\",\"version\":\"1.3.5\",\"beta_version\":\"1.4b2\",\"tested\":\"5.6.1\"},\"wp-migrate-db-pro-multisite-tools\":{\"type\":\"feature\",\"name\":\"Multisite Tools\",\"desc\":\"Export a subsite as an SQL file that can then be imported as a single site install. <a href=\\\"https:\\/\\/deliciousbrains.com\\/wp-migrate-db-pro\\/doc\\/multisite-tools-addon\\/?utm_campaign=addons%252Binstall&utm_source=MDB%252BPaid&utm_medium=insideplugin\\\">More Details &rarr;<\\/a>\",\"required\":\"1.5-dev\",\"version\":\"1.2.6\",\"beta_version\":\"1.3b1\",\"tested\":\"5.6.1\"},\"wp-migrate-db-pro-theme-plugin-files\":{\"type\":\"feature\",\"name\":\"Theme & Plugin Files\",\"desc\":\"Allows you to push and pull your theme and plugin files between two WordPress installs. <a href=\\\"https:\\/\\/deliciousbrains.com\\/wp-migrate-db-pro\\/doc\\/theme-plugin-files-addon\\/?utm_campaign=addons%252Binstall&utm_source=MDB%252BPaid&utm_medium=insideplugin\\\">More Details &rarr;<\\/a>\",\"required\":\"1.8.2b1\",\"version\":\"1.0.6\",\"beta_version\":\"1.1b3\",\"tested\":\"5.6.1\"}},\"message\":\"<style type=\\\"text\\/css\\\" media=\\\"screen\\\">body .support .support-content{overflow:hidden;width:727px}body .support .support-content .intro{margin-bottom:20px}body .support .support-content .submission-error p,body .support .support-content .submission-success p{padding:2px;margin:.5em 0;font-size:13px;line-height:1.5}body .support .support-content .dbrains-support-form{width:475px;float:left}body .support .support-content .dbrains-support-form p{width:auto}body .support .support-content .dbrains-support-form .field{margin-bottom:5px}body .support .support-content .dbrains-support-form input[type=text],body .support .support-content .dbrains-support-form textarea{width:100%}body .support .support-content .dbrains-support-form .field.from label{float:left;line-height:28px;display:block;font-weight:700}body .support .support-content .dbrains-support-form .field.from select{float:right;width:400px}body .support .support-content .dbrains-support-form .field.from .note{clear:both;padding-top:5px}body .support .support-content .dbrains-support-form .field.email-message textarea{height:170px}body .support .support-content .dbrains-support-form .field.remote-diagnostic-content{padding-left:20px}body .support .support-content .dbrains-support-form .field.remote-diagnostic-content ol{margin:0 0 5px 20px}body .support .support-content .dbrains-support-form .field.remote-diagnostic-content li{font-size:12px;color:#666;margin-bottom:0;line-height:1.4em}body .support .support-content .dbrains-support-form .field.remote-diagnostic-content textarea{height:80px}body .support .support-content .dbrains-support-form .note{font-size:12px;color:#666}body .support .support-content .dbrains-support-form .submit-form{overflow:hidden;padding:10px 0}body .support .support-content .dbrains-support-form .button{float:left}body .support .support-content .dbrains-support-form .button:active,body .support .support-content .dbrains-support-form .button:focus{outline:0}body .support .support-content .dbrains-support-form .ajax-spinner{float:left;margin-left:5px;margin-top:3px}body .support .support-content .additional-help{float:right;width:220px}body .support .support-content .additional-help a{text-decoration:none}body .support .support-content .additional-help h1{margin:0 0 12px;padding:0;font-size:18px;font-weight:400;line-height:1}body .support .support-content .additional-help h1 a{color:#333}body .support .support-content .additional-help .docs{background-color:#e6e6e6;padding:15px 15px 10px}body .support .support-content .additional-help .docs ul{margin:0}body .support .support-content .additional-help .docs li{font-size:14px}<\\/style><section class=\\\"dbrains-support-form\\\">\\n\\n<p class=\\\"intro\\\">\\n\\tYou have an active <strong>Developer<\\/strong> license. You will get front-of-the-line email support service when submitting the form below.<\\/p>\\n\\n<div class=\\\"updated submission-success\\\" style=\\\"display: none;\\\">\\n\\t<p><strong>Success!<\\/strong> &mdash; Thanks for submitting your support request. We\'ll be in touch soon.<\\/p>\\n<\\/div>\\n\\n<div class=\\\"error submission-error api-error\\\" style=\\\"display: none;\\\">\\n\\t<p><strong>Error!<\\/strong> &mdash; <\\/p>\\n<\\/div>\\n\\n<div class=\\\"error submission-error xhr-error\\\" style=\\\"display: none;\\\">\\n\\t<p><strong>Error!<\\/strong> &mdash; There was a problem submitting your request:<\\/p>\\n<\\/div>\\n\\n<div class=\\\"error submission-error email-error\\\" style=\\\"display: none;\\\">\\n\\t<p><strong>Error!<\\/strong> &mdash; Please select your email address.<\\/p>\\n<\\/div>\\n\\n<div class=\\\"error submission-error subject-error\\\" style=\\\"display: none;\\\">\\n\\t<p><strong>Error!<\\/strong> &mdash; Please enter a subject.<\\/p>\\n<\\/div>\\n\\n<div class=\\\"error submission-error message-error\\\" style=\\\"display: none;\\\">\\n\\t<p><strong>Error!<\\/strong> &mdash; Please enter a message.<\\/p>\\n<\\/div>\\n\\n<div class=\\\"error submission-error remote-diagnostic-content-error\\\" style=\\\"display: none;\\\">\\n\\t<p><strong>Error!<\\/strong> &mdash; Please paste in the Diagnostic Info &amp; Error Log from your <strong>remote site<\\/strong>.<\\/p>\\n<\\/div>\\n\\n<div class=\\\"error submission-error both-diagnostic-same-error\\\" style=\\\"display: none;\\\">\\n\\t<p><strong>Error!<\\/strong> &mdash; Looks like you pasted the local Diagnostic Info &amp; Error Log into the textbox for the remote info. Please get the info for your <strong>remote site<\\/strong> and paste it in, or just uncheck the second checkbox if you&#8217;d rather not include your remote site info.<\\/p>\\n<\\/div>\\n\\n<form target=\\\"_blank\\\" method=\\\"post\\\" action=\\\"https:\\/\\/api.deliciousbrains.com\\/?wc-api=delicious-brains&request=submit_support_request&licence_key=ffc6795e-b75f-4fbc-b274-7a6c0c97864e&product=wp-migrate-db-pro\\\">\\n\\n\\t<div class=\\\"field from\\\">\\n\\t\\t<label>From:<\\/label>\\n\\t\\t<select name=\\\"email\\\">\\n\\t\\t<option value=\\\"\\\">&mdash; Select your email address &mdash;<\\/option>\\n\\t\\t<option value=\\\"mattadams@factor1studios.com\\\">mattadams@factor1studios.com<\\/option>\\t\\t<\\/select>\\n\\n\\t\\t<p class=\\\"note\\\">\\n\\t\\t\\tReplies will be sent to this email address. Update your name &amp; email in <a href=\\\"https:\\/\\/deliciousbrains.com\\/my-account\\/\\\">My Account<\\/a>.\\t\\t<\\/p>\\n\\t<\\/div>\\n\\n\\t<div class=\\\"field subject\\\">\\n\\t\\t<input type=\\\"text\\\" name=\\\"subject\\\" placeholder=\\\"Subject\\\">\\n\\t<\\/div>\\n\\n\\t<div class=\\\"field email-message\\\">\\n\\t\\t<textarea name=\\\"message\\\" placeholder=\\\"Message\\\"><\\/textarea>\\n\\t<\\/div>\\n\\n\\t<div class=\\\"field checkbox local-diagnostic\\\">\\n\\t\\t<label>\\n\\t\\t\\t<input type=\\\"checkbox\\\" name=\\\"local-diagnostic\\\" value=\\\"1\\\" checked>\\n\\t\\t\\tAttach <strong>this site&#8217;s<\\/strong> Diagnostic Info &amp; Error Log (below)\\t\\t<\\/label>\\n\\t<\\/div>\\n\\t\\t<div class=\\\"field checkbox remote-diagnostic\\\">\\n\\t\\t<label>\\n\\t\\t\\t<input type=\\\"checkbox\\\" name=\\\"remote-diagnostic\\\" value=\\\"1\\\" checked>\\n\\t\\t\\tAttach the <strong>remote site&#8217;s<\\/strong> Diagnostic Info &amp; Error Log\\t\\t<\\/label>\\n\\t<\\/div>\\n\\n\\t<div class=\\\"field remote-diagnostic-content\\\">\\n\\t\\t<ol>\\n\\t\\t\\t<li>Go to the Help tab of the remote site<\\/li>\\n\\t\\t\\t<li>Copy the Diagnostic Info &amp; Error Log<\\/li>\\n\\t\\t\\t<li>Paste it below<\\/li>\\n\\t\\t<\\/ol>\\n\\t\\t<textarea name=\\\"remote-diagnostic-content\\\" placeholder=\\\"Remote site&#8217;s Diagnostic Info &amp; Error Log\\\"><\\/textarea>\\n\\t<\\/div>\\n\\t\\t<div class=\\\"submit-form\\\">\\n\\t\\t<button type=\\\"submit\\\" class=\\\"button\\\">Send Email<\\/button>\\n\\t<\\/div>\\n\\n\\t<p class=\\\"note trouble\\\">\\n\\t\\tHaving trouble submitting the form? Email your support request to <a href=\\\"mailto:priority-wpmdb@deliciousbrains.com\\\">priority-wpmdb@deliciousbrains.com<\\/a> instead.\\t<\\/p>\\n\\n<\\/form>\\n\\n<\\/section>\\n\\n\\t<aside class=\\\"additional-help\\\">\\n\\t\\t<section class=\\\"docs\\\">\\n\\t\\t\\t<h1><a href=\\\"https:\\/\\/deliciousbrains.com\\/wp-migrate-db-pro\\/docs\\/\\\">Documentation<\\/a><\\/h1>\\n\\t\\t\\t<ul class=\\\"categories\\\">\\n\\t\\t\\t\\t<li><a href=\\\"https:\\/\\/deliciousbrains.com\\/wp-migrate-db-pro\\/docs\\/getting-started\\/?utm_source=MDB%2BPaid&#038;utm_campaign=support%2Bdocs&#038;utm_medium=insideplugin\\\">Getting Started<\\/a><\\/li><li><a href=\\\"https:\\/\\/deliciousbrains.com\\/wp-migrate-db-pro\\/docs\\/debugging\\/?utm_source=MDB%2BPaid&#038;utm_campaign=support%2Bdocs&#038;utm_medium=insideplugin\\\">Debugging<\\/a><\\/li><li><a href=\\\"https:\\/\\/deliciousbrains.com\\/wp-migrate-db-pro\\/docs\\/cli\\/?utm_source=MDB%2BPaid&#038;utm_campaign=support%2Bdocs&#038;utm_medium=insideplugin\\\">CLI<\\/a><\\/li><li><a href=\\\"https:\\/\\/deliciousbrains.com\\/wp-migrate-db-pro\\/docs\\/common-errors\\/?utm_source=MDB%2BPaid&#038;utm_campaign=support%2Bdocs&#038;utm_medium=insideplugin\\\">Common Errors<\\/a><\\/li><li><a href=\\\"https:\\/\\/deliciousbrains.com\\/wp-migrate-db-pro\\/docs\\/howto\\/?utm_source=MDB%2BPaid&#038;utm_campaign=support%2Bdocs&#038;utm_medium=insideplugin\\\">How To<\\/a><\\/li><li><a href=\\\"https:\\/\\/deliciousbrains.com\\/wp-migrate-db-pro\\/docs\\/addons\\/?utm_source=MDB%2BPaid&#038;utm_campaign=support%2Bdocs&#038;utm_medium=insideplugin\\\">Addons<\\/a><\\/li><li><a href=\\\"https:\\/\\/deliciousbrains.com\\/wp-migrate-db-pro\\/docs\\/multisite\\/?utm_source=MDB%2BPaid&#038;utm_campaign=support%2Bdocs&#038;utm_medium=insideplugin\\\">Multisite<\\/a><\\/li><li><a href=\\\"https:\\/\\/deliciousbrains.com\\/wp-migrate-db-pro\\/docs\\/changelogs\\/?utm_source=MDB%2BPaid&#038;utm_campaign=support%2Bdocs&#038;utm_medium=insideplugin\\\">Changelogs<\\/a><\\/li>\\t\\t\\t<\\/ul>\\n\\t\\t<\\/section>\\n\\t<\\/aside>\\n<script>\\\"use strict\\\";!function($){var $form=$(\\\".dbrains-support-form form\\\"),$submit_div=$(\\\".submit-form\\\",$form),is_submitting=!1,$checkbox=$(\\\".remote-diagnostic input\\\",$form),$content=$(\\\".remote-diagnostic-content\\\",$form);$checkbox.on(\\\"click\\\",function(){$checkbox.prop(\\\"checked\\\")?$content.show():$content.hide()});var spinner_url=ajaxurl.replace(\\\"\\/admin-ajax.php\\\",\\\"\\/images\\/wpspin_light\\\");2<=window.devicePixelRatio&&(spinner_url+=\\\"-2x\\\"),spinner_url+=\\\".gif\\\",$form.submit(function(e){if(e.preventDefault(),!is_submitting){is_submitting=!0,$(\\\".button\\\",$form).blur();var $spinner=$(\\\".ajax-spinner\\\",$submit_div);$spinner[0]?$spinner.show():($spinner=$(\'<img src=\\\"\'+spinner_url+\'\\\" alt=\\\"\\\" class=\\\"ajax-spinner general-spinner\\\" \\/>\'),$submit_div.append($spinner)),$(\\\".submission-error\\\").hide();var required=[\\\"email\\\",\\\"subject\\\",\\\"message\\\"],form_data={},is_error=!1;$.each($form.serializeArray(),function(i,object){form_data[object.name]=object.value,-1<$.inArray(object.name,required)&&\\\"\\\"===object.value&&($(\\\".\\\"+object.name+\\\"-error\\\").fadeIn(),is_error=!0)});var is_remote_diagnostic_checked=$(\\\"input[name=remote-diagnostic]\\\",$form).is(\\\":checked\\\");if(is_remote_diagnostic_checked)if(\\\"\\\"===form_data[\\\"remote-diagnostic-content\\\"])$(\\\".remote-diagnostic-content-error\\\").fadeIn(),is_error=!0;else{var remote_first_line=form_data[\\\"remote-diagnostic-content\\\"].substr(0,form_data[\\\"remote-diagnostic-content\\\"].indexOf(\\\"\\\\n\\\")),local_textarea=$(\\\".debug-log-textarea\\\")[0],local_first_line=local_textarea.value.substr(0,local_textarea.value.indexOf(\\\"\\\\n\\\"));remote_first_line.trim()==local_first_line.trim()&&($(\\\".both-diagnostic-same-error\\\").fadeIn(),is_error=!0)}if(is_error)return $spinner.hide(),void(is_submitting=!1);is_remote_diagnostic_checked||(form_data[\\\"remote-diagnostic-content\\\"]=\\\"\\\"),$(\\\"input[name=local-diagnostic]\\\",$form).is(\\\":checked\\\")&&(form_data[\\\"local-diagnostic-content\\\"]=$(\\\".debug-log-textarea\\\").val()),$.ajax({url:$form.prop(\\\"action\\\"),type:\\\"POST\\\",dataType:\\\"JSON\\\",cache:!1,data:form_data,error:function(jqXHR,textStatus,errorThrown){var $error=$(\\\".xhr-error\\\");$(\\\"p\\\",$error).append(\\\" \\\"+errorThrown+\\\" (\\\"+textStatus+\\\")\\\"),$error.show(),$spinner.hide(),is_submitting=!1},success:function(data){if(void 0!==data.errors){var $error=$(\\\".api-error\\\");return $.each(data.errors,function(key,error_msg){return $(\\\"p\\\",$error).append(error_msg),!1}),$error.show(),$spinner.hide(),void(is_submitting=!1)}$(\\\".submission-success\\\").show(),$form.hide(),$spinner.hide(),is_submitting=!1}})}})}(jQuery);<\\/script>\"}','no');
INSERT INTO `wp_options` VALUES (872,'_transient_timeout_acf_plugin_info_pro','1614969973','no');
INSERT INTO `wp_options` VALUES (873,'_transient_acf_plugin_info_pro','a:18:{s:4:\"name\";s:26:\"Advanced Custom Fields PRO\";s:4:\"slug\";s:26:\"advanced-custom-fields-pro\";s:7:\"version\";s:5:\"5.9.5\";s:8:\"homepage\";s:36:\"https://www.advancedcustomfields.com\";s:6:\"author\";s:64:\"<a href=\"https://www.advancedcustomfields.com\">Elliot Condon</a>\";s:12:\"contributors\";a:1:{s:12:\"elliotcondon\";a:3:{s:7:\"profile\";s:36:\"https://www.advancedcustomfields.com\";s:6:\"avatar\";s:81:\"https://secure.gravatar.com/avatar/c296f449f92233e8d1102ff01c9bc71e?s=96&d=mm&r=g\";s:12:\"display_name\";s:22:\"Advanced Custom Fields\";}}s:8:\"requires\";s:3:\"4.7\";s:12:\"requires_php\";s:3:\"5.6\";s:6:\"tested\";s:3:\"5.6\";s:5:\"added\";s:10:\"2014-07-11\";s:12:\"last_updated\";s:10:\"2021-02-11\";s:11:\"description\";s:1349:\"<p>Use the Advanced Custom Fields plugin to take full control of your WordPress edit screens & custom field data.</p>\n\n<p><strong>Add fields on demand.</strong> Our field builder allows you to quickly and easily add fields to WP edit screens with only the click of a few buttons!</p>\n\n<p><strong>Add them anywhere.</strong> Fields can be added all over WP including posts, users, taxonomy terms, media, comments and even custom options pages!</p>\n\n<p><strong>Show them everywhere.</strong> Load and display your custom field values in any theme template file with our hassle free developer friendly functions!</p>\n\n<h4>Features</h4>\n<ul>\n<li>Simple & Intuitive</li>\n<li>Powerful Functions</li>\n<li>Over 30 Field Types</li>\n<li>Extensive Documentation</li>\n<li>Millions of Users</li>\n</ul>\n\n<h4>Links</h4>\n<ul>\n<li><a href=\"https://www.advancedcustomfields.com\">Website</a></li>\n<li><a href=\"https://www.advancedcustomfields.com/resources/\">Documentation</a></li>\n<li><a href=\"https://support.advancedcustomfields.com\">Support</a></li>\n<li><a href=\"https://www.advancedcustomfields.com/pro/\">ACF PRO</a></li>\n</ul>\n\n<h4>PRO</h4>\n<p>The Advanced Custom Fields plugin is also available in a professional version which includes more fields, more functionality, and more flexibility! <a href=\"https://www.advancedcustomfields.com/pro/\">Learn more</a></p>\";s:12:\"installation\";s:503:\"<p>From your WordPress dashboard</p>\n\n<ol>\n<li><strong>Visit</strong> Plugins > Add New</li>\n<li><strong>Search</strong> for \"Advanced Custom Fields\"</li>\n<li><strong>Activate</strong> Advanced Custom Fields from your Plugins page</li>\n<li><strong>Click</strong> on the new menu item \"Custom Fields\" and create your first Custom Field Group!</li>\n<li><strong>Read</strong> the documentation to <a href=\"https://www.advancedcustomfields.com/resources/getting-started-with-acf/\">get started</a></li>\n</ol>\";s:9:\"changelog\";s:5158:\"<h4>5.9.5</h4>\n<p><em>Release Date - 11 February 2021</em></p>\n\n<ul>\n<li>Fix - Fixed regression preventing blocks from loading correctly within the editor in WordPress 5.5.</li>\n<li>Fix - Fixed bug causing incorrect post_status properties when restoring a Field Group from trash in WordPress 5.6.</li>\n<li>Fix - Fixed edge case bug where a taxonomy named \"options\" could interfere with saving and loading option values.</li>\n<li>Fix - Fixed additional PHP 8.0 warnings.</li>\n<li>i18n - Updated Finnish translation thanks to Mikko Kekki</li>\n</ul>\n\n<h4>5.9.4</h4>\n<p><em>Release Date - 14 January 2021</em></p>\n\n<ul>\n<li>Enhancement - Added PHP validation for the Email field (previously relied solely on browser validation).</li>\n<li>Fix - Added support for PHP 8.0 (fixed logged warnings).</li>\n<li>Fix - Added support for jQuery 3.5 (fixed logged warnings).</li>\n<li>Fix - Fixed bug causing WYSIWYG field to appear unresponsive within the Gutenberg editor.</li>\n<li>Fix - Fixed regression preventing \"blog_%d\" and \"site_%d\" as valid <code>$post_id</code> values for custom Taxonomy terms.</li>\n<li>Fix - Fixed bug causing Radio field label to select first choice.</li>\n<li>Fix - Fixed bug preventing preloading blocks that contain multiple parent DOM elements.</li>\n<li>i18n - Updated Japanese translation thanks to Ryo Takahashi.</li>\n<li>i18n - Updated Portuguese translation thanks to Pedro Mendonça.</li>\n</ul>\n\n<h4>5.9.3</h4>\n<p><em>Release Date - 3 November 2020</em></p>\n\n<ul>\n<li>Fix - Fixed bug causing Revision meta to incorrectly update the parent Post meta.</li>\n<li>Fix - Fixed bug breaking \"Filter by Post Type\" and \"Filter by Taxonomy\" Field settings.</li>\n</ul>\n<p>* Added toolbar across all ACF admin pages.</p>\n<p>* Added new table columns: Description, Key, Location, Local JSON.</p>\n<p>* Added popup modal to review Local JSON changes before sync.</p>\n<p>* Added visual representation of where Field Groups will appear.</p>\n<p>* Added new help tab.</p>\n<p>* Simplified layout.</p>\n<ul>\n<li>Enhancement - New ACF Blocks features.</li>\n</ul>\n<p>* Added support for Inner Blocks.</p>\n<p>* Added new \"jsx\" setting.</p>\n<p>* Added new \"align_text\" settings.</p>\n<p>* Added new \"align_content\" settings.</p>\n<ul>\n<li>Enhancement - Added duplicate functionality for Repeater and Flexible Content fields.</li>\n<li>Enhancement - Added PHP validation support for Gutenberg.</li>\n<li>Enhancement - Added ability to bypass confirmation tooltips (just hold shift).</li>\n<li>Enhancement - Local JSON files now save back to their loaded source path (not \"save_json\" setting).</li>\n<li>Tweak - Replaced all custom icons with dashicons.</li>\n<li>Tweak - Changed custom post status label from \"Inactive\" to \"Disabled\".</li>\n<li>Tweak - Improved styling of metaboxes positioned in the block editor sidebar.</li>\n<li>Fix - Improved AJAX request efficiency when editing block className or anchor attributes.</li>\n<li>Fix - Fixed bug causing unresponsive WYSIWYG fields after moving a block via the up/down arrows.</li>\n<li>Fix - Fixed bug causing HTML to jump between multiple instances of the same Reusable Block.</li>\n<li>Fix - Fixed bug sometimes displaying validation errors when saving a draft.</li>\n<li>Fix - Fixed bug breaking Image field UI when displaying a scaled portrait attachment.</li>\n<li>Fix - Fixed bug in Link field incorrectly treating the \"Cancel\" button as \"Submit\".</li>\n<li>Fix - Fixed bug where a sub field within a collapsed Repeater row did not grow to the full available width.</li>\n<li>Fix - Ensured all archive URLs shown in the Page Link field dropdown are unique.</li>\n<li>Fix - Fixed bug causing incorrect conditional logic settings on nested fields when duplicating a Field Group.</li>\n<li>Fix - Fixed bug causing license activation issues with some password management browser extensions.</li>\n<li>Dev - Major improvements to <code>ACF_Location</code> class.</li>\n<li>Dev - Refactored all location classes to optimize performance.</li>\n<li>Dev - Extracted core JavaScript from \"acf-input.js\" into a separate \"acf.js\" file.</li>\n<li>Dev - Field Group export now shows \"active\" attribute as bool instead of int.</li>\n<li>Dev - Added filter \"acf/get_object_type\" to customize WP object information such as \"label\" and \"icon\".</li>\n<li>Dev - Added action \"acf/admin_print_uploader_scripts\" fired when printing uploader (WP media) scripts in the footer.</li>\n<li>Dev - Added filters \"acf/pre_load_attachment\" and \"acf/load_attachment\" to customize attachment details.</li>\n<li>Dev - Added filter \"acf/admin/toolbar\" to customize the admin toolbar items.</li>\n<li>Dev - Added new JS actions \"duplicate_fields\" and \"duplicate_field\" fired when duplicating a row.</li>\n<li>i18n - Changed Croatian locale code from \"hr_HR to \"hr\".</li>\n<li>i18n - Updated Portuguese translation thanks to Pedro Mendonça.</li>\n<li>i18n - Updated French Canadian translation thanks to Bérenger Zyla.</li>\n<li>i18n - Updated French translation thanks to Maxime Bernard-Jacquet.</li>\n<li>i18n - Updated German translations thanks to Ralf Koller.</li>\n</ul>\n\n<p><a href=\"https://www.advancedcustomfields.com/changelog/\">View the full changelog</a></p>\";s:14:\"upgrade_notice\";s:0:\"\";s:5:\"icons\";a:1:{s:7:\"default\";s:63:\"https://ps.w.org/advanced-custom-fields/assets/icon-256x256.png\";}s:7:\"banners\";a:2:{s:3:\"low\";s:77:\"https://ps.w.org/advanced-custom-fields/assets/banner-772x250.jpg?rev=1729102\";s:4:\"high\";s:78:\"https://ps.w.org/advanced-custom-fields/assets/banner-1544x500.jpg?rev=1729099\";}s:8:\"versions\";a:122:{i:0;s:5:\"5.9.4\";i:1;s:5:\"5.9.3\";i:2;s:5:\"5.9.2\";i:3;s:5:\"5.9.1\";i:4;s:11:\"5.9.0-beta5\";i:5;s:11:\"5.9.0-beta4\";i:6;s:11:\"5.9.0-beta3\";i:7;s:11:\"5.9.0-beta2\";i:8;s:11:\"5.9.0-beta1\";i:9;s:9:\"5.9.0-RC1\";i:10;s:5:\"5.9.0\";i:11;s:5:\"5.8.9\";i:12;s:5:\"5.8.8\";i:13;s:5:\"5.8.7\";i:14;s:5:\"5.8.6\";i:15;s:5:\"5.8.5\";i:16;s:5:\"5.8.4\";i:17;s:5:\"5.8.3\";i:18;s:5:\"5.8.2\";i:19;s:6:\"5.8.14\";i:20;s:6:\"5.8.13\";i:21;s:6:\"5.8.12\";i:22;s:6:\"5.8.11\";i:23;s:5:\"5.8.1\";i:24;s:13:\"5.8.0-beta4.1\";i:25;s:11:\"5.8.0-beta4\";i:26;s:11:\"5.8.0-beta3\";i:27;s:11:\"5.8.0-beta2\";i:28;s:11:\"5.8.0-beta1\";i:29;s:9:\"5.8.0-RC2\";i:30;s:9:\"5.8.0-RC1\";i:31;s:5:\"5.8.0\";i:32;s:5:\"5.7.9\";i:33;s:5:\"5.7.8\";i:34;s:5:\"5.7.7\";i:35;s:5:\"5.7.6\";i:36;s:5:\"5.7.5\";i:37;s:5:\"5.7.4\";i:38;s:5:\"5.7.3\";i:39;s:5:\"5.7.2\";i:40;s:6:\"5.7.13\";i:41;s:6:\"5.7.12\";i:42;s:6:\"5.7.10\";i:43;s:5:\"5.7.1\";i:44;s:5:\"5.7.0\";i:45;s:5:\"5.6.9\";i:46;s:5:\"5.6.8\";i:47;s:5:\"5.6.7\";i:48;s:5:\"5.6.6\";i:49;s:5:\"5.6.5\";i:50;s:5:\"5.6.4\";i:51;s:5:\"5.6.3\";i:52;s:5:\"5.6.2\";i:53;s:6:\"5.6.10\";i:54;s:5:\"5.6.1\";i:55;s:11:\"5.6.0-beta2\";i:56;s:11:\"5.6.0-beta1\";i:57;s:9:\"5.6.0-RC2\";i:58;s:9:\"5.6.0-RC1\";i:59;s:5:\"5.6.0\";i:60;s:5:\"5.5.9\";i:61;s:5:\"5.5.7\";i:62;s:5:\"5.5.5\";i:63;s:5:\"5.5.3\";i:64;s:5:\"5.5.2\";i:65;s:6:\"5.5.14\";i:66;s:6:\"5.5.13\";i:67;s:6:\"5.5.12\";i:68;s:6:\"5.5.11\";i:69;s:6:\"5.5.10\";i:70;s:5:\"5.5.1\";i:71;s:5:\"5.5.0\";i:72;s:5:\"5.4.8\";i:73;s:5:\"5.4.7\";i:74;s:5:\"5.4.6\";i:75;s:5:\"5.4.5\";i:76;s:5:\"5.4.4\";i:77;s:5:\"5.4.3\";i:78;s:5:\"5.4.2\";i:79;s:5:\"5.4.1\";i:80;s:5:\"5.4.0\";i:81;s:5:\"5.3.9\";i:82;s:5:\"5.3.8\";i:83;s:5:\"5.3.7\";i:84;s:5:\"5.3.6\";i:85;s:5:\"5.3.5\";i:86;s:5:\"5.3.4\";i:87;s:5:\"5.3.3\";i:88;s:5:\"5.3.2\";i:89;s:6:\"5.3.10\";i:90;s:5:\"5.3.1\";i:91;s:5:\"5.3.0\";i:92;s:5:\"5.2.9\";i:93;s:5:\"5.2.8\";i:94;s:5:\"5.2.7\";i:95;s:5:\"5.2.6\";i:96;s:5:\"5.2.5\";i:97;s:5:\"5.2.4\";i:98;s:5:\"5.2.3\";i:99;s:5:\"5.2.2\";i:100;s:5:\"5.2.1\";i:101;s:5:\"5.2.0\";i:102;s:5:\"5.1.9\";i:103;s:5:\"5.1.8\";i:104;s:5:\"5.1.7\";i:105;s:5:\"5.1.6\";i:106;s:5:\"5.1.5\";i:107;s:5:\"5.1.4\";i:108;s:5:\"5.1.3\";i:109;s:5:\"5.1.2\";i:110;s:5:\"5.1.1\";i:111;s:5:\"5.1.0\";i:112;s:5:\"5.0.9\";i:113;s:5:\"5.0.8\";i:114;s:5:\"5.0.7\";i:115;s:5:\"5.0.6\";i:116;s:5:\"5.0.5\";i:117;s:5:\"5.0.4\";i:118;s:5:\"5.0.3\";i:119;s:5:\"5.0.2\";i:120;s:5:\"5.0.1\";i:121;s:5:\"5.0.0\";}}','no');
INSERT INTO `wp_options` VALUES (876,'acf_pro_license','YToyOntzOjM6ImtleSI7czo3MjoiYjNKa1pYSmZhV1E5TXpNM05EVjhkSGx3WlQxd1pYSnpiMjVoYkh4a1lYUmxQVEl3TVRRdE1EY3RNRGdnTVRRNk5EVTZNems9IjtzOjM6InVybCI7czoyMjoiaHR0cDovL2xvY2FsaG9zdDoxMDAwOCI7fQ==','yes');
INSERT INTO `wp_options` VALUES (877,'_transient_timeout_acf_plugin_updates','1615056396','no');
INSERT INTO `wp_options` VALUES (878,'_transient_acf_plugin_updates','a:4:{s:7:\"plugins\";a:0:{}s:10:\"expiration\";i:172800;s:6:\"status\";i:1;s:7:\"checked\";a:1:{s:34:\"advanced-custom-fields-pro/acf.php\";s:5:\"5.9.5\";}}','no');
INSERT INTO `wp_options` VALUES (983,'gf_previous_db_version','2.4.18','yes');
INSERT INTO `wp_options` VALUES (984,'gf_upgrade_lock','','yes');
INSERT INTO `wp_options` VALUES (985,'gform_sticky_admin_messages','a:0:{}','yes');
INSERT INTO `wp_options` VALUES (991,'_site_transient_timeout_poptags_40cd750bba9870f18aada2478b24840a','1614894720','no');
INSERT INTO `wp_options` VALUES (992,'_site_transient_poptags_40cd750bba9870f18aada2478b24840a','O:8:\"stdClass\":100:{s:6:\"widget\";a:3:{s:4:\"name\";s:6:\"widget\";s:4:\"slug\";s:6:\"widget\";s:5:\"count\";i:4751;}s:11:\"woocommerce\";a:3:{s:4:\"name\";s:11:\"woocommerce\";s:4:\"slug\";s:11:\"woocommerce\";s:5:\"count\";i:4737;}s:4:\"post\";a:3:{s:4:\"name\";s:4:\"post\";s:4:\"slug\";s:4:\"post\";s:5:\"count\";i:2712;}s:5:\"admin\";a:3:{s:4:\"name\";s:5:\"admin\";s:4:\"slug\";s:5:\"admin\";s:5:\"count\";i:2583;}s:5:\"posts\";a:3:{s:4:\"name\";s:5:\"posts\";s:4:\"slug\";s:5:\"posts\";s:5:\"count\";i:1995;}s:9:\"shortcode\";a:3:{s:4:\"name\";s:9:\"shortcode\";s:4:\"slug\";s:9:\"shortcode\";s:5:\"count\";i:1844;}s:8:\"comments\";a:3:{s:4:\"name\";s:8:\"comments\";s:4:\"slug\";s:8:\"comments\";s:5:\"count\";i:1822;}s:6:\"images\";a:3:{s:4:\"name\";s:6:\"images\";s:4:\"slug\";s:6:\"images\";s:5:\"count\";i:1503;}s:6:\"google\";a:3:{s:4:\"name\";s:6:\"google\";s:4:\"slug\";s:6:\"google\";s:5:\"count\";i:1502;}s:7:\"twitter\";a:3:{s:4:\"name\";s:7:\"twitter\";s:4:\"slug\";s:7:\"twitter\";s:5:\"count\";i:1496;}s:3:\"seo\";a:3:{s:4:\"name\";s:3:\"seo\";s:4:\"slug\";s:3:\"seo\";s:5:\"count\";i:1480;}s:5:\"image\";a:3:{s:4:\"name\";s:5:\"image\";s:4:\"slug\";s:5:\"image\";s:5:\"count\";i:1473;}s:8:\"facebook\";a:3:{s:4:\"name\";s:8:\"facebook\";s:4:\"slug\";s:8:\"facebook\";s:5:\"count\";i:1463;}s:7:\"sidebar\";a:3:{s:4:\"name\";s:7:\"sidebar\";s:4:\"slug\";s:7:\"sidebar\";s:5:\"count\";i:1309;}s:5:\"email\";a:3:{s:4:\"name\";s:5:\"email\";s:4:\"slug\";s:5:\"email\";s:5:\"count\";i:1248;}s:7:\"gallery\";a:3:{s:4:\"name\";s:7:\"gallery\";s:4:\"slug\";s:7:\"gallery\";s:5:\"count\";i:1220;}s:9:\"ecommerce\";a:3:{s:4:\"name\";s:9:\"ecommerce\";s:4:\"slug\";s:9:\"ecommerce\";s:5:\"count\";i:1215;}s:4:\"page\";a:3:{s:4:\"name\";s:4:\"page\";s:4:\"slug\";s:4:\"page\";s:5:\"count\";i:1151;}s:6:\"social\";a:3:{s:4:\"name\";s:6:\"social\";s:4:\"slug\";s:6:\"social\";s:5:\"count\";i:1118;}s:5:\"login\";a:3:{s:4:\"name\";s:5:\"login\";s:4:\"slug\";s:5:\"login\";s:5:\"count\";i:1040;}s:8:\"security\";a:3:{s:4:\"name\";s:8:\"security\";s:4:\"slug\";s:8:\"security\";s:5:\"count\";i:935;}s:5:\"video\";a:3:{s:4:\"name\";s:5:\"video\";s:4:\"slug\";s:5:\"video\";s:5:\"count\";i:922;}s:7:\"widgets\";a:3:{s:4:\"name\";s:7:\"widgets\";s:4:\"slug\";s:7:\"widgets\";s:5:\"count\";i:899;}s:5:\"links\";a:3:{s:4:\"name\";s:5:\"links\";s:4:\"slug\";s:5:\"links\";s:5:\"count\";i:884;}s:10:\"e-commerce\";a:3:{s:4:\"name\";s:10:\"e-commerce\";s:4:\"slug\";s:10:\"e-commerce\";s:5:\"count\";i:859;}s:4:\"spam\";a:3:{s:4:\"name\";s:4:\"spam\";s:4:\"slug\";s:4:\"spam\";s:5:\"count\";i:813;}s:6:\"slider\";a:3:{s:4:\"name\";s:6:\"slider\";s:4:\"slug\";s:6:\"slider\";s:5:\"count\";i:807;}s:7:\"content\";a:3:{s:4:\"name\";s:7:\"content\";s:4:\"slug\";s:7:\"content\";s:5:\"count\";i:801;}s:9:\"analytics\";a:3:{s:4:\"name\";s:9:\"analytics\";s:4:\"slug\";s:9:\"analytics\";s:5:\"count\";i:795;}s:4:\"form\";a:3:{s:4:\"name\";s:4:\"form\";s:4:\"slug\";s:4:\"form\";s:5:\"count\";i:776;}s:10:\"buddypress\";a:3:{s:4:\"name\";s:10:\"buddypress\";s:4:\"slug\";s:10:\"buddypress\";s:5:\"count\";i:758;}s:5:\"media\";a:3:{s:4:\"name\";s:5:\"media\";s:4:\"slug\";s:5:\"media\";s:5:\"count\";i:738;}s:3:\"rss\";a:3:{s:4:\"name\";s:3:\"rss\";s:4:\"slug\";s:3:\"rss\";s:5:\"count\";i:726;}s:6:\"search\";a:3:{s:4:\"name\";s:6:\"search\";s:4:\"slug\";s:6:\"search\";s:5:\"count\";i:717;}s:5:\"pages\";a:3:{s:4:\"name\";s:5:\"pages\";s:4:\"slug\";s:5:\"pages\";s:5:\"count\";i:710;}s:6:\"editor\";a:3:{s:4:\"name\";s:6:\"editor\";s:4:\"slug\";s:6:\"editor\";s:5:\"count\";i:704;}s:4:\"menu\";a:3:{s:4:\"name\";s:4:\"menu\";s:4:\"slug\";s:4:\"menu\";s:5:\"count\";i:674;}s:6:\"jquery\";a:3:{s:4:\"name\";s:6:\"jquery\";s:4:\"slug\";s:6:\"jquery\";s:5:\"count\";i:663;}s:4:\"feed\";a:3:{s:4:\"name\";s:4:\"feed\";s:4:\"slug\";s:4:\"feed\";s:5:\"count\";i:661;}s:8:\"category\";a:3:{s:4:\"name\";s:8:\"category\";s:4:\"slug\";s:8:\"category\";s:5:\"count\";i:656;}s:7:\"payment\";a:3:{s:4:\"name\";s:7:\"payment\";s:4:\"slug\";s:7:\"payment\";s:5:\"count\";i:651;}s:12:\"contact-form\";a:3:{s:4:\"name\";s:12:\"contact form\";s:4:\"slug\";s:12:\"contact-form\";s:5:\"count\";i:650;}s:5:\"embed\";a:3:{s:4:\"name\";s:5:\"embed\";s:4:\"slug\";s:5:\"embed\";s:5:\"count\";i:644;}s:4:\"ajax\";a:3:{s:4:\"name\";s:4:\"ajax\";s:4:\"slug\";s:4:\"ajax\";s:5:\"count\";i:643;}s:9:\"gutenberg\";a:3:{s:4:\"name\";s:9:\"gutenberg\";s:4:\"slug\";s:9:\"gutenberg\";s:5:\"count\";i:612;}s:3:\"css\";a:3:{s:4:\"name\";s:3:\"css\";s:4:\"slug\";s:3:\"css\";s:5:\"count\";i:595;}s:7:\"youtube\";a:3:{s:4:\"name\";s:7:\"youtube\";s:4:\"slug\";s:7:\"youtube\";s:5:\"count\";i:593;}s:4:\"link\";a:3:{s:4:\"name\";s:4:\"link\";s:4:\"slug\";s:4:\"link\";s:5:\"count\";i:587;}s:10:\"javascript\";a:3:{s:4:\"name\";s:10:\"javascript\";s:4:\"slug\";s:10:\"javascript\";s:5:\"count\";i:586;}s:15:\"payment-gateway\";a:3:{s:4:\"name\";s:15:\"payment gateway\";s:4:\"slug\";s:15:\"payment-gateway\";s:5:\"count\";i:582;}s:9:\"affiliate\";a:3:{s:4:\"name\";s:9:\"affiliate\";s:4:\"slug\";s:9:\"affiliate\";s:5:\"count\";i:571;}s:5:\"share\";a:3:{s:4:\"name\";s:5:\"share\";s:4:\"slug\";s:5:\"share\";s:5:\"count\";i:564;}s:10:\"responsive\";a:3:{s:4:\"name\";s:10:\"responsive\";s:4:\"slug\";s:10:\"responsive\";s:5:\"count\";i:562;}s:5:\"theme\";a:3:{s:4:\"name\";s:5:\"theme\";s:4:\"slug\";s:5:\"theme\";s:5:\"count\";i:560;}s:7:\"comment\";a:3:{s:4:\"name\";s:7:\"comment\";s:4:\"slug\";s:7:\"comment\";s:5:\"count\";i:556;}s:9:\"dashboard\";a:3:{s:4:\"name\";s:9:\"dashboard\";s:4:\"slug\";s:9:\"dashboard\";s:5:\"count\";i:553;}s:3:\"ads\";a:3:{s:4:\"name\";s:3:\"ads\";s:4:\"slug\";s:3:\"ads\";s:5:\"count\";i:540;}s:3:\"api\";a:3:{s:4:\"name\";s:3:\"api\";s:4:\"slug\";s:3:\"api\";s:5:\"count\";i:539;}s:7:\"contact\";a:3:{s:4:\"name\";s:7:\"contact\";s:4:\"slug\";s:7:\"contact\";s:5:\"count\";i:538;}s:6:\"custom\";a:3:{s:4:\"name\";s:6:\"custom\";s:4:\"slug\";s:6:\"custom\";s:5:\"count\";i:537;}s:10:\"categories\";a:3:{s:4:\"name\";s:10:\"categories\";s:4:\"slug\";s:10:\"categories\";s:5:\"count\";i:530;}s:4:\"user\";a:3:{s:4:\"name\";s:4:\"user\";s:4:\"slug\";s:4:\"user\";s:5:\"count\";i:513;}s:6:\"button\";a:3:{s:4:\"name\";s:6:\"button\";s:4:\"slug\";s:6:\"button\";s:5:\"count\";i:503;}s:4:\"tags\";a:3:{s:4:\"name\";s:4:\"tags\";s:4:\"slug\";s:4:\"tags\";s:5:\"count\";i:497;}s:6:\"events\";a:3:{s:4:\"name\";s:6:\"events\";s:4:\"slug\";s:6:\"events\";s:5:\"count\";i:494;}s:6:\"mobile\";a:3:{s:4:\"name\";s:6:\"mobile\";s:4:\"slug\";s:6:\"mobile\";s:5:\"count\";i:490;}s:5:\"users\";a:3:{s:4:\"name\";s:5:\"users\";s:4:\"slug\";s:5:\"users\";s:5:\"count\";i:486;}s:9:\"marketing\";a:3:{s:4:\"name\";s:9:\"marketing\";s:4:\"slug\";s:9:\"marketing\";s:5:\"count\";i:483;}s:9:\"elementor\";a:3:{s:4:\"name\";s:9:\"elementor\";s:4:\"slug\";s:9:\"elementor\";s:5:\"count\";i:478;}s:5:\"block\";a:3:{s:4:\"name\";s:5:\"block\";s:4:\"slug\";s:5:\"block\";s:5:\"count\";i:477;}s:4:\"chat\";a:3:{s:4:\"name\";s:4:\"chat\";s:4:\"slug\";s:4:\"chat\";s:5:\"count\";i:469;}s:5:\"popup\";a:3:{s:4:\"name\";s:5:\"popup\";s:4:\"slug\";s:5:\"popup\";s:5:\"count\";i:454;}s:8:\"calendar\";a:3:{s:4:\"name\";s:8:\"calendar\";s:4:\"slug\";s:8:\"calendar\";s:5:\"count\";i:453;}s:5:\"forms\";a:3:{s:4:\"name\";s:5:\"forms\";s:4:\"slug\";s:5:\"forms\";s:5:\"count\";i:449;}s:5:\"photo\";a:3:{s:4:\"name\";s:5:\"photo\";s:4:\"slug\";s:5:\"photo\";s:5:\"count\";i:445;}s:10:\"navigation\";a:3:{s:4:\"name\";s:10:\"navigation\";s:4:\"slug\";s:10:\"navigation\";s:5:\"count\";i:442;}s:9:\"slideshow\";a:3:{s:4:\"name\";s:9:\"slideshow\";s:4:\"slug\";s:9:\"slideshow\";s:5:\"count\";i:439;}s:14:\"contact-form-7\";a:3:{s:4:\"name\";s:14:\"contact form 7\";s:4:\"slug\";s:14:\"contact-form-7\";s:5:\"count\";i:438;}s:10:\"newsletter\";a:3:{s:4:\"name\";s:10:\"newsletter\";s:4:\"slug\";s:10:\"newsletter\";s:5:\"count\";i:436;}s:5:\"stats\";a:3:{s:4:\"name\";s:5:\"stats\";s:4:\"slug\";s:5:\"stats\";s:5:\"count\";i:433;}s:6:\"photos\";a:3:{s:4:\"name\";s:6:\"photos\";s:4:\"slug\";s:6:\"photos\";s:5:\"count\";i:424;}s:8:\"shipping\";a:3:{s:4:\"name\";s:8:\"shipping\";s:4:\"slug\";s:8:\"shipping\";s:5:\"count\";i:420;}s:10:\"statistics\";a:3:{s:4:\"name\";s:10:\"statistics\";s:4:\"slug\";s:10:\"statistics\";s:5:\"count\";i:419;}s:12:\"social-media\";a:3:{s:4:\"name\";s:12:\"social media\";s:4:\"slug\";s:12:\"social-media\";s:5:\"count\";i:404;}s:4:\"news\";a:3:{s:4:\"name\";s:4:\"news\";s:4:\"slug\";s:4:\"news\";s:5:\"count\";i:404;}s:11:\"performance\";a:3:{s:4:\"name\";s:11:\"performance\";s:4:\"slug\";s:11:\"performance\";s:5:\"count\";i:403;}s:8:\"redirect\";a:3:{s:4:\"name\";s:8:\"redirect\";s:4:\"slug\";s:8:\"redirect\";s:5:\"count\";i:402;}s:10:\"shortcodes\";a:3:{s:4:\"name\";s:10:\"shortcodes\";s:4:\"slug\";s:10:\"shortcodes\";s:5:\"count\";i:400;}s:12:\"notification\";a:3:{s:4:\"name\";s:12:\"notification\";s:4:\"slug\";s:12:\"notification\";s:5:\"count\";i:391;}s:4:\"code\";a:3:{s:4:\"name\";s:4:\"code\";s:4:\"slug\";s:4:\"code\";s:5:\"count\";i:390;}s:7:\"plugins\";a:3:{s:4:\"name\";s:7:\"plugins\";s:4:\"slug\";s:7:\"plugins\";s:5:\"count\";i:384;}s:3:\"url\";a:3:{s:4:\"name\";s:3:\"url\";s:4:\"slug\";s:3:\"url\";s:5:\"count\";i:380;}s:9:\"multisite\";a:3:{s:4:\"name\";s:9:\"multisite\";s:4:\"slug\";s:9:\"multisite\";s:5:\"count\";i:379;}s:4:\"meta\";a:3:{s:4:\"name\";s:4:\"meta\";s:4:\"slug\";s:4:\"meta\";s:5:\"count\";i:369;}s:8:\"tracking\";a:3:{s:4:\"name\";s:8:\"tracking\";s:4:\"slug\";s:8:\"tracking\";s:5:\"count\";i:364;}s:4:\"list\";a:3:{s:4:\"name\";s:4:\"list\";s:4:\"slug\";s:4:\"list\";s:5:\"count\";i:363;}s:6:\"import\";a:3:{s:4:\"name\";s:6:\"import\";s:4:\"slug\";s:6:\"import\";s:5:\"count\";i:361;}s:16:\"google-analytics\";a:3:{s:4:\"name\";s:16:\"google analytics\";s:4:\"slug\";s:16:\"google-analytics\";s:5:\"count\";i:355;}s:5:\"cache\";a:3:{s:4:\"name\";s:5:\"cache\";s:4:\"slug\";s:5:\"cache\";s:5:\"count\";i:351;}s:16:\"custom-post-type\";a:3:{s:4:\"name\";s:16:\"custom post type\";s:4:\"slug\";s:16:\"custom-post-type\";s:5:\"count\";i:346;}}','no');
INSERT INTO `wp_options` VALUES (999,'_site_transient_update_plugins','O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1614883953;s:7:\"checked\";a:17:{s:51:\"acf-gravityforms-add-on/acf-gravityforms-add-on.php\";s:5:\"1.2.7\";s:34:\"advanced-custom-fields-pro/acf.php\";s:5:\"5.9.5\";s:35:\"backupwordpress/backupwordpress.php\";s:4:\"3.10\";s:47:\"better-rest-endpoints/better-rest-endpoints.php\";s:5:\"1.5.2\";s:33:\"classic-editor/classic-editor.php\";s:3:\"1.6\";s:32:\"duplicate-page/duplicatepage.php\";s:3:\"4.3\";s:29:\"gravityforms/gravityforms.php\";s:6:\"2.4.23\";s:50:\"gravity-forms-zero-spam/gravityforms-zero-spam.php\";s:5:\"1.0.5\";s:47:\"regenerate-thumbnails/regenerate-thumbnails.php\";s:5:\"3.1.4\";s:21:\"safe-svg/safe-svg.php\";s:5:\"1.9.9\";s:45:\"simple-page-ordering/simple-page-ordering.php\";s:5:\"2.3.4\";s:35:\"google-site-kit/google-site-kit.php\";s:6:\"1.27.0\";s:25:\"wp-smush-pro/wp-smush.php\";s:5:\"3.8.3\";s:39:\"wp-migrate-db-pro/wp-migrate-db-pro.php\";s:6:\"1.9.14\";s:63:\"wp-migrate-db-pro-media-files/wp-migrate-db-pro-media-files.php\";s:6:\"1.4.16\";s:40:\"wpmudev-updates/update-notifications.php\";s:6:\"4.10.6\";s:24:\"wordpress-seo/wp-seo.php\";s:6:\"15.9.1\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}s:9:\"no_update\";a:11:{s:51:\"acf-gravityforms-add-on/acf-gravityforms-add-on.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:37:\"w.org/plugins/acf-gravityforms-add-on\";s:4:\"slug\";s:23:\"acf-gravityforms-add-on\";s:6:\"plugin\";s:51:\"acf-gravityforms-add-on/acf-gravityforms-add-on.php\";s:11:\"new_version\";s:5:\"1.2.7\";s:3:\"url\";s:54:\"https://wordpress.org/plugins/acf-gravityforms-add-on/\";s:7:\"package\";s:72:\"https://downloads.wordpress.org/plugin/acf-gravityforms-add-on.1.2.7.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:76:\"https://ps.w.org/acf-gravityforms-add-on/assets/icon-256x256.png?rev=1631911\";s:2:\"1x\";s:76:\"https://ps.w.org/acf-gravityforms-add-on/assets/icon-128x128.png?rev=1631911\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:79:\"https://ps.w.org/acf-gravityforms-add-on/assets/banner-1544x500.png?rev=1631911\";s:2:\"1x\";s:78:\"https://ps.w.org/acf-gravityforms-add-on/assets/banner-772x250.png?rev=1631911\";}s:11:\"banners_rtl\";a:0:{}}s:35:\"backupwordpress/backupwordpress.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:29:\"w.org/plugins/backupwordpress\";s:4:\"slug\";s:15:\"backupwordpress\";s:6:\"plugin\";s:35:\"backupwordpress/backupwordpress.php\";s:11:\"new_version\";s:4:\"3.10\";s:3:\"url\";s:46:\"https://wordpress.org/plugins/backupwordpress/\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/plugin/backupwordpress.3.10.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:68:\"https://ps.w.org/backupwordpress/assets/icon-256x256.jpg?rev=1105225\";s:2:\"1x\";s:68:\"https://ps.w.org/backupwordpress/assets/icon-128x128.png?rev=1105225\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:70:\"https://ps.w.org/backupwordpress/assets/banner-1544x500.jpg?rev=904756\";s:2:\"1x\";s:69:\"https://ps.w.org/backupwordpress/assets/banner-772x250.jpg?rev=904756\";}s:11:\"banners_rtl\";a:0:{}}s:47:\"better-rest-endpoints/better-rest-endpoints.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:35:\"w.org/plugins/better-rest-endpoints\";s:4:\"slug\";s:21:\"better-rest-endpoints\";s:6:\"plugin\";s:47:\"better-rest-endpoints/better-rest-endpoints.php\";s:11:\"new_version\";s:5:\"1.5.2\";s:3:\"url\";s:52:\"https://wordpress.org/plugins/better-rest-endpoints/\";s:7:\"package\";s:70:\"https://downloads.wordpress.org/plugin/better-rest-endpoints.1.5.2.zip\";s:5:\"icons\";a:2:{s:2:\"1x\";s:66:\"https://ps.w.org/better-rest-endpoints/assets/icon.svg?rev=1805932\";s:3:\"svg\";s:66:\"https://ps.w.org/better-rest-endpoints/assets/icon.svg?rev=1805932\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:77:\"https://ps.w.org/better-rest-endpoints/assets/banner-1544x500.png?rev=1805932\";s:2:\"1x\";s:76:\"https://ps.w.org/better-rest-endpoints/assets/banner-772x250.png?rev=1805932\";}s:11:\"banners_rtl\";a:0:{}}s:33:\"classic-editor/classic-editor.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:28:\"w.org/plugins/classic-editor\";s:4:\"slug\";s:14:\"classic-editor\";s:6:\"plugin\";s:33:\"classic-editor/classic-editor.php\";s:11:\"new_version\";s:3:\"1.6\";s:3:\"url\";s:45:\"https://wordpress.org/plugins/classic-editor/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/plugin/classic-editor.1.6.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:67:\"https://ps.w.org/classic-editor/assets/icon-256x256.png?rev=1998671\";s:2:\"1x\";s:67:\"https://ps.w.org/classic-editor/assets/icon-128x128.png?rev=1998671\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:70:\"https://ps.w.org/classic-editor/assets/banner-1544x500.png?rev=1998671\";s:2:\"1x\";s:69:\"https://ps.w.org/classic-editor/assets/banner-772x250.png?rev=1998676\";}s:11:\"banners_rtl\";a:0:{}}s:32:\"duplicate-page/duplicatepage.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:28:\"w.org/plugins/duplicate-page\";s:4:\"slug\";s:14:\"duplicate-page\";s:6:\"plugin\";s:32:\"duplicate-page/duplicatepage.php\";s:11:\"new_version\";s:3:\"4.3\";s:3:\"url\";s:45:\"https://wordpress.org/plugins/duplicate-page/\";s:7:\"package\";s:57:\"https://downloads.wordpress.org/plugin/duplicate-page.zip\";s:5:\"icons\";a:1:{s:2:\"1x\";s:67:\"https://ps.w.org/duplicate-page/assets/icon-128x128.jpg?rev=1412874\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:69:\"https://ps.w.org/duplicate-page/assets/banner-772x250.jpg?rev=1410328\";}s:11:\"banners_rtl\";a:0:{}}s:50:\"gravity-forms-zero-spam/gravityforms-zero-spam.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:37:\"w.org/plugins/gravity-forms-zero-spam\";s:4:\"slug\";s:23:\"gravity-forms-zero-spam\";s:6:\"plugin\";s:50:\"gravity-forms-zero-spam/gravityforms-zero-spam.php\";s:11:\"new_version\";s:5:\"1.0.5\";s:3:\"url\";s:54:\"https://wordpress.org/plugins/gravity-forms-zero-spam/\";s:7:\"package\";s:72:\"https://downloads.wordpress.org/plugin/gravity-forms-zero-spam.1.0.5.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:76:\"https://ps.w.org/gravity-forms-zero-spam/assets/icon-256x256.png?rev=2475934\";s:2:\"1x\";s:76:\"https://ps.w.org/gravity-forms-zero-spam/assets/icon-128x128.png?rev=2475934\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:79:\"https://ps.w.org/gravity-forms-zero-spam/assets/banner-1544x500.png?rev=2475934\";s:2:\"1x\";s:78:\"https://ps.w.org/gravity-forms-zero-spam/assets/banner-772x250.png?rev=2475934\";}s:11:\"banners_rtl\";a:2:{s:2:\"2x\";s:83:\"https://ps.w.org/gravity-forms-zero-spam/assets/banner-1544x500-rtl.png?rev=2475934\";s:2:\"1x\";s:82:\"https://ps.w.org/gravity-forms-zero-spam/assets/banner-772x250-rtl.png?rev=2475934\";}}s:47:\"regenerate-thumbnails/regenerate-thumbnails.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:35:\"w.org/plugins/regenerate-thumbnails\";s:4:\"slug\";s:21:\"regenerate-thumbnails\";s:6:\"plugin\";s:47:\"regenerate-thumbnails/regenerate-thumbnails.php\";s:11:\"new_version\";s:5:\"3.1.4\";s:3:\"url\";s:52:\"https://wordpress.org/plugins/regenerate-thumbnails/\";s:7:\"package\";s:70:\"https://downloads.wordpress.org/plugin/regenerate-thumbnails.3.1.4.zip\";s:5:\"icons\";a:1:{s:2:\"1x\";s:74:\"https://ps.w.org/regenerate-thumbnails/assets/icon-128x128.png?rev=1753390\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:77:\"https://ps.w.org/regenerate-thumbnails/assets/banner-1544x500.jpg?rev=1753390\";s:2:\"1x\";s:76:\"https://ps.w.org/regenerate-thumbnails/assets/banner-772x250.jpg?rev=1753390\";}s:11:\"banners_rtl\";a:0:{}}s:21:\"safe-svg/safe-svg.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:22:\"w.org/plugins/safe-svg\";s:4:\"slug\";s:8:\"safe-svg\";s:6:\"plugin\";s:21:\"safe-svg/safe-svg.php\";s:11:\"new_version\";s:5:\"1.9.9\";s:3:\"url\";s:39:\"https://wordpress.org/plugins/safe-svg/\";s:7:\"package\";s:57:\"https://downloads.wordpress.org/plugin/safe-svg.1.9.9.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:61:\"https://ps.w.org/safe-svg/assets/icon-256x256.png?rev=1706191\";s:2:\"1x\";s:53:\"https://ps.w.org/safe-svg/assets/icon.svg?rev=1706191\";s:3:\"svg\";s:53:\"https://ps.w.org/safe-svg/assets/icon.svg?rev=1706191\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:64:\"https://ps.w.org/safe-svg/assets/banner-1544x500.png?rev=1706191\";s:2:\"1x\";s:63:\"https://ps.w.org/safe-svg/assets/banner-772x250.png?rev=1706191\";}s:11:\"banners_rtl\";a:0:{}}s:45:\"simple-page-ordering/simple-page-ordering.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:34:\"w.org/plugins/simple-page-ordering\";s:4:\"slug\";s:20:\"simple-page-ordering\";s:6:\"plugin\";s:45:\"simple-page-ordering/simple-page-ordering.php\";s:11:\"new_version\";s:5:\"2.3.4\";s:3:\"url\";s:51:\"https://wordpress.org/plugins/simple-page-ordering/\";s:7:\"package\";s:69:\"https://downloads.wordpress.org/plugin/simple-page-ordering.2.3.4.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:72:\"https://ps.w.org/simple-page-ordering/assets/icon-256x256.png?rev=971776\";s:2:\"1x\";s:72:\"https://ps.w.org/simple-page-ordering/assets/icon-128x128.png?rev=971776\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:76:\"https://ps.w.org/simple-page-ordering/assets/banner-1544x500.png?rev=1404285\";s:2:\"1x\";s:74:\"https://ps.w.org/simple-page-ordering/assets/banner-772x250.png?rev=971780\";}s:11:\"banners_rtl\";a:0:{}}s:35:\"google-site-kit/google-site-kit.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:29:\"w.org/plugins/google-site-kit\";s:4:\"slug\";s:15:\"google-site-kit\";s:6:\"plugin\";s:35:\"google-site-kit/google-site-kit.php\";s:11:\"new_version\";s:6:\"1.27.0\";s:3:\"url\";s:46:\"https://wordpress.org/plugins/google-site-kit/\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/plugin/google-site-kit.1.27.0.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:68:\"https://ps.w.org/google-site-kit/assets/icon-256x256.png?rev=2181376\";s:2:\"1x\";s:68:\"https://ps.w.org/google-site-kit/assets/icon-128x128.png?rev=2181376\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:71:\"https://ps.w.org/google-site-kit/assets/banner-1544x500.png?rev=2182425\";s:2:\"1x\";s:70:\"https://ps.w.org/google-site-kit/assets/banner-772x250.png?rev=2182425\";}s:11:\"banners_rtl\";a:0:{}}s:24:\"wordpress-seo/wp-seo.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:27:\"w.org/plugins/wordpress-seo\";s:4:\"slug\";s:13:\"wordpress-seo\";s:6:\"plugin\";s:24:\"wordpress-seo/wp-seo.php\";s:11:\"new_version\";s:6:\"15.9.1\";s:3:\"url\";s:44:\"https://wordpress.org/plugins/wordpress-seo/\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/plugin/wordpress-seo.15.9.1.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:66:\"https://ps.w.org/wordpress-seo/assets/icon-256x256.png?rev=2363699\";s:2:\"1x\";s:58:\"https://ps.w.org/wordpress-seo/assets/icon.svg?rev=2363699\";s:3:\"svg\";s:58:\"https://ps.w.org/wordpress-seo/assets/icon.svg?rev=2363699\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:69:\"https://ps.w.org/wordpress-seo/assets/banner-1544x500.png?rev=1843435\";s:2:\"1x\";s:68:\"https://ps.w.org/wordpress-seo/assets/banner-772x250.png?rev=1843435\";}s:11:\"banners_rtl\";a:2:{s:2:\"2x\";s:73:\"https://ps.w.org/wordpress-seo/assets/banner-1544x500-rtl.png?rev=1843435\";s:2:\"1x\";s:72:\"https://ps.w.org/wordpress-seo/assets/banner-772x250-rtl.png?rev=1843435\";}}}}','no');
INSERT INTO `wp_options` VALUES (1000,'_site_transient_timeout_wdp_un_local_projects','1614884253','no');
INSERT INTO `wp_options` VALUES (1001,'_site_transient_wdp_un_local_projects','a:2:{i:119;a:7:{s:3:\"pid\";s:3:\"119\";s:4:\"name\";s:18:\"WPMU DEV Dashboard\";s:8:\"filename\";s:40:\"wpmudev-updates/update-notifications.php\";s:4:\"path\";s:127:\"/Users/melanie/Documents/Web Development/Sites/demo-site/app/public/wp-content/plugins/wpmudev-updates/update-notifications.php\";s:7:\"version\";s:6:\"4.10.6\";s:4:\"slug\";s:19:\"wpmudev_install-119\";s:4:\"type\";s:6:\"plugin\";}i:912164;a:7:{s:3:\"pid\";s:6:\"912164\";s:4:\"name\";s:9:\"Smush Pro\";s:8:\"filename\";s:25:\"wp-smush-pro/wp-smush.php\";s:4:\"path\";s:112:\"/Users/melanie/Documents/Web Development/Sites/demo-site/app/public/wp-content/plugins/wp-smush-pro/wp-smush.php\";s:7:\"version\";s:5:\"3.8.3\";s:4:\"slug\";s:22:\"wpmudev_install-912164\";s:4:\"type\";s:6:\"plugin\";}}','no');
INSERT INTO `wp_options` VALUES (1002,'_transient_timeout_wpseo_total_unindexed_posts','1614970354','no');
INSERT INTO `wp_options` VALUES (1003,'_transient_wpseo_total_unindexed_posts','0','no');
INSERT INTO `wp_options` VALUES (1004,'_transient_timeout_wpseo_total_unindexed_terms','1614970354','no');
INSERT INTO `wp_options` VALUES (1005,'_transient_wpseo_total_unindexed_terms','0','no');
INSERT INTO `wp_options` VALUES (1006,'_transient_timeout_wpseo_total_unindexed_post_type_archives','1614970354','no');
INSERT INTO `wp_options` VALUES (1007,'_transient_wpseo_total_unindexed_post_type_archives','0','no');
INSERT INTO `wp_options` VALUES (1008,'_transient_timeout_wpseo_unindexed_post_link_count','1614970354','no');
INSERT INTO `wp_options` VALUES (1009,'_transient_wpseo_unindexed_post_link_count','0','no');
INSERT INTO `wp_options` VALUES (1010,'_transient_timeout_wpseo_unindexed_term_link_count','1614970354','no');
INSERT INTO `wp_options` VALUES (1011,'_transient_wpseo_unindexed_term_link_count','0','no');
INSERT INTO `wp_options` VALUES (1012,'rewrite_rules','a:97:{s:19:\"sitemap_index\\.xml$\";s:19:\"index.php?sitemap=1\";s:31:\"([^/]+?)-sitemap([0-9]+)?\\.xml$\";s:51:\"index.php?sitemap=$matches[1]&sitemap_n=$matches[2]\";s:24:\"([a-z]+)?-?sitemap\\.xsl$\";s:39:\"index.php?yoast-sitemap-xsl=$matches[1]\";s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:21:\"^index.php/wp-json/?$\";s:22:\"index.php?rest_route=/\";s:24:\"^index.php/wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:17:\"^wp-sitemap\\.xml$\";s:23:\"index.php?sitemap=index\";s:17:\"^wp-sitemap\\.xsl$\";s:36:\"index.php?sitemap-stylesheet=sitemap\";s:23:\"^wp-sitemap-index\\.xsl$\";s:34:\"index.php?sitemap-stylesheet=index\";s:48:\"^wp-sitemap-([a-z]+?)-([a-z\\d_-]+?)-(\\d+?)\\.xml$\";s:75:\"index.php?sitemap=$matches[1]&sitemap-subtype=$matches[2]&paged=$matches[3]\";s:34:\"^wp-sitemap-([a-z]+?)-(\\d+?)\\.xml$\";s:47:\"index.php?sitemap=$matches[1]&paged=$matches[2]\";s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:23:\"category/(.+?)/embed/?$\";s:46:\"index.php?category_name=$matches[1]&embed=true\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:20:\"tag/([^/]+)/embed/?$\";s:36:\"index.php?tag=$matches[1]&embed=true\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:21:\"type/([^/]+)/embed/?$\";s:44:\"index.php?post_format=$matches[1]&embed=true\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:12:\"robots\\.txt$\";s:18:\"index.php?robots=1\";s:13:\"favicon\\.ico$\";s:19:\"index.php?favicon=1\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:8:\"embed/?$\";s:21:\"index.php?&embed=true\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:27:\"comment-page-([0-9]{1,})/?$\";s:38:\"index.php?&page_id=2&cpage=$matches[1]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:17:\"comments/embed/?$\";s:21:\"index.php?&embed=true\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:20:\"search/(.+)/embed/?$\";s:34:\"index.php?s=$matches[1]&embed=true\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:23:\"author/([^/]+)/embed/?$\";s:44:\"index.php?author_name=$matches[1]&embed=true\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:45:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:74:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:32:\"([0-9]{4})/([0-9]{1,2})/embed/?$\";s:58:\"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:19:\"([0-9]{4})/embed/?$\";s:37:\"index.php?year=$matches[1]&embed=true\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";s:27:\"[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\"[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\"[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"([^/]+)/embed/?$\";s:37:\"index.php?name=$matches[1]&embed=true\";s:20:\"([^/]+)/trackback/?$\";s:31:\"index.php?name=$matches[1]&tb=1\";s:40:\"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:35:\"([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:28:\"([^/]+)/page/?([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&paged=$matches[2]\";s:35:\"([^/]+)/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&cpage=$matches[2]\";s:24:\"([^/]+)(?:/([0-9]+))?/?$\";s:43:\"index.php?name=$matches[1]&page=$matches[2]\";s:16:\"[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:26:\"[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:46:\"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:22:\"[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";}','yes');
INSERT INTO `wp_options` VALUES (1013,'_transient_timeout_GFCache_852e5cf335efa1dc6cf8c58b310788ec','1614884069','no');
INSERT INTO `wp_options` VALUES (1014,'_transient_GFCache_852e5cf335efa1dc6cf8c58b310788ec','a:0:{}','no');
INSERT INTO `wp_options` VALUES (1015,'_transient_timeout_GFCache_2e85a0baa554303935d29163b0be8c3d','1614884069','no');
INSERT INTO `wp_options` VALUES (1016,'_transient_GFCache_2e85a0baa554303935d29163b0be8c3d','a:0:{}','no');
/*!40000 ALTER TABLE `wp_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_postmeta`
--

DROP TABLE IF EXISTS `wp_postmeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=715 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_postmeta`
--

LOCK TABLES `wp_postmeta` WRITE;
/*!40000 ALTER TABLE `wp_postmeta` DISABLE KEYS */;
INSERT INTO `wp_postmeta` VALUES (1,2,'_wp_page_template','default');
INSERT INTO `wp_postmeta` VALUES (10,18,'_edit_lock','1590677750:1');
INSERT INTO `wp_postmeta` VALUES (11,73,'_edit_last','1');
INSERT INTO `wp_postmeta` VALUES (12,73,'_edit_lock','1590530449:1');
INSERT INTO `wp_postmeta` VALUES (13,7,'_edit_lock','1590530409:1');
INSERT INTO `wp_postmeta` VALUES (14,7,'_edit_last','1');
INSERT INTO `wp_postmeta` VALUES (15,78,'_edit_last','1');
INSERT INTO `wp_postmeta` VALUES (16,78,'_edit_lock','1590608371:1');
INSERT INTO `wp_postmeta` VALUES (17,85,'_edit_last','1');
INSERT INTO `wp_postmeta` VALUES (18,85,'_wp_page_template','templates/styleguide.php');
INSERT INTO `wp_postmeta` VALUES (19,85,'_edit_lock','1590598541:1');
INSERT INTO `wp_postmeta` VALUES (20,87,'_edit_last','1');
INSERT INTO `wp_postmeta` VALUES (21,87,'_wp_page_template','default');
INSERT INTO `wp_postmeta` VALUES (22,87,'hero_background','');
INSERT INTO `wp_postmeta` VALUES (23,87,'_hero_background','field_5ea71500997d7');
INSERT INTO `wp_postmeta` VALUES (24,87,'hero_horizontal_background_alignment','center');
INSERT INTO `wp_postmeta` VALUES (25,87,'_hero_horizontal_background_alignment','field_5ea715e6997dd');
INSERT INTO `wp_postmeta` VALUES (26,87,'hero_vertical_background_alignment','center');
INSERT INTO `wp_postmeta` VALUES (27,87,'_hero_vertical_background_alignment','field_5ea71621997de');
INSERT INTO `wp_postmeta` VALUES (28,87,'hero_column_span','10');
INSERT INTO `wp_postmeta` VALUES (29,87,'_hero_column_span','field_5ec56482a7c5f');
INSERT INTO `wp_postmeta` VALUES (30,87,'hero_column_alignment','center');
INSERT INTO `wp_postmeta` VALUES (31,87,'_hero_column_alignment','field_5ec564aba7c60');
INSERT INTO `wp_postmeta` VALUES (32,87,'hero_video_toggle','0');
INSERT INTO `wp_postmeta` VALUES (33,87,'_hero_video_toggle','field_5ea71568997d8');
INSERT INTO `wp_postmeta` VALUES (34,87,'hero_content','');
INSERT INTO `wp_postmeta` VALUES (35,87,'_hero_content','field_5ea715a5997da');
INSERT INTO `wp_postmeta` VALUES (36,87,'hero_buttons','');
INSERT INTO `wp_postmeta` VALUES (37,87,'_hero_buttons','field_5ea715c5997db');
INSERT INTO `wp_postmeta` VALUES (38,87,'hero_button_alignment','center');
INSERT INTO `wp_postmeta` VALUES (39,87,'_hero_button_alignment','field_5ea7170679be7');
INSERT INTO `wp_postmeta` VALUES (40,87,'default_hero','');
INSERT INTO `wp_postmeta` VALUES (41,87,'_default_hero','field_5ecd919847d49');
INSERT INTO `wp_postmeta` VALUES (42,87,'page_sections','');
INSERT INTO `wp_postmeta` VALUES (43,87,'_page_sections','field_5ea7226f8cc0b');
INSERT INTO `wp_postmeta` VALUES (44,87,'default_sections','');
INSERT INTO `wp_postmeta` VALUES (45,87,'_default_sections','field_5ecd91ab47d4b');
INSERT INTO `wp_postmeta` VALUES (46,88,'hero_background','');
INSERT INTO `wp_postmeta` VALUES (47,88,'_hero_background','field_5ea71500997d7');
INSERT INTO `wp_postmeta` VALUES (48,88,'hero_horizontal_background_alignment','center');
INSERT INTO `wp_postmeta` VALUES (49,88,'_hero_horizontal_background_alignment','field_5ea715e6997dd');
INSERT INTO `wp_postmeta` VALUES (50,88,'hero_vertical_background_alignment','center');
INSERT INTO `wp_postmeta` VALUES (51,88,'_hero_vertical_background_alignment','field_5ea71621997de');
INSERT INTO `wp_postmeta` VALUES (52,88,'hero_column_span','10');
INSERT INTO `wp_postmeta` VALUES (53,88,'_hero_column_span','field_5ec56482a7c5f');
INSERT INTO `wp_postmeta` VALUES (54,88,'hero_column_alignment','center');
INSERT INTO `wp_postmeta` VALUES (55,88,'_hero_column_alignment','field_5ec564aba7c60');
INSERT INTO `wp_postmeta` VALUES (56,88,'hero_video_toggle','0');
INSERT INTO `wp_postmeta` VALUES (57,88,'_hero_video_toggle','field_5ea71568997d8');
INSERT INTO `wp_postmeta` VALUES (58,88,'hero_content','');
INSERT INTO `wp_postmeta` VALUES (59,88,'_hero_content','field_5ea715a5997da');
INSERT INTO `wp_postmeta` VALUES (60,88,'hero_buttons','');
INSERT INTO `wp_postmeta` VALUES (61,88,'_hero_buttons','field_5ea715c5997db');
INSERT INTO `wp_postmeta` VALUES (62,88,'hero_button_alignment','center');
INSERT INTO `wp_postmeta` VALUES (63,88,'_hero_button_alignment','field_5ea7170679be7');
INSERT INTO `wp_postmeta` VALUES (64,88,'default_hero','');
INSERT INTO `wp_postmeta` VALUES (65,88,'_default_hero','field_5ecd919847d49');
INSERT INTO `wp_postmeta` VALUES (66,88,'page_sections','');
INSERT INTO `wp_postmeta` VALUES (67,88,'_page_sections','field_5ea7226f8cc0b');
INSERT INTO `wp_postmeta` VALUES (68,88,'default_sections','');
INSERT INTO `wp_postmeta` VALUES (69,88,'_default_sections','field_5ecd91ab47d4b');
INSERT INTO `wp_postmeta` VALUES (70,87,'_edit_lock','1590605378:1');
INSERT INTO `wp_postmeta` VALUES (71,2,'_edit_lock','1590606876:1');
INSERT INTO `wp_postmeta` VALUES (72,2,'_edit_last','1');
INSERT INTO `wp_postmeta` VALUES (73,2,'_yoast_wpseo_content_score','90');
INSERT INTO `wp_postmeta` VALUES (74,2,'hero_background','');
INSERT INTO `wp_postmeta` VALUES (75,2,'_hero_background','field_5ea71500997d7');
INSERT INTO `wp_postmeta` VALUES (76,2,'hero_horizontal_background_alignment','center');
INSERT INTO `wp_postmeta` VALUES (77,2,'_hero_horizontal_background_alignment','field_5ea715e6997dd');
INSERT INTO `wp_postmeta` VALUES (78,2,'hero_vertical_background_alignment','center');
INSERT INTO `wp_postmeta` VALUES (79,2,'_hero_vertical_background_alignment','field_5ea71621997de');
INSERT INTO `wp_postmeta` VALUES (80,2,'hero_column_span','10');
INSERT INTO `wp_postmeta` VALUES (81,2,'_hero_column_span','field_5ec56482a7c5f');
INSERT INTO `wp_postmeta` VALUES (82,2,'hero_column_alignment','center');
INSERT INTO `wp_postmeta` VALUES (83,2,'_hero_column_alignment','field_5ec564aba7c60');
INSERT INTO `wp_postmeta` VALUES (84,2,'hero_video_toggle','0');
INSERT INTO `wp_postmeta` VALUES (85,2,'_hero_video_toggle','field_5ea71568997d8');
INSERT INTO `wp_postmeta` VALUES (86,2,'hero_content','<h1 style=\"text-align: center;\">Hero Text</h1>\r\n&nbsp;\r\n\r\n&nbsp;');
INSERT INTO `wp_postmeta` VALUES (87,2,'_hero_content','field_5ea715a5997da');
INSERT INTO `wp_postmeta` VALUES (88,2,'hero_buttons','1');
INSERT INTO `wp_postmeta` VALUES (89,2,'_hero_buttons','field_5ea715c5997db');
INSERT INTO `wp_postmeta` VALUES (90,2,'hero_button_alignment','center');
INSERT INTO `wp_postmeta` VALUES (91,2,'_hero_button_alignment','field_5ea7170679be7');
INSERT INTO `wp_postmeta` VALUES (92,2,'default_hero','');
INSERT INTO `wp_postmeta` VALUES (93,2,'_default_hero','field_5ecd919847d49');
INSERT INTO `wp_postmeta` VALUES (94,2,'page_sections_0_centered_text_block_column_span','10');
INSERT INTO `wp_postmeta` VALUES (95,2,'_page_sections_0_centered_text_block_column_span','field_5ea7232bac58e_field_5ea7229da7a4d');
INSERT INTO `wp_postmeta` VALUES (96,2,'page_sections_0_centered_text_block_content','<p style=\"text-align: center;\">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>');
INSERT INTO `wp_postmeta` VALUES (97,2,'_page_sections_0_centered_text_block_content','field_5ea7232bac58e_field_5ea722c2a7a4e');
INSERT INTO `wp_postmeta` VALUES (98,2,'page_sections_0_centered_text_block_buttons','1');
INSERT INTO `wp_postmeta` VALUES (99,2,'_page_sections_0_centered_text_block_buttons','field_5ea7232bac58e_field_5ea722dca7a4f');
INSERT INTO `wp_postmeta` VALUES (100,2,'page_sections_0_centered_text_block_button_alignment','center');
INSERT INTO `wp_postmeta` VALUES (101,2,'_page_sections_0_centered_text_block_button_alignment','field_5ea7232bac58e_field_5ea72300a7a51');
INSERT INTO `wp_postmeta` VALUES (102,2,'page_sections_1_text_image_split_layout_option','left');
INSERT INTO `wp_postmeta` VALUES (103,2,'_page_sections_1_text_image_split_layout_option','field_5ea74fbf2ab11_field_5ea74e6eaf3c8');
INSERT INTO `wp_postmeta` VALUES (104,2,'page_sections_1_text_image_split_width_option','1');
INSERT INTO `wp_postmeta` VALUES (105,2,'_page_sections_1_text_image_split_width_option','field_5ea74fbf2ab11_field_5ea74e91af3c9');
INSERT INTO `wp_postmeta` VALUES (106,2,'page_sections_1_text_image_split_margin_option','0');
INSERT INTO `wp_postmeta` VALUES (107,2,'_page_sections_1_text_image_split_margin_option','field_5ea74fbf2ab11_field_5ea74ed9af3ca');
INSERT INTO `wp_postmeta` VALUES (108,2,'page_sections_1_text_image_split_background_color','#d9d9d9');
INSERT INTO `wp_postmeta` VALUES (109,2,'_page_sections_1_text_image_split_background_color','field_5ea74fbf2ab11_field_5eb43094542c6');
INSERT INTO `wp_postmeta` VALUES (110,2,'page_sections_1_text_image_split_image','');
INSERT INTO `wp_postmeta` VALUES (111,2,'_page_sections_1_text_image_split_image','field_5ea74fbf2ab11_field_5ea74f04af3cb');
INSERT INTO `wp_postmeta` VALUES (112,2,'page_sections_1_text_image_split_content','Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.');
INSERT INTO `wp_postmeta` VALUES (113,2,'_page_sections_1_text_image_split_content','field_5ea74fbf2ab11_field_5ea74f2caf3cc');
INSERT INTO `wp_postmeta` VALUES (114,2,'page_sections_1_text_image_split_button_toggle','0');
INSERT INTO `wp_postmeta` VALUES (115,2,'_page_sections_1_text_image_split_button_toggle','field_5ea74fbf2ab11_field_5ea74f40af3cd');
INSERT INTO `wp_postmeta` VALUES (116,2,'page_sections','a:2:{i:0;s:19:\"centered_text_block\";i:1;s:16:\"text_image_split\";}');
INSERT INTO `wp_postmeta` VALUES (117,2,'_page_sections','field_5ea7226f8cc0b');
INSERT INTO `wp_postmeta` VALUES (118,2,'default_sections','');
INSERT INTO `wp_postmeta` VALUES (119,2,'_default_sections','field_5ecd91ab47d4b');
INSERT INTO `wp_postmeta` VALUES (120,89,'hero_background','');
INSERT INTO `wp_postmeta` VALUES (121,89,'_hero_background','field_5ea71500997d7');
INSERT INTO `wp_postmeta` VALUES (122,89,'hero_horizontal_background_alignment','center');
INSERT INTO `wp_postmeta` VALUES (123,89,'_hero_horizontal_background_alignment','field_5ea715e6997dd');
INSERT INTO `wp_postmeta` VALUES (124,89,'hero_vertical_background_alignment','center');
INSERT INTO `wp_postmeta` VALUES (125,89,'_hero_vertical_background_alignment','field_5ea71621997de');
INSERT INTO `wp_postmeta` VALUES (126,89,'hero_column_span','10');
INSERT INTO `wp_postmeta` VALUES (127,89,'_hero_column_span','field_5ec56482a7c5f');
INSERT INTO `wp_postmeta` VALUES (128,89,'hero_column_alignment','center');
INSERT INTO `wp_postmeta` VALUES (129,89,'_hero_column_alignment','field_5ec564aba7c60');
INSERT INTO `wp_postmeta` VALUES (130,89,'hero_video_toggle','0');
INSERT INTO `wp_postmeta` VALUES (131,89,'_hero_video_toggle','field_5ea71568997d8');
INSERT INTO `wp_postmeta` VALUES (132,89,'hero_content','<h1 style=\"text-align: center;\">Hero Text</h1>');
INSERT INTO `wp_postmeta` VALUES (133,89,'_hero_content','field_5ea715a5997da');
INSERT INTO `wp_postmeta` VALUES (134,89,'hero_buttons','');
INSERT INTO `wp_postmeta` VALUES (135,89,'_hero_buttons','field_5ea715c5997db');
INSERT INTO `wp_postmeta` VALUES (136,89,'hero_button_alignment','center');
INSERT INTO `wp_postmeta` VALUES (137,89,'_hero_button_alignment','field_5ea7170679be7');
INSERT INTO `wp_postmeta` VALUES (138,89,'default_hero','');
INSERT INTO `wp_postmeta` VALUES (139,89,'_default_hero','field_5ecd919847d49');
INSERT INTO `wp_postmeta` VALUES (140,89,'page_sections_0_centered_text_block_column_span','10');
INSERT INTO `wp_postmeta` VALUES (141,89,'_page_sections_0_centered_text_block_column_span','field_5ea7232bac58e_field_5ea7229da7a4d');
INSERT INTO `wp_postmeta` VALUES (142,89,'page_sections_0_centered_text_block_content','<p style=\"text-align: center;\">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>');
INSERT INTO `wp_postmeta` VALUES (143,89,'_page_sections_0_centered_text_block_content','field_5ea7232bac58e_field_5ea722c2a7a4e');
INSERT INTO `wp_postmeta` VALUES (144,89,'page_sections_0_centered_text_block_buttons','');
INSERT INTO `wp_postmeta` VALUES (145,89,'_page_sections_0_centered_text_block_buttons','field_5ea7232bac58e_field_5ea722dca7a4f');
INSERT INTO `wp_postmeta` VALUES (146,89,'page_sections_0_centered_text_block_button_alignment','center');
INSERT INTO `wp_postmeta` VALUES (147,89,'_page_sections_0_centered_text_block_button_alignment','field_5ea7232bac58e_field_5ea72300a7a51');
INSERT INTO `wp_postmeta` VALUES (148,89,'page_sections_1_text_image_split_layout_option','left');
INSERT INTO `wp_postmeta` VALUES (149,89,'_page_sections_1_text_image_split_layout_option','field_5ea74fbf2ab11_field_5ea74e6eaf3c8');
INSERT INTO `wp_postmeta` VALUES (150,89,'page_sections_1_text_image_split_width_option','1');
INSERT INTO `wp_postmeta` VALUES (151,89,'_page_sections_1_text_image_split_width_option','field_5ea74fbf2ab11_field_5ea74e91af3c9');
INSERT INTO `wp_postmeta` VALUES (152,89,'page_sections_1_text_image_split_margin_option','0');
INSERT INTO `wp_postmeta` VALUES (153,89,'_page_sections_1_text_image_split_margin_option','field_5ea74fbf2ab11_field_5ea74ed9af3ca');
INSERT INTO `wp_postmeta` VALUES (154,89,'page_sections_1_text_image_split_background_color','#d9d9d9');
INSERT INTO `wp_postmeta` VALUES (155,89,'_page_sections_1_text_image_split_background_color','field_5ea74fbf2ab11_field_5eb43094542c6');
INSERT INTO `wp_postmeta` VALUES (156,89,'page_sections_1_text_image_split_image','');
INSERT INTO `wp_postmeta` VALUES (157,89,'_page_sections_1_text_image_split_image','field_5ea74fbf2ab11_field_5ea74f04af3cb');
INSERT INTO `wp_postmeta` VALUES (158,89,'page_sections_1_text_image_split_content','Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.');
INSERT INTO `wp_postmeta` VALUES (159,89,'_page_sections_1_text_image_split_content','field_5ea74fbf2ab11_field_5ea74f2caf3cc');
INSERT INTO `wp_postmeta` VALUES (160,89,'page_sections_1_text_image_split_button_toggle','0');
INSERT INTO `wp_postmeta` VALUES (161,89,'_page_sections_1_text_image_split_button_toggle','field_5ea74fbf2ab11_field_5ea74f40af3cd');
INSERT INTO `wp_postmeta` VALUES (162,89,'page_sections','a:2:{i:0;s:19:\"centered_text_block\";i:1;s:16:\"text_image_split\";}');
INSERT INTO `wp_postmeta` VALUES (163,89,'_page_sections','field_5ea7226f8cc0b');
INSERT INTO `wp_postmeta` VALUES (164,89,'default_sections','');
INSERT INTO `wp_postmeta` VALUES (165,89,'_default_sections','field_5ecd91ab47d4b');
INSERT INTO `wp_postmeta` VALUES (166,90,'_edit_lock','1590603547:1');
INSERT INTO `wp_postmeta` VALUES (167,90,'_edit_last','1');
INSERT INTO `wp_postmeta` VALUES (168,87,'blog_intro_text','<h1 style=\"text-align: center;\">Blog</h1>\r\n<p style=\"text-align: center;\">Check out our latest posts below</p>');
INSERT INTO `wp_postmeta` VALUES (169,87,'_blog_intro_text','field_5728e4d16b348');
INSERT INTO `wp_postmeta` VALUES (170,88,'blog_intro_text','<h1 style=\"text-align: center;\">Blog</h1>\r\n<p style=\"text-align: center;\">Check out our latest posts below</p>');
INSERT INTO `wp_postmeta` VALUES (171,88,'_blog_intro_text','field_5728e4d16b348');
INSERT INTO `wp_postmeta` VALUES (172,93,'_edit_last','1');
INSERT INTO `wp_postmeta` VALUES (173,93,'_edit_lock','1590601748:1');
INSERT INTO `wp_postmeta` VALUES (176,93,'_yoast_wpseo_content_score','30');
INSERT INTO `wp_postmeta` VALUES (177,93,'_yoast_wpseo_primary_category','3');
INSERT INTO `wp_postmeta` VALUES (178,95,'_edit_last','1');
INSERT INTO `wp_postmeta` VALUES (179,95,'_edit_lock','1590602954:1');
INSERT INTO `wp_postmeta` VALUES (180,95,'_yoast_wpseo_content_score','30');
INSERT INTO `wp_postmeta` VALUES (181,95,'_yoast_wpseo_primary_category','2');
INSERT INTO `wp_postmeta` VALUES (189,87,'post_meta_data','a:2:{i:0;s:6:\"author\";i:1;s:4:\"date\";}');
INSERT INTO `wp_postmeta` VALUES (190,87,'_post_meta_data','field_5eceaf331eab5');
INSERT INTO `wp_postmeta` VALUES (191,102,'hero_background','');
INSERT INTO `wp_postmeta` VALUES (192,102,'_hero_background','field_5ea71500997d7');
INSERT INTO `wp_postmeta` VALUES (193,102,'hero_horizontal_background_alignment','center');
INSERT INTO `wp_postmeta` VALUES (194,102,'_hero_horizontal_background_alignment','field_5ea715e6997dd');
INSERT INTO `wp_postmeta` VALUES (195,102,'hero_vertical_background_alignment','center');
INSERT INTO `wp_postmeta` VALUES (196,102,'_hero_vertical_background_alignment','field_5ea71621997de');
INSERT INTO `wp_postmeta` VALUES (197,102,'hero_column_span','10');
INSERT INTO `wp_postmeta` VALUES (198,102,'_hero_column_span','field_5ec56482a7c5f');
INSERT INTO `wp_postmeta` VALUES (199,102,'hero_column_alignment','center');
INSERT INTO `wp_postmeta` VALUES (200,102,'_hero_column_alignment','field_5ec564aba7c60');
INSERT INTO `wp_postmeta` VALUES (201,102,'hero_video_toggle','0');
INSERT INTO `wp_postmeta` VALUES (202,102,'_hero_video_toggle','field_5ea71568997d8');
INSERT INTO `wp_postmeta` VALUES (203,102,'hero_content','');
INSERT INTO `wp_postmeta` VALUES (204,102,'_hero_content','field_5ea715a5997da');
INSERT INTO `wp_postmeta` VALUES (205,102,'hero_buttons','');
INSERT INTO `wp_postmeta` VALUES (206,102,'_hero_buttons','field_5ea715c5997db');
INSERT INTO `wp_postmeta` VALUES (207,102,'hero_button_alignment','center');
INSERT INTO `wp_postmeta` VALUES (208,102,'_hero_button_alignment','field_5ea7170679be7');
INSERT INTO `wp_postmeta` VALUES (209,102,'default_hero','');
INSERT INTO `wp_postmeta` VALUES (210,102,'_default_hero','field_5ecd919847d49');
INSERT INTO `wp_postmeta` VALUES (211,102,'page_sections','');
INSERT INTO `wp_postmeta` VALUES (212,102,'_page_sections','field_5ea7226f8cc0b');
INSERT INTO `wp_postmeta` VALUES (213,102,'default_sections','');
INSERT INTO `wp_postmeta` VALUES (214,102,'_default_sections','field_5ecd91ab47d4b');
INSERT INTO `wp_postmeta` VALUES (215,102,'blog_intro_text','<h1 style=\"text-align: center;\">Blog</h1>\r\n<p style=\"text-align: center;\">Check out our latest posts below</p>');
INSERT INTO `wp_postmeta` VALUES (216,102,'_blog_intro_text','field_5728e4d16b348');
INSERT INTO `wp_postmeta` VALUES (217,102,'post_meta_data','a:2:{i:0;s:6:\"author\";i:1;s:4:\"date\";}');
INSERT INTO `wp_postmeta` VALUES (218,102,'_post_meta_data','field_5eceaf331eab5');
INSERT INTO `wp_postmeta` VALUES (221,30,'_edit_lock','1590605429:1');
INSERT INTO `wp_postmeta` VALUES (222,36,'_edit_lock','1590605847:1');
INSERT INTO `wp_postmeta` VALUES (223,47,'_edit_lock','1590605944:1');
INSERT INTO `wp_postmeta` VALUES (224,53,'_edit_lock','1590606109:1');
INSERT INTO `wp_postmeta` VALUES (225,63,'_edit_lock','1590606185:1');
INSERT INTO `wp_postmeta` VALUES (226,70,'_edit_lock','1590604634:1');
INSERT INTO `wp_postmeta` VALUES (242,30,'_edit_last','1');
INSERT INTO `wp_postmeta` VALUES (243,2,'page_sections_0_centered_text_block_buttons_0_button_class','primary');
INSERT INTO `wp_postmeta` VALUES (244,2,'_page_sections_0_centered_text_block_buttons_0_button_class','field_5eceb63abcc3a');
INSERT INTO `wp_postmeta` VALUES (245,2,'page_sections_0_centered_text_block_buttons_0_button','a:3:{s:5:\"title\";s:6:\"Button\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}');
INSERT INTO `wp_postmeta` VALUES (246,2,'_page_sections_0_centered_text_block_buttons_0_button','field_5ea722f8a7a50');
INSERT INTO `wp_postmeta` VALUES (247,109,'hero_background','');
INSERT INTO `wp_postmeta` VALUES (248,109,'_hero_background','field_5ea71500997d7');
INSERT INTO `wp_postmeta` VALUES (249,109,'hero_horizontal_background_alignment','center');
INSERT INTO `wp_postmeta` VALUES (250,109,'_hero_horizontal_background_alignment','field_5ea715e6997dd');
INSERT INTO `wp_postmeta` VALUES (251,109,'hero_vertical_background_alignment','center');
INSERT INTO `wp_postmeta` VALUES (252,109,'_hero_vertical_background_alignment','field_5ea71621997de');
INSERT INTO `wp_postmeta` VALUES (253,109,'hero_column_span','10');
INSERT INTO `wp_postmeta` VALUES (254,109,'_hero_column_span','field_5ec56482a7c5f');
INSERT INTO `wp_postmeta` VALUES (255,109,'hero_column_alignment','center');
INSERT INTO `wp_postmeta` VALUES (256,109,'_hero_column_alignment','field_5ec564aba7c60');
INSERT INTO `wp_postmeta` VALUES (257,109,'hero_video_toggle','0');
INSERT INTO `wp_postmeta` VALUES (258,109,'_hero_video_toggle','field_5ea71568997d8');
INSERT INTO `wp_postmeta` VALUES (259,109,'hero_content','<h1 style=\"text-align: center;\">Hero Text</h1>');
INSERT INTO `wp_postmeta` VALUES (260,109,'_hero_content','field_5ea715a5997da');
INSERT INTO `wp_postmeta` VALUES (261,109,'hero_buttons','');
INSERT INTO `wp_postmeta` VALUES (262,109,'_hero_buttons','field_5ea715c5997db');
INSERT INTO `wp_postmeta` VALUES (263,109,'hero_button_alignment','center');
INSERT INTO `wp_postmeta` VALUES (264,109,'_hero_button_alignment','field_5ea7170679be7');
INSERT INTO `wp_postmeta` VALUES (265,109,'default_hero','');
INSERT INTO `wp_postmeta` VALUES (266,109,'_default_hero','field_5ecd919847d49');
INSERT INTO `wp_postmeta` VALUES (267,109,'page_sections_0_centered_text_block_column_span','10');
INSERT INTO `wp_postmeta` VALUES (268,109,'_page_sections_0_centered_text_block_column_span','field_5ea7232bac58e_field_5ea7229da7a4d');
INSERT INTO `wp_postmeta` VALUES (269,109,'page_sections_0_centered_text_block_content','<p style=\"text-align: center;\">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>');
INSERT INTO `wp_postmeta` VALUES (270,109,'_page_sections_0_centered_text_block_content','field_5ea7232bac58e_field_5ea722c2a7a4e');
INSERT INTO `wp_postmeta` VALUES (271,109,'page_sections_0_centered_text_block_buttons','1');
INSERT INTO `wp_postmeta` VALUES (272,109,'_page_sections_0_centered_text_block_buttons','field_5ea7232bac58e_field_5ea722dca7a4f');
INSERT INTO `wp_postmeta` VALUES (273,109,'page_sections_0_centered_text_block_button_alignment','center');
INSERT INTO `wp_postmeta` VALUES (274,109,'_page_sections_0_centered_text_block_button_alignment','field_5ea7232bac58e_field_5ea72300a7a51');
INSERT INTO `wp_postmeta` VALUES (275,109,'page_sections_1_text_image_split_layout_option','left');
INSERT INTO `wp_postmeta` VALUES (276,109,'_page_sections_1_text_image_split_layout_option','field_5ea74fbf2ab11_field_5ea74e6eaf3c8');
INSERT INTO `wp_postmeta` VALUES (277,109,'page_sections_1_text_image_split_width_option','1');
INSERT INTO `wp_postmeta` VALUES (278,109,'_page_sections_1_text_image_split_width_option','field_5ea74fbf2ab11_field_5ea74e91af3c9');
INSERT INTO `wp_postmeta` VALUES (279,109,'page_sections_1_text_image_split_margin_option','0');
INSERT INTO `wp_postmeta` VALUES (280,109,'_page_sections_1_text_image_split_margin_option','field_5ea74fbf2ab11_field_5ea74ed9af3ca');
INSERT INTO `wp_postmeta` VALUES (281,109,'page_sections_1_text_image_split_background_color','#d9d9d9');
INSERT INTO `wp_postmeta` VALUES (282,109,'_page_sections_1_text_image_split_background_color','field_5ea74fbf2ab11_field_5eb43094542c6');
INSERT INTO `wp_postmeta` VALUES (283,109,'page_sections_1_text_image_split_image','');
INSERT INTO `wp_postmeta` VALUES (284,109,'_page_sections_1_text_image_split_image','field_5ea74fbf2ab11_field_5ea74f04af3cb');
INSERT INTO `wp_postmeta` VALUES (285,109,'page_sections_1_text_image_split_content','Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.');
INSERT INTO `wp_postmeta` VALUES (286,109,'_page_sections_1_text_image_split_content','field_5ea74fbf2ab11_field_5ea74f2caf3cc');
INSERT INTO `wp_postmeta` VALUES (287,109,'page_sections_1_text_image_split_button_toggle','0');
INSERT INTO `wp_postmeta` VALUES (288,109,'_page_sections_1_text_image_split_button_toggle','field_5ea74fbf2ab11_field_5ea74f40af3cd');
INSERT INTO `wp_postmeta` VALUES (289,109,'page_sections','a:2:{i:0;s:19:\"centered_text_block\";i:1;s:16:\"text_image_split\";}');
INSERT INTO `wp_postmeta` VALUES (290,109,'_page_sections','field_5ea7226f8cc0b');
INSERT INTO `wp_postmeta` VALUES (291,109,'default_sections','');
INSERT INTO `wp_postmeta` VALUES (292,109,'_default_sections','field_5ecd91ab47d4b');
INSERT INTO `wp_postmeta` VALUES (293,109,'page_sections_0_centered_text_block_buttons_0_button_class','primary');
INSERT INTO `wp_postmeta` VALUES (294,109,'_page_sections_0_centered_text_block_buttons_0_button_class','field_5eceb63abcc3a');
INSERT INTO `wp_postmeta` VALUES (295,109,'page_sections_0_centered_text_block_buttons_0_button','a:3:{s:5:\"title\";s:6:\"Button\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}');
INSERT INTO `wp_postmeta` VALUES (296,109,'_page_sections_0_centered_text_block_buttons_0_button','field_5ea722f8a7a50');
INSERT INTO `wp_postmeta` VALUES (297,18,'_edit_last','1');
INSERT INTO `wp_postmeta` VALUES (298,2,'hero_buttons_0_button_class','primary');
INSERT INTO `wp_postmeta` VALUES (299,2,'_hero_buttons_0_button_class','field_5eceb70d0e42d');
INSERT INTO `wp_postmeta` VALUES (300,2,'hero_buttons_0_button','a:3:{s:5:\"title\";s:11:\"Button Text\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}');
INSERT INTO `wp_postmeta` VALUES (301,2,'_hero_buttons_0_button','field_5ea715d8997dc');
INSERT INTO `wp_postmeta` VALUES (302,111,'hero_background','');
INSERT INTO `wp_postmeta` VALUES (303,111,'_hero_background','field_5ea71500997d7');
INSERT INTO `wp_postmeta` VALUES (304,111,'hero_horizontal_background_alignment','center');
INSERT INTO `wp_postmeta` VALUES (305,111,'_hero_horizontal_background_alignment','field_5ea715e6997dd');
INSERT INTO `wp_postmeta` VALUES (306,111,'hero_vertical_background_alignment','center');
INSERT INTO `wp_postmeta` VALUES (307,111,'_hero_vertical_background_alignment','field_5ea71621997de');
INSERT INTO `wp_postmeta` VALUES (308,111,'hero_column_span','10');
INSERT INTO `wp_postmeta` VALUES (309,111,'_hero_column_span','field_5ec56482a7c5f');
INSERT INTO `wp_postmeta` VALUES (310,111,'hero_column_alignment','center');
INSERT INTO `wp_postmeta` VALUES (311,111,'_hero_column_alignment','field_5ec564aba7c60');
INSERT INTO `wp_postmeta` VALUES (312,111,'hero_video_toggle','0');
INSERT INTO `wp_postmeta` VALUES (313,111,'_hero_video_toggle','field_5ea71568997d8');
INSERT INTO `wp_postmeta` VALUES (314,111,'hero_content','<h1 style=\"text-align: center;\">Hero Text</h1>');
INSERT INTO `wp_postmeta` VALUES (315,111,'_hero_content','field_5ea715a5997da');
INSERT INTO `wp_postmeta` VALUES (316,111,'hero_buttons','1');
INSERT INTO `wp_postmeta` VALUES (317,111,'_hero_buttons','field_5ea715c5997db');
INSERT INTO `wp_postmeta` VALUES (318,111,'hero_button_alignment','center');
INSERT INTO `wp_postmeta` VALUES (319,111,'_hero_button_alignment','field_5ea7170679be7');
INSERT INTO `wp_postmeta` VALUES (320,111,'default_hero','');
INSERT INTO `wp_postmeta` VALUES (321,111,'_default_hero','field_5ecd919847d49');
INSERT INTO `wp_postmeta` VALUES (322,111,'page_sections_0_centered_text_block_column_span','10');
INSERT INTO `wp_postmeta` VALUES (323,111,'_page_sections_0_centered_text_block_column_span','field_5ea7232bac58e_field_5ea7229da7a4d');
INSERT INTO `wp_postmeta` VALUES (324,111,'page_sections_0_centered_text_block_content','<p style=\"text-align: center;\">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>');
INSERT INTO `wp_postmeta` VALUES (325,111,'_page_sections_0_centered_text_block_content','field_5ea7232bac58e_field_5ea722c2a7a4e');
INSERT INTO `wp_postmeta` VALUES (326,111,'page_sections_0_centered_text_block_buttons','1');
INSERT INTO `wp_postmeta` VALUES (327,111,'_page_sections_0_centered_text_block_buttons','field_5ea7232bac58e_field_5ea722dca7a4f');
INSERT INTO `wp_postmeta` VALUES (328,111,'page_sections_0_centered_text_block_button_alignment','center');
INSERT INTO `wp_postmeta` VALUES (329,111,'_page_sections_0_centered_text_block_button_alignment','field_5ea7232bac58e_field_5ea72300a7a51');
INSERT INTO `wp_postmeta` VALUES (330,111,'page_sections_1_text_image_split_layout_option','left');
INSERT INTO `wp_postmeta` VALUES (331,111,'_page_sections_1_text_image_split_layout_option','field_5ea74fbf2ab11_field_5ea74e6eaf3c8');
INSERT INTO `wp_postmeta` VALUES (332,111,'page_sections_1_text_image_split_width_option','1');
INSERT INTO `wp_postmeta` VALUES (333,111,'_page_sections_1_text_image_split_width_option','field_5ea74fbf2ab11_field_5ea74e91af3c9');
INSERT INTO `wp_postmeta` VALUES (334,111,'page_sections_1_text_image_split_margin_option','0');
INSERT INTO `wp_postmeta` VALUES (335,111,'_page_sections_1_text_image_split_margin_option','field_5ea74fbf2ab11_field_5ea74ed9af3ca');
INSERT INTO `wp_postmeta` VALUES (336,111,'page_sections_1_text_image_split_background_color','#d9d9d9');
INSERT INTO `wp_postmeta` VALUES (337,111,'_page_sections_1_text_image_split_background_color','field_5ea74fbf2ab11_field_5eb43094542c6');
INSERT INTO `wp_postmeta` VALUES (338,111,'page_sections_1_text_image_split_image','');
INSERT INTO `wp_postmeta` VALUES (339,111,'_page_sections_1_text_image_split_image','field_5ea74fbf2ab11_field_5ea74f04af3cb');
INSERT INTO `wp_postmeta` VALUES (340,111,'page_sections_1_text_image_split_content','Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.');
INSERT INTO `wp_postmeta` VALUES (341,111,'_page_sections_1_text_image_split_content','field_5ea74fbf2ab11_field_5ea74f2caf3cc');
INSERT INTO `wp_postmeta` VALUES (342,111,'page_sections_1_text_image_split_button_toggle','0');
INSERT INTO `wp_postmeta` VALUES (343,111,'_page_sections_1_text_image_split_button_toggle','field_5ea74fbf2ab11_field_5ea74f40af3cd');
INSERT INTO `wp_postmeta` VALUES (344,111,'page_sections','a:2:{i:0;s:19:\"centered_text_block\";i:1;s:16:\"text_image_split\";}');
INSERT INTO `wp_postmeta` VALUES (345,111,'_page_sections','field_5ea7226f8cc0b');
INSERT INTO `wp_postmeta` VALUES (346,111,'default_sections','');
INSERT INTO `wp_postmeta` VALUES (347,111,'_default_sections','field_5ecd91ab47d4b');
INSERT INTO `wp_postmeta` VALUES (348,111,'page_sections_0_centered_text_block_buttons_0_button_class','primary');
INSERT INTO `wp_postmeta` VALUES (349,111,'_page_sections_0_centered_text_block_buttons_0_button_class','field_5eceb63abcc3a');
INSERT INTO `wp_postmeta` VALUES (350,111,'page_sections_0_centered_text_block_buttons_0_button','a:3:{s:5:\"title\";s:6:\"Button\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}');
INSERT INTO `wp_postmeta` VALUES (351,111,'_page_sections_0_centered_text_block_buttons_0_button','field_5ea722f8a7a50');
INSERT INTO `wp_postmeta` VALUES (352,111,'hero_buttons_0_button_class','primary');
INSERT INTO `wp_postmeta` VALUES (353,111,'_hero_buttons_0_button_class','field_5eceb70d0e42d');
INSERT INTO `wp_postmeta` VALUES (354,111,'hero_buttons_0_button','a:3:{s:5:\"title\";s:11:\"Button Text\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}');
INSERT INTO `wp_postmeta` VALUES (355,111,'_hero_buttons_0_button','field_5ea715d8997dc');
INSERT INTO `wp_postmeta` VALUES (356,112,'hero_background','');
INSERT INTO `wp_postmeta` VALUES (357,112,'_hero_background','field_5ea71500997d7');
INSERT INTO `wp_postmeta` VALUES (358,112,'hero_horizontal_background_alignment','center');
INSERT INTO `wp_postmeta` VALUES (359,112,'_hero_horizontal_background_alignment','field_5ea715e6997dd');
INSERT INTO `wp_postmeta` VALUES (360,112,'hero_vertical_background_alignment','center');
INSERT INTO `wp_postmeta` VALUES (361,112,'_hero_vertical_background_alignment','field_5ea71621997de');
INSERT INTO `wp_postmeta` VALUES (362,112,'hero_column_span','10');
INSERT INTO `wp_postmeta` VALUES (363,112,'_hero_column_span','field_5ec56482a7c5f');
INSERT INTO `wp_postmeta` VALUES (364,112,'hero_column_alignment','center');
INSERT INTO `wp_postmeta` VALUES (365,112,'_hero_column_alignment','field_5ec564aba7c60');
INSERT INTO `wp_postmeta` VALUES (366,112,'hero_video_toggle','0');
INSERT INTO `wp_postmeta` VALUES (367,112,'_hero_video_toggle','field_5ea71568997d8');
INSERT INTO `wp_postmeta` VALUES (368,112,'hero_content','<h1 style=\"text-align: center;\">Hero Text</h1>\r\n&nbsp;\r\n\r\n&nbsp;');
INSERT INTO `wp_postmeta` VALUES (369,112,'_hero_content','field_5ea715a5997da');
INSERT INTO `wp_postmeta` VALUES (370,112,'hero_buttons','1');
INSERT INTO `wp_postmeta` VALUES (371,112,'_hero_buttons','field_5ea715c5997db');
INSERT INTO `wp_postmeta` VALUES (372,112,'hero_button_alignment','center');
INSERT INTO `wp_postmeta` VALUES (373,112,'_hero_button_alignment','field_5ea7170679be7');
INSERT INTO `wp_postmeta` VALUES (374,112,'default_hero','');
INSERT INTO `wp_postmeta` VALUES (375,112,'_default_hero','field_5ecd919847d49');
INSERT INTO `wp_postmeta` VALUES (376,112,'page_sections_0_centered_text_block_column_span','10');
INSERT INTO `wp_postmeta` VALUES (377,112,'_page_sections_0_centered_text_block_column_span','field_5ea7232bac58e_field_5ea7229da7a4d');
INSERT INTO `wp_postmeta` VALUES (378,112,'page_sections_0_centered_text_block_content','<p style=\"text-align: center;\">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>');
INSERT INTO `wp_postmeta` VALUES (379,112,'_page_sections_0_centered_text_block_content','field_5ea7232bac58e_field_5ea722c2a7a4e');
INSERT INTO `wp_postmeta` VALUES (380,112,'page_sections_0_centered_text_block_buttons','1');
INSERT INTO `wp_postmeta` VALUES (381,112,'_page_sections_0_centered_text_block_buttons','field_5ea7232bac58e_field_5ea722dca7a4f');
INSERT INTO `wp_postmeta` VALUES (382,112,'page_sections_0_centered_text_block_button_alignment','center');
INSERT INTO `wp_postmeta` VALUES (383,112,'_page_sections_0_centered_text_block_button_alignment','field_5ea7232bac58e_field_5ea72300a7a51');
INSERT INTO `wp_postmeta` VALUES (384,112,'page_sections_1_text_image_split_layout_option','left');
INSERT INTO `wp_postmeta` VALUES (385,112,'_page_sections_1_text_image_split_layout_option','field_5ea74fbf2ab11_field_5ea74e6eaf3c8');
INSERT INTO `wp_postmeta` VALUES (386,112,'page_sections_1_text_image_split_width_option','1');
INSERT INTO `wp_postmeta` VALUES (387,112,'_page_sections_1_text_image_split_width_option','field_5ea74fbf2ab11_field_5ea74e91af3c9');
INSERT INTO `wp_postmeta` VALUES (388,112,'page_sections_1_text_image_split_margin_option','0');
INSERT INTO `wp_postmeta` VALUES (389,112,'_page_sections_1_text_image_split_margin_option','field_5ea74fbf2ab11_field_5ea74ed9af3ca');
INSERT INTO `wp_postmeta` VALUES (390,112,'page_sections_1_text_image_split_background_color','#d9d9d9');
INSERT INTO `wp_postmeta` VALUES (391,112,'_page_sections_1_text_image_split_background_color','field_5ea74fbf2ab11_field_5eb43094542c6');
INSERT INTO `wp_postmeta` VALUES (392,112,'page_sections_1_text_image_split_image','');
INSERT INTO `wp_postmeta` VALUES (393,112,'_page_sections_1_text_image_split_image','field_5ea74fbf2ab11_field_5ea74f04af3cb');
INSERT INTO `wp_postmeta` VALUES (394,112,'page_sections_1_text_image_split_content','Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.');
INSERT INTO `wp_postmeta` VALUES (395,112,'_page_sections_1_text_image_split_content','field_5ea74fbf2ab11_field_5ea74f2caf3cc');
INSERT INTO `wp_postmeta` VALUES (396,112,'page_sections_1_text_image_split_button_toggle','0');
INSERT INTO `wp_postmeta` VALUES (397,112,'_page_sections_1_text_image_split_button_toggle','field_5ea74fbf2ab11_field_5ea74f40af3cd');
INSERT INTO `wp_postmeta` VALUES (398,112,'page_sections','a:2:{i:0;s:19:\"centered_text_block\";i:1;s:16:\"text_image_split\";}');
INSERT INTO `wp_postmeta` VALUES (399,112,'_page_sections','field_5ea7226f8cc0b');
INSERT INTO `wp_postmeta` VALUES (400,112,'default_sections','');
INSERT INTO `wp_postmeta` VALUES (401,112,'_default_sections','field_5ecd91ab47d4b');
INSERT INTO `wp_postmeta` VALUES (402,112,'page_sections_0_centered_text_block_buttons_0_button_class','primary');
INSERT INTO `wp_postmeta` VALUES (403,112,'_page_sections_0_centered_text_block_buttons_0_button_class','field_5eceb63abcc3a');
INSERT INTO `wp_postmeta` VALUES (404,112,'page_sections_0_centered_text_block_buttons_0_button','a:3:{s:5:\"title\";s:6:\"Button\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}');
INSERT INTO `wp_postmeta` VALUES (405,112,'_page_sections_0_centered_text_block_buttons_0_button','field_5ea722f8a7a50');
INSERT INTO `wp_postmeta` VALUES (406,112,'hero_buttons_0_button_class','primary');
INSERT INTO `wp_postmeta` VALUES (407,112,'_hero_buttons_0_button_class','field_5eceb70d0e42d');
INSERT INTO `wp_postmeta` VALUES (408,112,'hero_buttons_0_button','a:3:{s:5:\"title\";s:11:\"Button Text\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}');
INSERT INTO `wp_postmeta` VALUES (409,112,'_hero_buttons_0_button','field_5ea715d8997dc');
INSERT INTO `wp_postmeta` VALUES (410,36,'_edit_last','1');
INSERT INTO `wp_postmeta` VALUES (427,114,'hero_background','');
INSERT INTO `wp_postmeta` VALUES (428,114,'_hero_background','field_5ea71500997d7');
INSERT INTO `wp_postmeta` VALUES (429,114,'hero_horizontal_background_alignment','center');
INSERT INTO `wp_postmeta` VALUES (430,114,'_hero_horizontal_background_alignment','field_5ea715e6997dd');
INSERT INTO `wp_postmeta` VALUES (431,114,'hero_vertical_background_alignment','center');
INSERT INTO `wp_postmeta` VALUES (432,114,'_hero_vertical_background_alignment','field_5ea71621997de');
INSERT INTO `wp_postmeta` VALUES (433,114,'hero_column_span','10');
INSERT INTO `wp_postmeta` VALUES (434,114,'_hero_column_span','field_5ec56482a7c5f');
INSERT INTO `wp_postmeta` VALUES (435,114,'hero_column_alignment','center');
INSERT INTO `wp_postmeta` VALUES (436,114,'_hero_column_alignment','field_5ec564aba7c60');
INSERT INTO `wp_postmeta` VALUES (437,114,'hero_video_toggle','0');
INSERT INTO `wp_postmeta` VALUES (438,114,'_hero_video_toggle','field_5ea71568997d8');
INSERT INTO `wp_postmeta` VALUES (439,114,'hero_content','<h1 style=\"text-align: center;\">Hero Text</h1>\r\n&nbsp;\r\n\r\n&nbsp;');
INSERT INTO `wp_postmeta` VALUES (440,114,'_hero_content','field_5ea715a5997da');
INSERT INTO `wp_postmeta` VALUES (441,114,'hero_buttons','1');
INSERT INTO `wp_postmeta` VALUES (442,114,'_hero_buttons','field_5ea715c5997db');
INSERT INTO `wp_postmeta` VALUES (443,114,'hero_button_alignment','center');
INSERT INTO `wp_postmeta` VALUES (444,114,'_hero_button_alignment','field_5ea7170679be7');
INSERT INTO `wp_postmeta` VALUES (445,114,'default_hero','');
INSERT INTO `wp_postmeta` VALUES (446,114,'_default_hero','field_5ecd919847d49');
INSERT INTO `wp_postmeta` VALUES (447,114,'page_sections_0_centered_text_block_column_span','10');
INSERT INTO `wp_postmeta` VALUES (448,114,'_page_sections_0_centered_text_block_column_span','field_5ea7232bac58e_field_5ea7229da7a4d');
INSERT INTO `wp_postmeta` VALUES (449,114,'page_sections_0_centered_text_block_content','<p style=\"text-align: center;\">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>');
INSERT INTO `wp_postmeta` VALUES (450,114,'_page_sections_0_centered_text_block_content','field_5ea7232bac58e_field_5ea722c2a7a4e');
INSERT INTO `wp_postmeta` VALUES (451,114,'page_sections_0_centered_text_block_buttons','1');
INSERT INTO `wp_postmeta` VALUES (452,114,'_page_sections_0_centered_text_block_buttons','field_5ea7232bac58e_field_5ea722dca7a4f');
INSERT INTO `wp_postmeta` VALUES (453,114,'page_sections_0_centered_text_block_button_alignment','center');
INSERT INTO `wp_postmeta` VALUES (454,114,'_page_sections_0_centered_text_block_button_alignment','field_5ea7232bac58e_field_5ea72300a7a51');
INSERT INTO `wp_postmeta` VALUES (455,114,'page_sections_1_text_image_split_layout_option','left');
INSERT INTO `wp_postmeta` VALUES (456,114,'_page_sections_1_text_image_split_layout_option','field_5ea74fbf2ab11_field_5ea74e6eaf3c8');
INSERT INTO `wp_postmeta` VALUES (457,114,'page_sections_1_text_image_split_width_option','1');
INSERT INTO `wp_postmeta` VALUES (458,114,'_page_sections_1_text_image_split_width_option','field_5ea74fbf2ab11_field_5ea74e91af3c9');
INSERT INTO `wp_postmeta` VALUES (459,114,'page_sections_1_text_image_split_margin_option','0');
INSERT INTO `wp_postmeta` VALUES (460,114,'_page_sections_1_text_image_split_margin_option','field_5ea74fbf2ab11_field_5ea74ed9af3ca');
INSERT INTO `wp_postmeta` VALUES (461,114,'page_sections_1_text_image_split_background_color','#d9d9d9');
INSERT INTO `wp_postmeta` VALUES (462,114,'_page_sections_1_text_image_split_background_color','field_5ea74fbf2ab11_field_5eb43094542c6');
INSERT INTO `wp_postmeta` VALUES (463,114,'page_sections_1_text_image_split_image','');
INSERT INTO `wp_postmeta` VALUES (464,114,'_page_sections_1_text_image_split_image','field_5ea74fbf2ab11_field_5ea74f04af3cb');
INSERT INTO `wp_postmeta` VALUES (465,114,'page_sections_1_text_image_split_content','Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.');
INSERT INTO `wp_postmeta` VALUES (466,114,'_page_sections_1_text_image_split_content','field_5ea74fbf2ab11_field_5ea74f2caf3cc');
INSERT INTO `wp_postmeta` VALUES (467,114,'page_sections_1_text_image_split_button_toggle','0');
INSERT INTO `wp_postmeta` VALUES (468,114,'_page_sections_1_text_image_split_button_toggle','field_5ea74fbf2ab11_field_5ea74f40af3cd');
INSERT INTO `wp_postmeta` VALUES (469,114,'page_sections','a:3:{i:0;s:19:\"centered_text_block\";i:1;s:16:\"text_image_split\";i:2;s:6:\"banner\";}');
INSERT INTO `wp_postmeta` VALUES (470,114,'_page_sections','field_5ea7226f8cc0b');
INSERT INTO `wp_postmeta` VALUES (471,114,'default_sections','');
INSERT INTO `wp_postmeta` VALUES (472,114,'_default_sections','field_5ecd91ab47d4b');
INSERT INTO `wp_postmeta` VALUES (473,114,'page_sections_0_centered_text_block_buttons_0_button_class','primary');
INSERT INTO `wp_postmeta` VALUES (474,114,'_page_sections_0_centered_text_block_buttons_0_button_class','field_5eceb63abcc3a');
INSERT INTO `wp_postmeta` VALUES (475,114,'page_sections_0_centered_text_block_buttons_0_button','a:3:{s:5:\"title\";s:6:\"Button\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}');
INSERT INTO `wp_postmeta` VALUES (476,114,'_page_sections_0_centered_text_block_buttons_0_button','field_5ea722f8a7a50');
INSERT INTO `wp_postmeta` VALUES (477,114,'hero_buttons_0_button_class','primary');
INSERT INTO `wp_postmeta` VALUES (478,114,'_hero_buttons_0_button_class','field_5eceb70d0e42d');
INSERT INTO `wp_postmeta` VALUES (479,114,'hero_buttons_0_button','a:3:{s:5:\"title\";s:11:\"Button Text\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}');
INSERT INTO `wp_postmeta` VALUES (480,114,'_hero_buttons_0_button','field_5ea715d8997dc');
INSERT INTO `wp_postmeta` VALUES (481,114,'page_sections_2_banner_background','');
INSERT INTO `wp_postmeta` VALUES (482,114,'_page_sections_2_banner_background','field_5ea7277adf1e1_field_5ea725fcce65b');
INSERT INTO `wp_postmeta` VALUES (483,114,'page_sections_2_banner_width_option','1');
INSERT INTO `wp_postmeta` VALUES (484,114,'_page_sections_2_banner_width_option','field_5ea7277adf1e1_field_5ea726b6ce65f');
INSERT INTO `wp_postmeta` VALUES (485,114,'page_sections_2_banner_padding','200');
INSERT INTO `wp_postmeta` VALUES (486,114,'_page_sections_2_banner_padding','field_5ea7277adf1e1_field_5ea730d6208c2');
INSERT INTO `wp_postmeta` VALUES (487,114,'page_sections_2_banner_horizontal_background_alignment','center');
INSERT INTO `wp_postmeta` VALUES (488,114,'_page_sections_2_banner_horizontal_background_alignment','field_5ea7277adf1e1_field_5ea72624ce65c');
INSERT INTO `wp_postmeta` VALUES (489,114,'page_sections_2_banner_vertical_background_alignment','center');
INSERT INTO `wp_postmeta` VALUES (490,114,'_page_sections_2_banner_vertical_background_alignment','field_5ea7277adf1e1_field_5ea72668ce65d');
INSERT INTO `wp_postmeta` VALUES (491,114,'page_sections_2_banner_column_span','8');
INSERT INTO `wp_postmeta` VALUES (492,114,'_page_sections_2_banner_column_span','field_5ea7277adf1e1_field_5ea7272cce660');
INSERT INTO `wp_postmeta` VALUES (493,114,'page_sections_2_banner_content','');
INSERT INTO `wp_postmeta` VALUES (494,114,'_page_sections_2_banner_content','field_5ea7277adf1e1_field_5ea7268fce65e');
INSERT INTO `wp_postmeta` VALUES (495,114,'page_sections_2_banner_button_toggle','0');
INSERT INTO `wp_postmeta` VALUES (496,114,'_page_sections_2_banner_button_toggle','field_5ea7277adf1e1_field_5ec563f3abc26');
INSERT INTO `wp_postmeta` VALUES (497,47,'_edit_last','1');
INSERT INTO `wp_postmeta` VALUES (498,53,'_edit_last','1');
INSERT INTO `wp_postmeta` VALUES (499,63,'_edit_last','1');
INSERT INTO `wp_postmeta` VALUES (500,118,'hero_background','');
INSERT INTO `wp_postmeta` VALUES (501,118,'_hero_background','field_5ea71500997d7');
INSERT INTO `wp_postmeta` VALUES (502,118,'hero_horizontal_background_alignment','center');
INSERT INTO `wp_postmeta` VALUES (503,118,'_hero_horizontal_background_alignment','field_5ea715e6997dd');
INSERT INTO `wp_postmeta` VALUES (504,118,'hero_vertical_background_alignment','center');
INSERT INTO `wp_postmeta` VALUES (505,118,'_hero_vertical_background_alignment','field_5ea71621997de');
INSERT INTO `wp_postmeta` VALUES (506,118,'hero_column_span','10');
INSERT INTO `wp_postmeta` VALUES (507,118,'_hero_column_span','field_5ec56482a7c5f');
INSERT INTO `wp_postmeta` VALUES (508,118,'hero_column_alignment','center');
INSERT INTO `wp_postmeta` VALUES (509,118,'_hero_column_alignment','field_5ec564aba7c60');
INSERT INTO `wp_postmeta` VALUES (510,118,'hero_video_toggle','0');
INSERT INTO `wp_postmeta` VALUES (511,118,'_hero_video_toggle','field_5ea71568997d8');
INSERT INTO `wp_postmeta` VALUES (512,118,'hero_content','<h1 style=\"text-align: center;\">Hero Text</h1>\r\n&nbsp;\r\n\r\n&nbsp;');
INSERT INTO `wp_postmeta` VALUES (513,118,'_hero_content','field_5ea715a5997da');
INSERT INTO `wp_postmeta` VALUES (514,118,'hero_buttons','1');
INSERT INTO `wp_postmeta` VALUES (515,118,'_hero_buttons','field_5ea715c5997db');
INSERT INTO `wp_postmeta` VALUES (516,118,'hero_button_alignment','center');
INSERT INTO `wp_postmeta` VALUES (517,118,'_hero_button_alignment','field_5ea7170679be7');
INSERT INTO `wp_postmeta` VALUES (518,118,'default_hero','');
INSERT INTO `wp_postmeta` VALUES (519,118,'_default_hero','field_5ecd919847d49');
INSERT INTO `wp_postmeta` VALUES (520,118,'page_sections_0_centered_text_block_column_span','10');
INSERT INTO `wp_postmeta` VALUES (521,118,'_page_sections_0_centered_text_block_column_span','field_5ea7232bac58e_field_5ea7229da7a4d');
INSERT INTO `wp_postmeta` VALUES (522,118,'page_sections_0_centered_text_block_content','<p style=\"text-align: center;\">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>');
INSERT INTO `wp_postmeta` VALUES (523,118,'_page_sections_0_centered_text_block_content','field_5ea7232bac58e_field_5ea722c2a7a4e');
INSERT INTO `wp_postmeta` VALUES (524,118,'page_sections_0_centered_text_block_buttons','1');
INSERT INTO `wp_postmeta` VALUES (525,118,'_page_sections_0_centered_text_block_buttons','field_5ea7232bac58e_field_5ea722dca7a4f');
INSERT INTO `wp_postmeta` VALUES (526,118,'page_sections_0_centered_text_block_button_alignment','center');
INSERT INTO `wp_postmeta` VALUES (527,118,'_page_sections_0_centered_text_block_button_alignment','field_5ea7232bac58e_field_5ea72300a7a51');
INSERT INTO `wp_postmeta` VALUES (528,118,'page_sections_1_text_image_split_layout_option','left');
INSERT INTO `wp_postmeta` VALUES (529,118,'_page_sections_1_text_image_split_layout_option','field_5ea74fbf2ab11_field_5ea74e6eaf3c8');
INSERT INTO `wp_postmeta` VALUES (530,118,'page_sections_1_text_image_split_width_option','1');
INSERT INTO `wp_postmeta` VALUES (531,118,'_page_sections_1_text_image_split_width_option','field_5ea74fbf2ab11_field_5ea74e91af3c9');
INSERT INTO `wp_postmeta` VALUES (532,118,'page_sections_1_text_image_split_margin_option','0');
INSERT INTO `wp_postmeta` VALUES (533,118,'_page_sections_1_text_image_split_margin_option','field_5ea74fbf2ab11_field_5ea74ed9af3ca');
INSERT INTO `wp_postmeta` VALUES (534,118,'page_sections_1_text_image_split_background_color','#d9d9d9');
INSERT INTO `wp_postmeta` VALUES (535,118,'_page_sections_1_text_image_split_background_color','field_5ea74fbf2ab11_field_5eb43094542c6');
INSERT INTO `wp_postmeta` VALUES (536,118,'page_sections_1_text_image_split_image','');
INSERT INTO `wp_postmeta` VALUES (537,118,'_page_sections_1_text_image_split_image','field_5ea74fbf2ab11_field_5ea74f04af3cb');
INSERT INTO `wp_postmeta` VALUES (538,118,'page_sections_1_text_image_split_content','Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.');
INSERT INTO `wp_postmeta` VALUES (539,118,'_page_sections_1_text_image_split_content','field_5ea74fbf2ab11_field_5ea74f2caf3cc');
INSERT INTO `wp_postmeta` VALUES (540,118,'page_sections_1_text_image_split_button_toggle','0');
INSERT INTO `wp_postmeta` VALUES (541,118,'_page_sections_1_text_image_split_button_toggle','field_5ea74fbf2ab11_field_5ea74f40af3cd');
INSERT INTO `wp_postmeta` VALUES (542,118,'page_sections','a:2:{i:0;s:19:\"centered_text_block\";i:1;s:16:\"text_image_split\";}');
INSERT INTO `wp_postmeta` VALUES (543,118,'_page_sections','field_5ea7226f8cc0b');
INSERT INTO `wp_postmeta` VALUES (544,118,'default_sections','');
INSERT INTO `wp_postmeta` VALUES (545,118,'_default_sections','field_5ecd91ab47d4b');
INSERT INTO `wp_postmeta` VALUES (546,118,'page_sections_0_centered_text_block_buttons_0_button_class','primary');
INSERT INTO `wp_postmeta` VALUES (547,118,'_page_sections_0_centered_text_block_buttons_0_button_class','field_5eceb63abcc3a');
INSERT INTO `wp_postmeta` VALUES (548,118,'page_sections_0_centered_text_block_buttons_0_button','a:3:{s:5:\"title\";s:6:\"Button\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}');
INSERT INTO `wp_postmeta` VALUES (549,118,'_page_sections_0_centered_text_block_buttons_0_button','field_5ea722f8a7a50');
INSERT INTO `wp_postmeta` VALUES (550,118,'hero_buttons_0_button_class','primary');
INSERT INTO `wp_postmeta` VALUES (551,118,'_hero_buttons_0_button_class','field_5eceb70d0e42d');
INSERT INTO `wp_postmeta` VALUES (552,118,'hero_buttons_0_button','a:3:{s:5:\"title\";s:11:\"Button Text\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}');
INSERT INTO `wp_postmeta` VALUES (553,118,'_hero_buttons_0_button','field_5ea715d8997dc');
INSERT INTO `wp_postmeta` VALUES (554,119,'_menu_item_type','post_type');
INSERT INTO `wp_postmeta` VALUES (555,119,'_menu_item_menu_item_parent','0');
INSERT INTO `wp_postmeta` VALUES (556,119,'_menu_item_object_id','2');
INSERT INTO `wp_postmeta` VALUES (557,119,'_menu_item_object','page');
INSERT INTO `wp_postmeta` VALUES (558,119,'_menu_item_target','');
INSERT INTO `wp_postmeta` VALUES (559,119,'_menu_item_classes','a:1:{i:0;s:0:\"\";}');
INSERT INTO `wp_postmeta` VALUES (560,119,'_menu_item_xfn','');
INSERT INTO `wp_postmeta` VALUES (561,119,'_menu_item_url','');
INSERT INTO `wp_postmeta` VALUES (563,120,'_menu_item_type','post_type');
INSERT INTO `wp_postmeta` VALUES (564,120,'_menu_item_menu_item_parent','0');
INSERT INTO `wp_postmeta` VALUES (565,120,'_menu_item_object_id','87');
INSERT INTO `wp_postmeta` VALUES (566,120,'_menu_item_object','page');
INSERT INTO `wp_postmeta` VALUES (567,120,'_menu_item_target','');
INSERT INTO `wp_postmeta` VALUES (568,120,'_menu_item_classes','a:1:{i:0;s:0:\"\";}');
INSERT INTO `wp_postmeta` VALUES (569,120,'_menu_item_xfn','');
INSERT INTO `wp_postmeta` VALUES (570,120,'_menu_item_url','');
INSERT INTO `wp_postmeta` VALUES (572,121,'_menu_item_type','post_type');
INSERT INTO `wp_postmeta` VALUES (573,121,'_menu_item_menu_item_parent','0');
INSERT INTO `wp_postmeta` VALUES (574,121,'_menu_item_object_id','85');
INSERT INTO `wp_postmeta` VALUES (575,121,'_menu_item_object','page');
INSERT INTO `wp_postmeta` VALUES (576,121,'_menu_item_target','');
INSERT INTO `wp_postmeta` VALUES (577,121,'_menu_item_classes','a:1:{i:0;s:0:\"\";}');
INSERT INTO `wp_postmeta` VALUES (578,121,'_menu_item_xfn','');
INSERT INTO `wp_postmeta` VALUES (579,121,'_menu_item_url','');
INSERT INTO `wp_postmeta` VALUES (581,122,'_menu_item_type','post_type');
INSERT INTO `wp_postmeta` VALUES (582,122,'_menu_item_menu_item_parent','0');
INSERT INTO `wp_postmeta` VALUES (583,122,'_menu_item_object_id','2');
INSERT INTO `wp_postmeta` VALUES (584,122,'_menu_item_object','page');
INSERT INTO `wp_postmeta` VALUES (585,122,'_menu_item_target','');
INSERT INTO `wp_postmeta` VALUES (586,122,'_menu_item_classes','a:1:{i:0;s:0:\"\";}');
INSERT INTO `wp_postmeta` VALUES (587,122,'_menu_item_xfn','');
INSERT INTO `wp_postmeta` VALUES (588,122,'_menu_item_url','');
INSERT INTO `wp_postmeta` VALUES (590,123,'_menu_item_type','post_type');
INSERT INTO `wp_postmeta` VALUES (591,123,'_menu_item_menu_item_parent','0');
INSERT INTO `wp_postmeta` VALUES (592,123,'_menu_item_object_id','87');
INSERT INTO `wp_postmeta` VALUES (593,123,'_menu_item_object','page');
INSERT INTO `wp_postmeta` VALUES (594,123,'_menu_item_target','');
INSERT INTO `wp_postmeta` VALUES (595,123,'_menu_item_classes','a:1:{i:0;s:0:\"\";}');
INSERT INTO `wp_postmeta` VALUES (596,123,'_menu_item_xfn','');
INSERT INTO `wp_postmeta` VALUES (597,123,'_menu_item_url','');
INSERT INTO `wp_postmeta` VALUES (599,124,'_menu_item_type','post_type');
INSERT INTO `wp_postmeta` VALUES (600,124,'_menu_item_menu_item_parent','0');
INSERT INTO `wp_postmeta` VALUES (601,124,'_menu_item_object_id','85');
INSERT INTO `wp_postmeta` VALUES (602,124,'_menu_item_object','page');
INSERT INTO `wp_postmeta` VALUES (603,124,'_menu_item_target','');
INSERT INTO `wp_postmeta` VALUES (604,124,'_menu_item_classes','a:1:{i:0;s:0:\"\";}');
INSERT INTO `wp_postmeta` VALUES (605,124,'_menu_item_xfn','');
INSERT INTO `wp_postmeta` VALUES (606,124,'_menu_item_url','');
INSERT INTO `wp_postmeta` VALUES (608,125,'_menu_item_type','custom');
INSERT INTO `wp_postmeta` VALUES (609,125,'_menu_item_menu_item_parent','122');
INSERT INTO `wp_postmeta` VALUES (610,125,'_menu_item_object_id','125');
INSERT INTO `wp_postmeta` VALUES (611,125,'_menu_item_object','custom');
INSERT INTO `wp_postmeta` VALUES (612,125,'_menu_item_target','');
INSERT INTO `wp_postmeta` VALUES (613,125,'_menu_item_classes','a:1:{i:0;s:0:\"\";}');
INSERT INTO `wp_postmeta` VALUES (614,125,'_menu_item_xfn','');
INSERT INTO `wp_postmeta` VALUES (615,125,'_menu_item_url','#');
INSERT INTO `wp_postmeta` VALUES (617,126,'_menu_item_type','custom');
INSERT INTO `wp_postmeta` VALUES (618,126,'_menu_item_menu_item_parent','122');
INSERT INTO `wp_postmeta` VALUES (619,126,'_menu_item_object_id','126');
INSERT INTO `wp_postmeta` VALUES (620,126,'_menu_item_object','custom');
INSERT INTO `wp_postmeta` VALUES (621,126,'_menu_item_target','');
INSERT INTO `wp_postmeta` VALUES (622,126,'_menu_item_classes','a:1:{i:0;s:0:\"\";}');
INSERT INTO `wp_postmeta` VALUES (623,126,'_menu_item_xfn','');
INSERT INTO `wp_postmeta` VALUES (624,126,'_menu_item_url','#');
INSERT INTO `wp_postmeta` VALUES (626,127,'_menu_item_type','custom');
INSERT INTO `wp_postmeta` VALUES (627,127,'_menu_item_menu_item_parent','123');
INSERT INTO `wp_postmeta` VALUES (628,127,'_menu_item_object_id','127');
INSERT INTO `wp_postmeta` VALUES (629,127,'_menu_item_object','custom');
INSERT INTO `wp_postmeta` VALUES (630,127,'_menu_item_target','');
INSERT INTO `wp_postmeta` VALUES (631,127,'_menu_item_classes','a:1:{i:0;s:0:\"\";}');
INSERT INTO `wp_postmeta` VALUES (632,127,'_menu_item_xfn','');
INSERT INTO `wp_postmeta` VALUES (633,127,'_menu_item_url','#');
INSERT INTO `wp_postmeta` VALUES (635,128,'_menu_item_type','custom');
INSERT INTO `wp_postmeta` VALUES (636,128,'_menu_item_menu_item_parent','123');
INSERT INTO `wp_postmeta` VALUES (637,128,'_menu_item_object_id','128');
INSERT INTO `wp_postmeta` VALUES (638,128,'_menu_item_object','custom');
INSERT INTO `wp_postmeta` VALUES (639,128,'_menu_item_target','');
INSERT INTO `wp_postmeta` VALUES (640,128,'_menu_item_classes','a:1:{i:0;s:0:\"\";}');
INSERT INTO `wp_postmeta` VALUES (641,128,'_menu_item_xfn','');
INSERT INTO `wp_postmeta` VALUES (642,128,'_menu_item_url','#');
INSERT INTO `wp_postmeta` VALUES (644,129,'_menu_item_type','custom');
INSERT INTO `wp_postmeta` VALUES (645,129,'_menu_item_menu_item_parent','123');
INSERT INTO `wp_postmeta` VALUES (646,129,'_menu_item_object_id','129');
INSERT INTO `wp_postmeta` VALUES (647,129,'_menu_item_object','custom');
INSERT INTO `wp_postmeta` VALUES (648,129,'_menu_item_target','');
INSERT INTO `wp_postmeta` VALUES (649,129,'_menu_item_classes','a:1:{i:0;s:0:\"\";}');
INSERT INTO `wp_postmeta` VALUES (650,129,'_menu_item_xfn','');
INSERT INTO `wp_postmeta` VALUES (651,129,'_menu_item_url','#');
INSERT INTO `wp_postmeta` VALUES (653,130,'_menu_item_type','custom');
INSERT INTO `wp_postmeta` VALUES (654,130,'_menu_item_menu_item_parent','124');
INSERT INTO `wp_postmeta` VALUES (655,130,'_menu_item_object_id','130');
INSERT INTO `wp_postmeta` VALUES (656,130,'_menu_item_object','custom');
INSERT INTO `wp_postmeta` VALUES (657,130,'_menu_item_target','');
INSERT INTO `wp_postmeta` VALUES (658,130,'_menu_item_classes','a:1:{i:0;s:0:\"\";}');
INSERT INTO `wp_postmeta` VALUES (659,130,'_menu_item_xfn','');
INSERT INTO `wp_postmeta` VALUES (660,130,'_menu_item_url','#');
INSERT INTO `wp_postmeta` VALUES (662,131,'_menu_item_type','custom');
INSERT INTO `wp_postmeta` VALUES (663,131,'_menu_item_menu_item_parent','124');
INSERT INTO `wp_postmeta` VALUES (664,131,'_menu_item_object_id','131');
INSERT INTO `wp_postmeta` VALUES (665,131,'_menu_item_object','custom');
INSERT INTO `wp_postmeta` VALUES (666,131,'_menu_item_target','');
INSERT INTO `wp_postmeta` VALUES (667,131,'_menu_item_classes','a:1:{i:0;s:0:\"\";}');
INSERT INTO `wp_postmeta` VALUES (668,131,'_menu_item_xfn','');
INSERT INTO `wp_postmeta` VALUES (669,131,'_menu_item_url','#');
INSERT INTO `wp_postmeta` VALUES (671,132,'_menu_item_type','custom');
INSERT INTO `wp_postmeta` VALUES (672,132,'_menu_item_menu_item_parent','0');
INSERT INTO `wp_postmeta` VALUES (673,132,'_menu_item_object_id','132');
INSERT INTO `wp_postmeta` VALUES (674,132,'_menu_item_object','custom');
INSERT INTO `wp_postmeta` VALUES (675,132,'_menu_item_target','');
INSERT INTO `wp_postmeta` VALUES (676,132,'_menu_item_classes','a:1:{i:0;s:0:\"\";}');
INSERT INTO `wp_postmeta` VALUES (677,132,'_menu_item_xfn','');
INSERT INTO `wp_postmeta` VALUES (678,132,'_menu_item_url','https://facebook.com');
INSERT INTO `wp_postmeta` VALUES (680,133,'_menu_item_type','custom');
INSERT INTO `wp_postmeta` VALUES (681,133,'_menu_item_menu_item_parent','0');
INSERT INTO `wp_postmeta` VALUES (682,133,'_menu_item_object_id','133');
INSERT INTO `wp_postmeta` VALUES (683,133,'_menu_item_object','custom');
INSERT INTO `wp_postmeta` VALUES (684,133,'_menu_item_target','');
INSERT INTO `wp_postmeta` VALUES (685,133,'_menu_item_classes','a:1:{i:0;s:0:\"\";}');
INSERT INTO `wp_postmeta` VALUES (686,133,'_menu_item_xfn','');
INSERT INTO `wp_postmeta` VALUES (687,133,'_menu_item_url','https://linkedin.com');
INSERT INTO `wp_postmeta` VALUES (689,134,'_menu_item_type','custom');
INSERT INTO `wp_postmeta` VALUES (690,134,'_menu_item_menu_item_parent','0');
INSERT INTO `wp_postmeta` VALUES (691,134,'_menu_item_object_id','134');
INSERT INTO `wp_postmeta` VALUES (692,134,'_menu_item_object','custom');
INSERT INTO `wp_postmeta` VALUES (693,134,'_menu_item_target','');
INSERT INTO `wp_postmeta` VALUES (694,134,'_menu_item_classes','a:1:{i:0;s:0:\"\";}');
INSERT INTO `wp_postmeta` VALUES (695,134,'_menu_item_xfn','');
INSERT INTO `wp_postmeta` VALUES (696,134,'_menu_item_url','https://instagram.com');
INSERT INTO `wp_postmeta` VALUES (698,135,'_menu_item_type','custom');
INSERT INTO `wp_postmeta` VALUES (699,135,'_menu_item_menu_item_parent','0');
INSERT INTO `wp_postmeta` VALUES (700,135,'_menu_item_object_id','135');
INSERT INTO `wp_postmeta` VALUES (701,135,'_menu_item_object','custom');
INSERT INTO `wp_postmeta` VALUES (702,135,'_menu_item_target','');
INSERT INTO `wp_postmeta` VALUES (703,135,'_menu_item_classes','a:1:{i:0;s:0:\"\";}');
INSERT INTO `wp_postmeta` VALUES (704,135,'_menu_item_xfn','');
INSERT INTO `wp_postmeta` VALUES (705,135,'_menu_item_url','https://twitter.com');
INSERT INTO `wp_postmeta` VALUES (707,136,'_menu_item_type','custom');
INSERT INTO `wp_postmeta` VALUES (708,136,'_menu_item_menu_item_parent','0');
INSERT INTO `wp_postmeta` VALUES (709,136,'_menu_item_object_id','136');
INSERT INTO `wp_postmeta` VALUES (710,136,'_menu_item_object','custom');
INSERT INTO `wp_postmeta` VALUES (711,136,'_menu_item_target','');
INSERT INTO `wp_postmeta` VALUES (712,136,'_menu_item_classes','a:1:{i:0;s:0:\"\";}');
INSERT INTO `wp_postmeta` VALUES (713,136,'_menu_item_xfn','');
INSERT INTO `wp_postmeta` VALUES (714,136,'_menu_item_url','https://youtube.com');
/*!40000 ALTER TABLE `wp_postmeta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_posts`
--

DROP TABLE IF EXISTS `wp_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=137 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_posts`
--

LOCK TABLES `wp_posts` WRITE;
/*!40000 ALTER TABLE `wp_posts` DISABLE KEYS */;
INSERT INTO `wp_posts` VALUES (2,1,'2020-05-26 20:44:50','2020-05-26 20:44:50','<!-- wp:paragraph -->\r\n<p>This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:quote -->\r\n<blockquote class=\"wp-block-quote\">\r\n<p>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like piña coladas. (And gettin\' caught in the rain.)</p>\r\n</blockquote>\r\n<!-- /wp:quote -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>...or something like this:</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:quote -->\r\n<blockquote class=\"wp-block-quote\">\r\n<p>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</p>\r\n</blockquote>\r\n<!-- /wp:quote -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>As a new WordPress user, you should go to <a href=\"http://localhost:10008/wp-admin/\">your dashboard</a> to delete this page and create new pages for your content. Have fun!</p>\r\n<!-- /wp:paragraph -->','Sample Page','','publish','closed','open','','sample-page','','','2020-05-27 19:06:07','2020-05-27 19:06:07','',0,'http://localhost:10008/?page_id=2',0,'page','',0);
INSERT INTO `wp_posts` VALUES (7,1,'2020-05-26 21:41:37','2020-05-26 21:41:37','a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:9:\"post_type\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:4:\"post\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";}','Flex Layouts','flex-layouts','acf-disabled','closed','closed','','group_5ea7226568aaf','','','2020-05-26 22:02:31','2020-05-26 22:02:31','',0,'http://localhost:10008/?p=7',16,'acf-field-group','',0);
INSERT INTO `wp_posts` VALUES (8,1,'2020-05-26 21:41:37','2020-05-26 21:41:37','a:9:{s:4:\"type\";s:16:\"flexible_content\";s:12:\"instructions\";s:19:\"Click \"Add Section\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:7:\"layouts\";a:6:{s:20:\"layout_5ea7227625047\";a:6:{s:3:\"key\";s:20:\"layout_5ea7227625047\";s:5:\"label\";s:19:\"Centered Text Block\";s:4:\"name\";s:19:\"centered_text_block\";s:7:\"display\";s:5:\"block\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";}s:20:\"layout_5ea72776df1e0\";a:6:{s:3:\"key\";s:20:\"layout_5ea72776df1e0\";s:5:\"label\";s:6:\"Banner\";s:4:\"name\";s:6:\"banner\";s:7:\"display\";s:5:\"block\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";}s:20:\"layout_5ea73e70c1086\";a:6:{s:3:\"key\";s:20:\"layout_5ea73e70c1086\";s:5:\"label\";s:6:\"Slider\";s:4:\"name\";s:6:\"slider\";s:7:\"display\";s:5:\"block\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";}s:20:\"layout_5ea74fb52ab10\";a:6:{s:3:\"key\";s:20:\"layout_5ea74fb52ab10\";s:5:\"label\";s:16:\"Text/Image Split\";s:4:\"name\";s:16:\"text_image_split\";s:7:\"display\";s:5:\"block\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";}s:20:\"layout_5ea7578437d47\";a:6:{s:3:\"key\";s:20:\"layout_5ea7578437d47\";s:5:\"label\";s:13:\"3-Column Grid\";s:4:\"name\";s:13:\"3_column_grid\";s:7:\"display\";s:5:\"block\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";}s:20:\"layout_5ea88e547a63a\";a:6:{s:3:\"key\";s:20:\"layout_5ea88e547a63a\";s:5:\"label\";s:17:\"Newsletter Signup\";s:4:\"name\";s:17:\"newsletter_signup\";s:7:\"display\";s:5:\"block\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";}}s:12:\"button_label\";s:11:\"Add Section\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";}','Page Sections','page_sections','publish','closed','closed','','field_5ea7226f8cc0b','','','2020-05-26 22:02:31','2020-05-26 22:02:31','',7,'http://localhost:10008/?post_type=acf-field&#038;p=8',0,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (9,1,'2020-05-26 21:41:37','2020-05-26 21:41:37','a:11:{s:4:\"type\";s:5:\"clone\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:5:\"clone\";a:1:{i:0;s:19:\"group_5ea72291c1f7c\";}s:7:\"display\";s:8:\"seamless\";s:6:\"layout\";s:5:\"block\";s:12:\"prefix_label\";i:0;s:11:\"prefix_name\";i:0;s:13:\"parent_layout\";s:20:\"layout_5ea7227625047\";}','Flex Block','flex_block','publish','closed','closed','','field_5ea7232bac58e','','','2020-05-26 21:41:37','2020-05-26 21:41:37','',8,'http://localhost:10008/?post_type=acf-field&p=9',0,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (10,1,'2020-05-26 21:41:37','2020-05-26 21:41:37','a:11:{s:4:\"type\";s:5:\"clone\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:5:\"clone\";a:1:{i:0;s:19:\"group_5ea725c96a69b\";}s:7:\"display\";s:8:\"seamless\";s:6:\"layout\";s:5:\"block\";s:12:\"prefix_label\";i:0;s:11:\"prefix_name\";i:0;s:13:\"parent_layout\";s:20:\"layout_5ea72776df1e0\";}','Flex Banner','flex_banner','publish','closed','closed','','field_5ea7277adf1e1','','','2020-05-26 21:41:37','2020-05-26 21:41:37','',8,'http://localhost:10008/?post_type=acf-field&p=10',0,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (11,1,'2020-05-26 21:41:37','2020-05-26 21:41:37','a:11:{s:4:\"type\";s:5:\"clone\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:5:\"clone\";a:1:{i:0;s:19:\"group_5ea73d9f934ca\";}s:7:\"display\";s:8:\"seamless\";s:6:\"layout\";s:5:\"block\";s:12:\"prefix_label\";i:0;s:11:\"prefix_name\";i:0;s:13:\"parent_layout\";s:20:\"layout_5ea73e70c1086\";}','Flex Slider','flex_slider','publish','closed','closed','','field_5ea73e75c1087','','','2020-05-26 21:41:37','2020-05-26 21:41:37','',8,'http://localhost:10008/?post_type=acf-field&p=11',0,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (12,1,'2020-05-26 21:41:37','2020-05-26 21:41:37','a:11:{s:4:\"type\";s:5:\"clone\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:5:\"clone\";a:1:{i:0;s:19:\"group_5ea74e639f65c\";}s:7:\"display\";s:8:\"seamless\";s:6:\"layout\";s:5:\"block\";s:12:\"prefix_label\";i:0;s:11:\"prefix_name\";i:0;s:13:\"parent_layout\";s:20:\"layout_5ea74fb52ab10\";}','Flex Split','flex_split','publish','closed','closed','','field_5ea74fbf2ab11','','','2020-05-26 21:41:37','2020-05-26 21:41:37','',8,'http://localhost:10008/?post_type=acf-field&p=12',0,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (13,1,'2020-05-26 21:41:37','2020-05-26 21:41:37','a:11:{s:4:\"type\";s:5:\"clone\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:5:\"clone\";a:1:{i:0;s:19:\"group_5ea7568ed7f84\";}s:7:\"display\";s:8:\"seamless\";s:6:\"layout\";s:5:\"block\";s:12:\"prefix_label\";i:0;s:11:\"prefix_name\";i:0;s:13:\"parent_layout\";s:20:\"layout_5ea7578437d47\";}','Flex Grid','flex_grid','publish','closed','closed','','field_5ea7578f37d48','','','2020-05-26 21:41:37','2020-05-26 21:41:37','',8,'http://localhost:10008/?post_type=acf-field&p=13',0,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (15,1,'2020-05-26 21:41:37','2020-05-26 21:41:37','a:11:{s:4:\"type\";s:5:\"clone\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:5:\"clone\";a:1:{i:0;s:19:\"group_5ea88dde7cfa1\";}s:7:\"display\";s:8:\"seamless\";s:6:\"layout\";s:5:\"block\";s:12:\"prefix_label\";i:0;s:11:\"prefix_name\";i:0;s:13:\"parent_layout\";s:20:\"layout_5ea88e547a63a\";}','Flex Newsletter','flex_newsletter','publish','closed','closed','','field_5ea88e5b7a63b','','','2020-05-26 21:41:37','2020-05-26 21:41:37','',8,'http://localhost:10008/?post_type=acf-field&p=15',0,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (18,1,'2020-05-26 21:41:37','2020-05-26 21:41:37','a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:9:\"post_type\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:4:\"post\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";}','Hero (Global)','hero-global','acf-disabled','closed','closed','','group_5ea714edc7d39','','','2020-05-27 18:54:07','2020-05-27 18:54:07','',0,'http://localhost:10008/?p=18',17,'acf-field-group','',0);
INSERT INTO `wp_posts` VALUES (19,1,'2020-05-26 21:41:37','2020-05-26 21:41:37','a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:166:\"Upload the background image for the hero here (at least 1920 x 670 px) <br><br>\r\n\r\nThis image also serves as the fallback image for the background image (if enabled).\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:2:\"id\";s:12:\"preview_size\";s:9:\"thumbnail\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}','Background','hero_background','publish','closed','closed','','field_5ea71500997d7','','','2020-05-26 21:41:37','2020-05-26 21:41:37','',18,'http://localhost:10008/?post_type=acf-field&p=19',0,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (20,1,'2020-05-26 21:41:37','2020-05-26 21:41:37','a:12:{s:4:\"type\";s:5:\"radio\";s:12:\"instructions\";s:45:\"How should the image be horizontally aligned?\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:7:\"choices\";a:3:{s:4:\"left\";s:4:\"Left\";s:6:\"center\";s:6:\"Center\";s:5:\"right\";s:5:\"Right\";}s:10:\"allow_null\";i:0;s:12:\"other_choice\";i:0;s:13:\"default_value\";s:6:\"center\";s:6:\"layout\";s:8:\"vertical\";s:13:\"return_format\";s:5:\"value\";s:17:\"save_other_choice\";i:0;}','Horizontal Background Alignment','hero_horizontal_background_alignment','publish','closed','closed','','field_5ea715e6997dd','','','2020-05-26 21:41:37','2020-05-26 21:41:37','',18,'http://localhost:10008/?post_type=acf-field&p=20',1,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (21,1,'2020-05-26 21:41:37','2020-05-26 21:41:37','a:12:{s:4:\"type\";s:5:\"radio\";s:12:\"instructions\";s:43:\"How should the image be vertically aligned?\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:7:\"choices\";a:3:{s:3:\"top\";s:3:\"Top\";s:6:\"center\";s:6:\"Center\";s:6:\"bottom\";s:6:\"Bottom\";}s:10:\"allow_null\";i:0;s:12:\"other_choice\";i:0;s:13:\"default_value\";s:6:\"center\";s:6:\"layout\";s:8:\"vertical\";s:13:\"return_format\";s:5:\"value\";s:17:\"save_other_choice\";i:0;}','Vertical Background Alignment','hero_vertical_background_alignment','publish','closed','closed','','field_5ea71621997de','','','2020-05-26 21:41:37','2020-05-26 21:41:37','',18,'http://localhost:10008/?post_type=acf-field&p=21',2,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (22,1,'2020-05-26 21:41:37','2020-05-26 21:41:37','a:12:{s:4:\"type\";s:6:\"number\";s:12:\"instructions\";s:54:\"How many columns should this section span (max of 12)?\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";i:10;s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:3:\"min\";i:6;s:3:\"max\";i:12;s:4:\"step\";i:1;}','Column Span','hero_column_span','publish','closed','closed','','field_5ec56482a7c5f','','','2020-05-26 21:41:37','2020-05-26 21:41:37','',18,'http://localhost:10008/?post_type=acf-field&p=22',3,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (23,1,'2020-05-26 21:41:37','2020-05-26 21:41:37','a:12:{s:4:\"type\";s:5:\"radio\";s:12:\"instructions\";s:34:\"How should this column be aligned?\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:7:\"choices\";a:3:{s:5:\"start\";s:4:\"Left\";s:6:\"center\";s:6:\"Center\";s:3:\"end\";s:5:\"Right\";}s:10:\"allow_null\";i:0;s:12:\"other_choice\";i:0;s:13:\"default_value\";s:6:\"center\";s:6:\"layout\";s:8:\"vertical\";s:13:\"return_format\";s:5:\"value\";s:17:\"save_other_choice\";i:0;}','Column Alignment','hero_column_alignment','publish','closed','closed','','field_5ec564aba7c60','','','2020-05-26 21:41:37','2020-05-26 21:41:37','',18,'http://localhost:10008/?post_type=acf-field&p=23',4,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (24,1,'2020-05-26 21:41:37','2020-05-26 21:41:37','a:10:{s:4:\"type\";s:10:\"true_false\";s:12:\"instructions\";s:40:\"Display a background video in this hero?\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:7:\"message\";s:0:\"\";s:13:\"default_value\";i:0;s:2:\"ui\";i:1;s:10:\"ui_on_text\";s:0:\"\";s:11:\"ui_off_text\";s:0:\"\";}','Video Toggle','hero_video_toggle','publish','closed','closed','','field_5ea71568997d8','','','2020-05-26 21:41:37','2020-05-26 21:41:37','',18,'http://localhost:10008/?post_type=acf-field&p=24',5,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (25,1,'2020-05-26 21:41:37','2020-05-26 21:41:37','a:10:{s:4:\"type\";s:4:\"file\";s:12:\"instructions\";s:31:\"Upload the video .mp4 file here\";s:8:\"required\";i:0;s:17:\"conditional_logic\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"field\";s:19:\"field_5ea71568997d8\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:1:\"1\";}}}s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";s:7:\"library\";s:3:\"all\";s:8:\"min_size\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:4:\".mp4\";}','Video','hero_video','publish','closed','closed','','field_5ea7158b997d9','','','2020-05-26 21:41:37','2020-05-26 21:41:37','',18,'http://localhost:10008/?post_type=acf-field&p=25',6,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (26,1,'2020-05-26 21:41:37','2020-05-26 21:41:37','a:10:{s:4:\"type\";s:7:\"wysiwyg\";s:12:\"instructions\";s:40:\"Enter the text content for the hero here\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:4:\"tabs\";s:3:\"all\";s:7:\"toolbar\";s:4:\"full\";s:12:\"media_upload\";i:1;s:5:\"delay\";i:0;}','Content','hero_content','publish','closed','closed','','field_5ea715a5997da','','','2020-05-26 21:41:37','2020-05-26 21:41:37','',18,'http://localhost:10008/?post_type=acf-field&p=26',7,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (27,1,'2020-05-26 21:41:37','2020-05-26 21:41:37','a:10:{s:4:\"type\";s:8:\"repeater\";s:12:\"instructions\";s:18:\"Click \"Add Button\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"collapsed\";s:0:\"\";s:3:\"min\";i:0;s:3:\"max\";i:2;s:6:\"layout\";s:3:\"row\";s:12:\"button_label\";s:10:\"Add Button\";}','Buttons','hero_buttons','publish','closed','closed','','field_5ea715c5997db','','','2020-05-26 21:41:37','2020-05-26 21:41:37','',18,'http://localhost:10008/?post_type=acf-field&p=27',8,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (28,1,'2020-05-26 21:41:37','2020-05-26 21:41:37','a:6:{s:4:\"type\";s:4:\"link\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:5:\"array\";}','Button','button','publish','closed','closed','','field_5ea715d8997dc','','','2020-05-27 18:53:26','2020-05-27 18:53:26','',27,'http://localhost:10008/?post_type=acf-field&#038;p=28',1,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (29,1,'2020-05-26 21:41:37','2020-05-26 21:41:37','a:12:{s:4:\"type\";s:5:\"radio\";s:12:\"instructions\";s:36:\"How should the button(s) be aligned?\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:7:\"choices\";a:3:{s:4:\"left\";s:4:\"Left\";s:6:\"center\";s:6:\"Center\";s:5:\"right\";s:5:\"Right\";}s:10:\"allow_null\";i:0;s:12:\"other_choice\";i:0;s:13:\"default_value\";s:6:\"center\";s:6:\"layout\";s:8:\"vertical\";s:13:\"return_format\";s:5:\"value\";s:17:\"save_other_choice\";i:0;}','Button Alignment','hero_button_alignment','publish','closed','closed','','field_5ea7170679be7','','','2020-05-26 21:41:37','2020-05-26 21:41:37','',18,'http://localhost:10008/?post_type=acf-field&p=29',9,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (30,1,'2020-05-26 21:41:37','2020-05-26 21:41:37','a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:9:\"post_type\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:4:\"post\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";}','Centered Text Block (Global)','centered-text-block-global','acf-disabled','closed','closed','','group_5ea72291c1f7c','','','2020-05-27 18:51:57','2020-05-27 18:51:57','',0,'http://localhost:10008/?p=30',18,'acf-field-group','',0);
INSERT INTO `wp_posts` VALUES (31,1,'2020-05-26 21:41:37','2020-05-26 21:41:37','a:12:{s:4:\"type\";s:6:\"number\";s:12:\"instructions\";s:54:\"How many columns should this section span? (max of 12)\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";i:10;s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:3:\"min\";i:6;s:3:\"max\";i:12;s:4:\"step\";i:1;}','Column Span','centered_text_block_column_span','publish','closed','closed','','field_5ea7229da7a4d','','','2020-05-26 21:41:37','2020-05-26 21:41:37','',30,'http://localhost:10008/?post_type=acf-field&p=31',0,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (32,1,'2020-05-26 21:41:37','2020-05-26 21:41:37','a:10:{s:4:\"type\";s:7:\"wysiwyg\";s:12:\"instructions\";s:44:\"Enter the text content for this section here\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:4:\"tabs\";s:3:\"all\";s:7:\"toolbar\";s:4:\"full\";s:12:\"media_upload\";i:1;s:5:\"delay\";i:0;}','Content','centered_text_block_content','publish','closed','closed','','field_5ea722c2a7a4e','','','2020-05-26 21:41:37','2020-05-26 21:41:37','',30,'http://localhost:10008/?post_type=acf-field&p=32',1,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (33,1,'2020-05-26 21:41:37','2020-05-26 21:41:37','a:10:{s:4:\"type\";s:8:\"repeater\";s:12:\"instructions\";s:18:\"Click \"Add Button\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"collapsed\";s:0:\"\";s:3:\"min\";i:0;s:3:\"max\";i:2;s:6:\"layout\";s:3:\"row\";s:12:\"button_label\";s:10:\"Add Button\";}','Buttons','centered_text_block_buttons','publish','closed','closed','','field_5ea722dca7a4f','','','2020-05-26 21:41:37','2020-05-26 21:41:37','',30,'http://localhost:10008/?post_type=acf-field&p=33',2,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (34,1,'2020-05-26 21:41:37','2020-05-26 21:41:37','a:6:{s:4:\"type\";s:4:\"link\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:5:\"array\";}','Button','button','publish','closed','closed','','field_5ea722f8a7a50','','','2020-05-27 18:51:11','2020-05-27 18:51:11','',33,'http://localhost:10008/?post_type=acf-field&#038;p=34',1,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (35,1,'2020-05-26 21:41:37','2020-05-26 21:41:37','a:12:{s:4:\"type\";s:5:\"radio\";s:12:\"instructions\";s:36:\"How should the button(s) be aligned?\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:7:\"choices\";a:3:{s:4:\"left\";s:4:\"Left\";s:6:\"center\";s:6:\"Center\";s:5:\"right\";s:5:\"Right\";}s:10:\"allow_null\";i:0;s:12:\"other_choice\";i:0;s:13:\"default_value\";s:6:\"center\";s:6:\"layout\";s:8:\"vertical\";s:13:\"return_format\";s:5:\"value\";s:17:\"save_other_choice\";i:0;}','Button Alignment','centered_text_block_button_alignment','publish','closed','closed','','field_5ea72300a7a51','','','2020-05-26 21:41:37','2020-05-26 21:41:37','',30,'http://localhost:10008/?post_type=acf-field&p=35',3,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (36,1,'2020-05-26 21:41:37','2020-05-26 21:41:37','a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:9:\"post_type\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:4:\"post\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";}','Banner (Global)','banner-global','acf-disabled','closed','closed','','group_5ea725c96a69b','','','2020-05-27 18:58:48','2020-05-27 18:58:48','',0,'http://localhost:10008/?p=36',19,'acf-field-group','',0);
INSERT INTO `wp_posts` VALUES (37,1,'2020-05-26 21:41:37','2020-05-26 21:41:37','a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:74:\"Upload the background image for this section here (at least 1920 x 545 px)\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:2:\"id\";s:12:\"preview_size\";s:9:\"thumbnail\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}','Background','banner_background','publish','closed','closed','','field_5ea725fcce65b','','','2020-05-26 21:41:37','2020-05-26 21:41:37','',36,'http://localhost:10008/?post_type=acf-field&p=37',0,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (38,1,'2020-05-26 21:41:37','2020-05-26 21:41:37','a:10:{s:4:\"type\";s:10:\"true_false\";s:12:\"instructions\";s:185:\"Is this a full-width banner?<br><br>\r\n\r\nIf so, the background will stretch to the edges of the screen.<br><br>\r\n\r\nIf not, the background will stretch to the edges of the 12-column grid.\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:7:\"message\";s:0:\"\";s:13:\"default_value\";i:1;s:2:\"ui\";i:1;s:10:\"ui_on_text\";s:0:\"\";s:11:\"ui_off_text\";s:0:\"\";}','Width Option','banner_width_option','publish','closed','closed','','field_5ea726b6ce65f','','','2020-05-26 21:41:37','2020-05-26 21:41:37','',36,'http://localhost:10008/?post_type=acf-field&p=38',1,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (39,1,'2020-05-26 21:41:37','2020-05-26 21:41:37','a:12:{s:4:\"type\";s:6:\"number\";s:12:\"instructions\";s:81:\"How much padding should be applied to the top and bottom of this section (in px)?\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";i:200;s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:3:\"min\";i:50;s:3:\"max\";i:500;s:4:\"step\";i:1;}','Padding','banner_padding','publish','closed','closed','','field_5ea730d6208c2','','','2020-05-26 21:41:37','2020-05-26 21:41:37','',36,'http://localhost:10008/?post_type=acf-field&p=39',2,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (40,1,'2020-05-26 21:41:37','2020-05-26 21:41:37','a:12:{s:4:\"type\";s:5:\"radio\";s:12:\"instructions\";s:50:\"How should the background be horizontally aligned?\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:7:\"choices\";a:3:{s:4:\"left\";s:4:\"Left\";s:6:\"center\";s:6:\"Center\";s:5:\"right\";s:5:\"Right\";}s:10:\"allow_null\";i:0;s:12:\"other_choice\";i:0;s:13:\"default_value\";s:6:\"center\";s:6:\"layout\";s:8:\"vertical\";s:13:\"return_format\";s:5:\"value\";s:17:\"save_other_choice\";i:0;}','Horizontal Background Alignment','banner_horizontal_background_alignment','publish','closed','closed','','field_5ea72624ce65c','','','2020-05-26 21:41:37','2020-05-26 21:41:37','',36,'http://localhost:10008/?post_type=acf-field&p=40',3,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (41,1,'2020-05-26 21:41:37','2020-05-26 21:41:37','a:12:{s:4:\"type\";s:5:\"radio\";s:12:\"instructions\";s:48:\"How should the background be vertically aligned?\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:7:\"choices\";a:3:{s:3:\"top\";s:3:\"Top\";s:6:\"center\";s:6:\"Center\";s:6:\"bottom\";s:6:\"Bottom\";}s:10:\"allow_null\";i:0;s:12:\"other_choice\";i:0;s:13:\"default_value\";s:6:\"center\";s:6:\"layout\";s:8:\"vertical\";s:13:\"return_format\";s:5:\"value\";s:17:\"save_other_choice\";i:0;}','Vertical Background Alignment','banner_vertical_background_alignment','publish','closed','closed','','field_5ea72668ce65d','','','2020-05-26 21:41:37','2020-05-26 21:41:37','',36,'http://localhost:10008/?post_type=acf-field&p=41',4,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (42,1,'2020-05-26 21:41:37','2020-05-26 21:41:37','a:12:{s:4:\"type\";s:6:\"number\";s:12:\"instructions\";s:59:\"How many columns does the section content span? (max of 12)\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";i:8;s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:3:\"min\";i:6;s:3:\"max\";i:12;s:4:\"step\";i:1;}','Column Span','banner_column_span','publish','closed','closed','','field_5ea7272cce660','','','2020-05-26 21:41:37','2020-05-26 21:41:37','',36,'http://localhost:10008/?post_type=acf-field&p=42',5,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (43,1,'2020-05-26 21:41:37','2020-05-26 21:41:37','a:10:{s:4:\"type\";s:7:\"wysiwyg\";s:12:\"instructions\";s:39:\"Enter the text content for this section\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:4:\"tabs\";s:3:\"all\";s:7:\"toolbar\";s:4:\"full\";s:12:\"media_upload\";i:1;s:5:\"delay\";i:0;}','Content','banner_content','publish','closed','closed','','field_5ea7268fce65e','','','2020-05-26 21:41:37','2020-05-26 21:41:37','',36,'http://localhost:10008/?post_type=acf-field&p=43',6,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (44,1,'2020-05-26 21:41:37','2020-05-26 21:41:37','a:10:{s:4:\"type\";s:10:\"true_false\";s:12:\"instructions\";s:22:\"Display a button here?\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:7:\"message\";s:0:\"\";s:13:\"default_value\";i:0;s:2:\"ui\";i:1;s:10:\"ui_on_text\";s:0:\"\";s:11:\"ui_off_text\";s:0:\"\";}','Button Toggle','banner_button_toggle','publish','closed','closed','','field_5ec563f3abc26','','','2020-05-26 21:41:37','2020-05-26 21:41:37','',36,'http://localhost:10008/?post_type=acf-field&p=44',7,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (45,1,'2020-05-26 21:41:37','2020-05-26 21:41:37','a:12:{s:4:\"type\";s:5:\"radio\";s:12:\"instructions\";s:34:\"How should this button be aligned?\";s:8:\"required\";i:0;s:17:\"conditional_logic\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"field\";s:19:\"field_5ec563f3abc26\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:1:\"1\";}}}s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:7:\"choices\";a:3:{s:4:\"left\";s:4:\"Left\";s:6:\"center\";s:6:\"Center\";s:5:\"right\";s:5:\"Right\";}s:10:\"allow_null\";i:0;s:12:\"other_choice\";i:0;s:13:\"default_value\";s:6:\"center\";s:6:\"layout\";s:8:\"vertical\";s:13:\"return_format\";s:5:\"value\";s:17:\"save_other_choice\";i:0;}','Button Alignment','banner_button_alignment','publish','closed','closed','','field_5ec5640cabc27','','','2020-05-26 21:41:37','2020-05-26 21:41:37','',36,'http://localhost:10008/?post_type=acf-field&p=45',8,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (46,1,'2020-05-26 21:41:37','2020-05-26 21:41:37','a:6:{s:4:\"type\";s:4:\"link\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"field\";s:19:\"field_5ec563f3abc26\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:1:\"1\";}}}s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:5:\"array\";}','Button','banner_button','publish','closed','closed','','field_5ec5642eabc28','','','2020-05-27 18:56:07','2020-05-27 18:56:07','',36,'http://localhost:10008/?post_type=acf-field&#038;p=46',10,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (47,1,'2020-05-26 21:41:37','2020-05-26 21:41:37','a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:9:\"post_type\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:4:\"post\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";}','Slider (Global)','slider-global','acf-disabled','closed','closed','','group_5ea73d9f934ca','','','2020-05-27 19:01:16','2020-05-27 19:01:16','',0,'http://localhost:10008/?p=47',20,'acf-field-group','',0);
INSERT INTO `wp_posts` VALUES (48,1,'2020-05-26 21:41:37','2020-05-26 21:41:37','a:10:{s:4:\"type\";s:7:\"wysiwyg\";s:12:\"instructions\";s:45:\"Enter the intro content above the slider here\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:4:\"tabs\";s:3:\"all\";s:7:\"toolbar\";s:4:\"full\";s:12:\"media_upload\";i:1;s:5:\"delay\";i:0;}','Intro Content','slider_intro_content','publish','closed','closed','','field_5ea73dacafcfb','','','2020-05-26 21:41:37','2020-05-26 21:41:37','',47,'http://localhost:10008/?post_type=acf-field&p=48',0,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (49,1,'2020-05-26 21:41:37','2020-05-26 21:41:37','a:10:{s:4:\"type\";s:8:\"repeater\";s:12:\"instructions\";s:17:\"Click \"Add Slide\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"collapsed\";s:0:\"\";s:3:\"min\";i:0;s:3:\"max\";i:0;s:6:\"layout\";s:3:\"row\";s:12:\"button_label\";s:9:\"Add Slide\";}','Slider','slider','publish','closed','closed','','field_5ea73dcfafcfc','','','2020-05-26 21:41:37','2020-05-26 21:41:37','',47,'http://localhost:10008/?post_type=acf-field&p=49',1,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (50,1,'2020-05-26 21:41:37','2020-05-26 21:41:37','a:10:{s:4:\"type\";s:7:\"wysiwyg\";s:12:\"instructions\";s:28:\"Enter the slide content here\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:4:\"tabs\";s:3:\"all\";s:7:\"toolbar\";s:4:\"full\";s:12:\"media_upload\";i:1;s:5:\"delay\";i:0;}','Content','content','publish','closed','closed','','field_5ea73e34afcfe','','','2020-05-26 21:41:37','2020-05-26 21:41:37','',49,'http://localhost:10008/?post_type=acf-field&p=50',0,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (51,1,'2020-05-26 21:41:37','2020-05-26 21:41:37','a:10:{s:4:\"type\";s:10:\"true_false\";s:12:\"instructions\";s:31:\"Display a button on this slide?\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:7:\"message\";s:0:\"\";s:13:\"default_value\";i:0;s:2:\"ui\";i:1;s:10:\"ui_on_text\";s:0:\"\";s:11:\"ui_off_text\";s:0:\"\";}','Button Toggle','button_toggle','publish','closed','closed','','field_5ea73e44afcff','','','2020-05-26 21:41:37','2020-05-26 21:41:37','',49,'http://localhost:10008/?post_type=acf-field&p=51',1,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (52,1,'2020-05-26 21:41:37','2020-05-26 21:41:37','a:6:{s:4:\"type\";s:4:\"link\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"field\";s:19:\"field_5ea73e44afcff\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:1:\"1\";}}}s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:5:\"array\";}','Button','button','publish','closed','closed','','field_5ea73e53afd00','','','2020-05-27 19:00:38','2020-05-27 19:00:38','',49,'http://localhost:10008/?post_type=acf-field&#038;p=52',3,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (53,1,'2020-05-26 21:41:37','2020-05-26 21:41:37','a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:9:\"post_type\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:4:\"post\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";}','Text/Image Split (Global)','text-image-split-global','acf-disabled','closed','closed','','group_5ea74e639f65c','','','2020-05-27 19:03:56','2020-05-27 19:03:56','',0,'http://localhost:10008/?p=53',21,'acf-field-group','',0);
INSERT INTO `wp_posts` VALUES (54,1,'2020-05-26 21:41:37','2020-05-26 21:41:37','a:12:{s:4:\"type\";s:5:\"radio\";s:12:\"instructions\";s:33:\"On which side does the image sit?\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:7:\"choices\";a:2:{s:4:\"left\";s:4:\"Left\";s:5:\"right\";s:5:\"Right\";}s:10:\"allow_null\";i:0;s:12:\"other_choice\";i:0;s:13:\"default_value\";s:0:\"\";s:6:\"layout\";s:8:\"vertical\";s:13:\"return_format\";s:5:\"value\";s:17:\"save_other_choice\";i:0;}','Layout Option','text_image_split_layout_option','publish','closed','closed','','field_5ea74e6eaf3c8','','','2020-05-26 21:41:37','2020-05-26 21:41:37','',53,'http://localhost:10008/?post_type=acf-field&p=54',0,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (55,1,'2020-05-26 21:41:37','2020-05-26 21:41:37','a:10:{s:4:\"type\";s:10:\"true_false\";s:12:\"instructions\";s:162:\"Is this a full-width section?<br><br>\r\n\r\nIf so, it will stretch to the edges of the screen.<br><br>\r\n\r\nIf not, it will stretch to the edges of the 12-column grid.\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:7:\"message\";s:0:\"\";s:13:\"default_value\";i:1;s:2:\"ui\";i:1;s:10:\"ui_on_text\";s:0:\"\";s:11:\"ui_off_text\";s:0:\"\";}','Width Option','text_image_split_width_option','publish','closed','closed','','field_5ea74e91af3c9','','','2020-05-26 21:41:37','2020-05-26 21:41:37','',53,'http://localhost:10008/?post_type=acf-field&p=55',1,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (56,1,'2020-05-26 21:41:37','2020-05-26 21:41:37','a:10:{s:4:\"type\";s:10:\"true_false\";s:12:\"instructions\";s:40:\"Add margin above and below this section?\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:7:\"message\";s:0:\"\";s:13:\"default_value\";i:0;s:2:\"ui\";i:1;s:10:\"ui_on_text\";s:0:\"\";s:11:\"ui_off_text\";s:0:\"\";}','Margin Option','text_image_split_margin_option','publish','closed','closed','','field_5ea74ed9af3ca','','','2020-05-26 21:41:37','2020-05-26 21:41:37','',53,'http://localhost:10008/?post_type=acf-field&p=56',2,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (57,1,'2020-05-26 21:41:37','2020-05-26 21:41:37','a:12:{s:4:\"type\";s:5:\"radio\";s:12:\"instructions\";s:36:\"What should the background color be?\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:7:\"choices\";a:2:{s:7:\"#d9d9d9\";s:10:\"Light Gray\";s:7:\"#ffffff\";s:5:\"White\";}s:10:\"allow_null\";i:0;s:12:\"other_choice\";i:0;s:13:\"default_value\";s:0:\"\";s:6:\"layout\";s:8:\"vertical\";s:13:\"return_format\";s:5:\"value\";s:17:\"save_other_choice\";i:0;}','Background Color','text_image_split_background_color','publish','closed','closed','','field_5eb43094542c6','','','2020-05-26 21:41:37','2020-05-26 21:41:37','',53,'http://localhost:10008/?post_type=acf-field&p=57',3,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (58,1,'2020-05-26 21:41:37','2020-05-26 21:41:37','a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:62:\"Upload the image for this section here (at least 950 x 500 px)\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:2:\"id\";s:12:\"preview_size\";s:9:\"thumbnail\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}','Image','text_image_split_image','publish','closed','closed','','field_5ea74f04af3cb','','','2020-05-26 21:41:37','2020-05-26 21:41:37','',53,'http://localhost:10008/?post_type=acf-field&p=58',4,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (59,1,'2020-05-26 21:41:37','2020-05-26 21:41:37','a:10:{s:4:\"type\";s:7:\"wysiwyg\";s:12:\"instructions\";s:44:\"Enter the text content for this section here\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:4:\"tabs\";s:3:\"all\";s:7:\"toolbar\";s:4:\"full\";s:12:\"media_upload\";i:1;s:5:\"delay\";i:0;}','Content','text_image_split_content','publish','closed','closed','','field_5ea74f2caf3cc','','','2020-05-26 21:41:37','2020-05-26 21:41:37','',53,'http://localhost:10008/?post_type=acf-field&p=59',5,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (60,1,'2020-05-26 21:41:37','2020-05-26 21:41:37','a:10:{s:4:\"type\";s:10:\"true_false\";s:12:\"instructions\";s:22:\"Display a button here?\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:7:\"message\";s:0:\"\";s:13:\"default_value\";i:0;s:2:\"ui\";i:1;s:10:\"ui_on_text\";s:0:\"\";s:11:\"ui_off_text\";s:0:\"\";}','Button Toggle','text_image_split_button_toggle','publish','closed','closed','','field_5ea74f40af3cd','','','2020-05-26 21:41:37','2020-05-26 21:41:37','',53,'http://localhost:10008/?post_type=acf-field&p=60',6,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (61,1,'2020-05-26 21:41:37','2020-05-26 21:41:37','a:12:{s:4:\"type\";s:5:\"radio\";s:12:\"instructions\";s:34:\"How should this button be aligned?\";s:8:\"required\";i:0;s:17:\"conditional_logic\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"field\";s:19:\"field_5ea74f40af3cd\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:1:\"1\";}}}s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:7:\"choices\";a:3:{s:4:\"left\";s:4:\"Left\";s:6:\"center\";s:6:\"Center\";s:5:\"right\";s:5:\"Right\";}s:10:\"allow_null\";i:0;s:12:\"other_choice\";i:0;s:13:\"default_value\";s:4:\"left\";s:6:\"layout\";s:8:\"vertical\";s:13:\"return_format\";s:5:\"value\";s:17:\"save_other_choice\";i:0;}','Button Alignment','text_image_split_button_alignment','publish','closed','closed','','field_5ea74f50af3ce','','','2020-05-26 21:41:37','2020-05-26 21:41:37','',53,'http://localhost:10008/?post_type=acf-field&p=61',7,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (62,1,'2020-05-26 21:41:37','2020-05-26 21:41:37','a:6:{s:4:\"type\";s:4:\"link\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"field\";s:19:\"field_5ea74f40af3cd\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:1:\"1\";}}}s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:5:\"array\";}','Button','text_image_split_button','publish','closed','closed','','field_5ea74f76af3cf','','','2020-05-27 19:03:02','2020-05-27 19:03:02','',53,'http://localhost:10008/?post_type=acf-field&#038;p=62',9,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (63,1,'2020-05-26 21:41:37','2020-05-26 21:41:37','a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:9:\"post_type\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:4:\"post\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";}','3-Column Grid (Global)','3-column-grid-global','acf-disabled','closed','closed','','group_5ea7568ed7f84','','','2020-05-27 19:05:26','2020-05-27 19:05:26','',0,'http://localhost:10008/?p=63',22,'acf-field-group','',0);
INSERT INTO `wp_posts` VALUES (64,1,'2020-05-26 21:41:37','2020-05-26 21:41:37','a:10:{s:4:\"type\";s:7:\"wysiwyg\";s:12:\"instructions\";s:43:\"Enter the intro content above the grid here\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:4:\"tabs\";s:3:\"all\";s:7:\"toolbar\";s:4:\"full\";s:12:\"media_upload\";i:1;s:5:\"delay\";i:0;}','Intro Content','3_column_grid_intro_content','publish','closed','closed','','field_5ea7569d9822d','','','2020-05-26 21:41:37','2020-05-26 21:41:37','',63,'http://localhost:10008/?post_type=acf-field&p=64',0,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (65,1,'2020-05-26 21:41:37','2020-05-26 21:41:37','a:10:{s:4:\"type\";s:8:\"repeater\";s:12:\"instructions\";s:18:\"Click \"Add Column\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"collapsed\";s:0:\"\";s:3:\"min\";i:0;s:3:\"max\";i:0;s:6:\"layout\";s:3:\"row\";s:12:\"button_label\";s:10:\"Add Column\";}','Grid','3_column_grid','publish','closed','closed','','field_5ea756b19822e','','','2020-05-26 21:41:37','2020-05-26 21:41:37','',63,'http://localhost:10008/?post_type=acf-field&p=65',1,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (66,1,'2020-05-26 21:41:37','2020-05-26 21:41:37','a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:45:\"Upload the image here (at least 400 x 250 px)\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:2:\"id\";s:12:\"preview_size\";s:9:\"thumbnail\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}','Image','image','publish','closed','closed','','field_5ea7573c98232','','','2020-05-26 21:41:37','2020-05-26 21:41:37','',65,'http://localhost:10008/?post_type=acf-field&p=66',0,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (67,1,'2020-05-26 21:41:37','2020-05-26 21:41:37','a:10:{s:4:\"type\";s:7:\"wysiwyg\";s:12:\"instructions\";s:43:\"Enter the text content for this column here\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:4:\"tabs\";s:3:\"all\";s:7:\"toolbar\";s:4:\"full\";s:12:\"media_upload\";i:1;s:5:\"delay\";i:0;}','Content','content','publish','closed','closed','','field_5ea757029822f','','','2020-05-26 21:41:37','2020-05-26 21:41:37','',65,'http://localhost:10008/?post_type=acf-field&p=67',1,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (68,1,'2020-05-26 21:41:37','2020-05-26 21:41:37','a:10:{s:4:\"type\";s:10:\"true_false\";s:12:\"instructions\";s:22:\"Display a button here?\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:7:\"message\";s:0:\"\";s:13:\"default_value\";i:0;s:2:\"ui\";i:1;s:10:\"ui_on_text\";s:0:\"\";s:11:\"ui_off_text\";s:0:\"\";}','Button Toggle','button_toggle','publish','closed','closed','','field_5ea7571198230','','','2020-05-26 21:41:37','2020-05-26 21:41:37','',65,'http://localhost:10008/?post_type=acf-field&p=68',2,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (69,1,'2020-05-26 21:41:37','2020-05-26 21:41:37','a:6:{s:4:\"type\";s:4:\"link\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"field\";s:19:\"field_5ea7571198230\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:1:\"1\";}}}s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:5:\"array\";}','Button','button','publish','closed','closed','','field_5ea7572498231','','','2020-05-27 19:04:52','2020-05-27 19:04:52','',65,'http://localhost:10008/?post_type=acf-field&#038;p=69',4,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (70,1,'2020-05-26 21:41:37','2020-05-26 21:41:37','a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:9:\"post_type\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:4:\"post\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";}','Newsletter Signup (Global)','newsletter-signup-global','acf-disabled','closed','closed','','group_5ea88dde7cfa1','','','2020-05-26 21:41:37','2020-05-26 21:41:37','',0,'http://localhost:10008/?p=70',24,'acf-field-group','',0);
INSERT INTO `wp_posts` VALUES (71,1,'2020-05-26 21:41:37','2020-05-26 21:41:37','a:10:{s:4:\"type\";s:7:\"wysiwyg\";s:12:\"instructions\";s:28:\"Enter the intro content here\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:4:\"tabs\";s:3:\"all\";s:7:\"toolbar\";s:4:\"full\";s:12:\"media_upload\";i:1;s:5:\"delay\";i:0;}','Intro','newsletter_intro','publish','closed','closed','','field_5ea88defcb7c8','','','2020-05-26 21:41:37','2020-05-26 21:41:37','',70,'http://localhost:10008/?post_type=acf-field&p=71',0,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (72,1,'2020-05-26 21:41:37','2020-05-26 21:41:37','a:8:{s:4:\"type\";s:5:\"forms\";s:12:\"instructions\";s:31:\"Choose the form to display here\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:11:\"post_object\";s:10:\"allow_null\";i:0;s:8:\"multiple\";i:0;}','Form','newsletter_form','publish','closed','closed','','field_5ea88e375e1a6','','','2020-05-26 21:41:37','2020-05-26 21:41:37','',70,'http://localhost:10008/?post_type=acf-field&p=72',1,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (73,1,'2020-05-26 22:01:39','2020-05-26 22:01:39','a:7:{s:8:\"location\";a:1:{i:0;a:2:{i:0;a:3:{s:5:\"param\";s:13:\"page_template\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:7:\"default\";}i:1;a:3:{s:5:\"param\";s:9:\"page_type\";s:8:\"operator\";s:2:\"!=\";s:5:\"value\";s:10:\"posts_page\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";a:1:{i:0;s:11:\"the_content\";}s:11:\"description\";s:38:\"Custom fields for the default template\";}','Default Template','default-template','publish','closed','closed','','group_5ecd9179ac374','','','2020-05-27 18:26:57','2020-05-27 18:26:57','',0,'http://localhost:10008/?post_type=acf-field-group&#038;p=73',1,'acf-field-group','',0);
INSERT INTO `wp_posts` VALUES (74,1,'2020-05-26 22:01:39','2020-05-26 22:01:39','a:7:{s:4:\"type\";s:3:\"tab\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"placement\";s:3:\"top\";s:8:\"endpoint\";i:0;}','Hero','hero','publish','closed','closed','','field_5ecd919247d48','','','2020-05-26 22:01:39','2020-05-26 22:01:39','',73,'http://localhost:10008/?post_type=acf-field&p=74',0,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (75,1,'2020-05-26 22:01:39','2020-05-26 22:01:39','a:10:{s:4:\"type\";s:5:\"clone\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:5:\"clone\";a:1:{i:0;s:19:\"group_5ea714edc7d39\";}s:7:\"display\";s:8:\"seamless\";s:6:\"layout\";s:5:\"block\";s:12:\"prefix_label\";i:0;s:11:\"prefix_name\";i:0;}','Default Hero','default_hero','publish','closed','closed','','field_5ecd919847d49','','','2020-05-26 22:01:39','2020-05-26 22:01:39','',73,'http://localhost:10008/?post_type=acf-field&p=75',1,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (76,1,'2020-05-26 22:01:39','2020-05-26 22:01:39','a:7:{s:4:\"type\";s:3:\"tab\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"placement\";s:3:\"top\";s:8:\"endpoint\";i:0;}','Page Sections','page_sections','publish','closed','closed','','field_5ecd91a447d4a','','','2020-05-26 22:01:39','2020-05-26 22:01:39','',73,'http://localhost:10008/?post_type=acf-field&p=76',2,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (77,1,'2020-05-26 22:01:39','2020-05-26 22:01:39','a:10:{s:4:\"type\";s:5:\"clone\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:5:\"clone\";a:1:{i:0;s:19:\"group_5ea7226568aaf\";}s:7:\"display\";s:8:\"seamless\";s:6:\"layout\";s:5:\"block\";s:12:\"prefix_label\";i:0;s:11:\"prefix_name\";i:0;}','Default Sections','default_sections','publish','closed','closed','','field_5ecd91ab47d4b','','','2020-05-26 22:03:02','2020-05-26 22:03:02','',73,'http://localhost:10008/?post_type=acf-field&#038;p=77',3,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (78,1,'2020-05-26 22:07:44','2020-05-26 22:07:44','a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:12:\"options_page\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:24:\"acf-options-site-options\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";}','Site Options','site-options','publish','closed','closed','','group_5ecd92384b0a6','','','2020-05-27 18:26:57','2020-05-27 18:26:57','',0,'http://localhost:10008/?post_type=acf-field-group&#038;p=78',2,'acf-field-group','',0);
INSERT INTO `wp_posts` VALUES (79,1,'2020-05-26 22:07:44','2020-05-26 22:07:44','a:7:{s:4:\"type\";s:3:\"tab\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"placement\";s:3:\"top\";s:8:\"endpoint\";i:0;}','Header','header','publish','closed','closed','','field_5ecd92888321c','','','2020-05-26 22:07:44','2020-05-26 22:07:44','',78,'http://localhost:10008/?post_type=acf-field&p=79',0,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (80,1,'2020-05-26 22:07:44','2020-05-26 22:07:44','a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:80:\"Upload the header logo here (either an svg or a png that\'s at least 300 x 75 px)\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:2:\"id\";s:12:\"preview_size\";s:9:\"thumbnail\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}','Header Logo','header_logo','publish','closed','closed','','field_5ecd923d8321b','','','2020-05-26 22:07:44','2020-05-26 22:07:44','',78,'http://localhost:10008/?post_type=acf-field&p=80',1,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (81,1,'2020-05-26 22:07:44','2020-05-26 22:07:44','a:7:{s:4:\"type\";s:3:\"tab\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"placement\";s:3:\"top\";s:8:\"endpoint\";i:0;}','Footer','footer','publish','closed','closed','','field_5ecd928e8321d','','','2020-05-26 22:07:44','2020-05-26 22:07:44','',78,'http://localhost:10008/?post_type=acf-field&p=81',2,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (82,1,'2020-05-26 22:07:44','2020-05-26 22:07:44','a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:80:\"Upload the header logo here (either an svg or a png that\'s at least 300 x 75 px)\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:2:\"id\";s:12:\"preview_size\";s:9:\"thumbnail\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}','Footer Logo','footer_logo','publish','closed','closed','','field_5ecd92958321e','','','2020-05-26 22:07:44','2020-05-26 22:07:44','',78,'http://localhost:10008/?post_type=acf-field&p=82',3,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (83,1,'2020-05-26 22:07:44','2020-05-26 22:07:44','a:7:{s:4:\"type\";s:3:\"tab\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"placement\";s:3:\"top\";s:8:\"endpoint\";i:0;}','404','404','publish','closed','closed','','field_5ecd92c28321f','','','2020-05-27 18:21:44','2020-05-27 18:21:44','',78,'http://localhost:10008/?post_type=acf-field&#038;p=83',4,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (84,1,'2020-05-26 22:07:44','2020-05-26 22:07:44','a:10:{s:4:\"type\";s:7:\"wysiwyg\";s:12:\"instructions\";s:31:\"Enter the 404 page content here\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:185:\"<h1 style=\"text-align: center\">404</h1>\r\n\r\n<h3 style=\"text-align: center\">Page Not Found</h3>\r\n\r\n<p style=\"text-align: center\">Looks like the page you are looking for doesn\'t exist.</p>\";s:4:\"tabs\";s:3:\"all\";s:7:\"toolbar\";s:4:\"full\";s:12:\"media_upload\";i:1;s:5:\"delay\";i:0;}','404 Content','404_content','publish','closed','closed','','field_5ecd92c683220','','','2020-05-27 18:21:44','2020-05-27 18:21:44','',78,'http://localhost:10008/?post_type=acf-field&#038;p=84',5,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (85,1,'2020-05-26 22:49:37','2020-05-26 22:49:37','','Styleguide','','publish','closed','closed','','styleguide','','','2020-05-27 16:57:32','2020-05-27 16:57:32','',0,'http://localhost:10008/?page_id=85',0,'page','',0);
INSERT INTO `wp_posts` VALUES (86,1,'2020-05-26 22:49:37','2020-05-26 22:49:37','','Styleguide','','inherit','closed','closed','','85-revision-v1','','','2020-05-26 22:49:37','2020-05-26 22:49:37','',85,'http://localhost:10008/85-revision-v1/',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (87,1,'2020-05-26 22:49:57','2020-05-26 22:49:57','','Blog','','publish','closed','closed','','blog','','','2020-05-27 18:21:24','2020-05-27 18:21:24','',0,'http://localhost:10008/?page_id=87',0,'page','',0);
INSERT INTO `wp_posts` VALUES (88,1,'2020-05-26 22:49:57','2020-05-26 22:49:57','','Blog','','inherit','closed','closed','','87-revision-v1','','','2020-05-26 22:49:57','2020-05-26 22:49:57','',87,'http://localhost:10008/87-revision-v1/',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (89,1,'2020-05-27 17:04:13','2020-05-27 17:04:13','<!-- wp:paragraph -->\r\n<p>This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:quote -->\r\n<blockquote class=\"wp-block-quote\">\r\n<p>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like piña coladas. (And gettin\' caught in the rain.)</p>\r\n</blockquote>\r\n<!-- /wp:quote -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>...or something like this:</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:quote -->\r\n<blockquote class=\"wp-block-quote\">\r\n<p>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</p>\r\n</blockquote>\r\n<!-- /wp:quote -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>As a new WordPress user, you should go to <a href=\"http://localhost:10008/wp-admin/\">your dashboard</a> to delete this page and create new pages for your content. Have fun!</p>\r\n<!-- /wp:paragraph -->','Sample Page','','inherit','closed','closed','','2-revision-v1','','','2020-05-27 17:04:13','2020-05-27 17:04:13','',2,'http://localhost:10008/2-revision-v1/',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (90,1,'2020-05-27 17:48:45','2020-05-27 17:48:45','a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:9:\"page_type\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:10:\"posts_page\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";}','Blog','blog','publish','closed','closed','','group_5728e3bc743d7','','','2020-05-27 18:26:57','2020-05-27 18:26:57','',0,'http://localhost:10008/?p=90',3,'acf-field-group','',0);
INSERT INTO `wp_posts` VALUES (92,1,'2020-05-27 17:48:45','2020-05-27 17:48:45','a:10:{s:4:\"type\";s:7:\"wysiwyg\";s:12:\"instructions\";s:41:\"Enter the intro content for the blog here\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:110:\"<h1 style=\"text-align: center\">Blog</h1>\r\n\r\n<p style=\"text-align: center\">Check out our latest posts below</p>\";s:4:\"tabs\";s:3:\"all\";s:7:\"toolbar\";s:4:\"full\";s:12:\"media_upload\";i:1;s:5:\"delay\";i:0;}','Intro Text','blog_intro_text','publish','closed','closed','','field_5728e4d16b348','','','2020-05-27 18:20:38','2020-05-27 18:20:38','',90,'http://localhost:10008/?post_type=acf-field&#038;p=92',1,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (93,1,'2020-05-27 17:51:29','2020-05-27 17:51:29','Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.','Post 1','','publish','open','open','','post-1','','','2020-05-27 17:51:29','2020-05-27 17:51:29','',0,'http://localhost:10008/?p=93',0,'post','',0);
INSERT INTO `wp_posts` VALUES (94,1,'2020-05-27 17:51:29','2020-05-27 17:51:29','Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.','Post 1','','inherit','closed','closed','','93-revision-v1','','','2020-05-27 17:51:29','2020-05-27 17:51:29','',93,'http://localhost:10008/93-revision-v1/',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (95,1,'2020-05-27 17:51:47','2020-05-27 17:51:47','Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.','Post 2','','publish','open','open','','post-2','','','2020-05-27 18:09:14','2020-05-27 18:09:14','',0,'http://localhost:10008/?p=95',0,'post','',0);
INSERT INTO `wp_posts` VALUES (96,1,'2020-05-27 17:51:47','2020-05-27 17:51:47','Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.','Post 2','','inherit','closed','closed','','95-revision-v1','','','2020-05-27 17:51:47','2020-05-27 17:51:47','',95,'http://localhost:10008/95-revision-v1/',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (99,1,'2020-05-27 18:20:38','2020-05-27 18:20:38','a:7:{s:4:\"type\";s:3:\"tab\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"placement\";s:3:\"top\";s:8:\"endpoint\";i:0;}','Blog Page Intro','blog_page_intro','publish','closed','closed','','field_5eceaf1e1eab3','','','2020-05-27 18:20:38','2020-05-27 18:20:38','',90,'http://localhost:10008/?post_type=acf-field&p=99',0,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (100,1,'2020-05-27 18:20:38','2020-05-27 18:20:38','a:7:{s:4:\"type\";s:3:\"tab\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"placement\";s:3:\"top\";s:8:\"endpoint\";i:0;}','Post List','post_list','publish','closed','closed','','field_5eceaf2a1eab4','','','2020-05-27 18:20:38','2020-05-27 18:20:38','',90,'http://localhost:10008/?post_type=acf-field&p=100',2,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (101,1,'2020-05-27 18:20:38','2020-05-27 18:20:38','a:12:{s:4:\"type\";s:8:\"checkbox\";s:12:\"instructions\";s:58:\"Choose what meta information to display for each blog post\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:7:\"choices\";a:4:{s:6:\"author\";s:6:\"Author\";s:4:\"date\";s:4:\"Date\";s:10:\"categories\";s:10:\"Categories\";s:4:\"tags\";s:4:\"Tags\";}s:12:\"allow_custom\";i:0;s:13:\"default_value\";b:0;s:6:\"layout\";s:8:\"vertical\";s:6:\"toggle\";i:0;s:13:\"return_format\";s:5:\"value\";s:11:\"save_custom\";i:0;}','Post Meta Data','post_meta_data','publish','closed','closed','','field_5eceaf331eab5','','','2020-05-27 18:20:38','2020-05-27 18:20:38','',90,'http://localhost:10008/?post_type=acf-field&p=101',3,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (102,1,'2020-05-27 18:21:24','2020-05-27 18:21:24','','Blog','','inherit','closed','closed','','87-revision-v1','','','2020-05-27 18:21:24','2020-05-27 18:21:24','',87,'http://localhost:10008/87-revision-v1/',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (108,1,'2020-05-27 18:51:11','2020-05-27 18:51:11','a:12:{s:4:\"type\";s:5:\"radio\";s:12:\"instructions\";s:43:\"Choose the color class for this button here\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:7:\"choices\";a:6:{s:7:\"primary\";s:7:\"Primary\";s:13:\"primary-ghost\";s:15:\"Primary (Ghost)\";s:9:\"secondary\";s:9:\"Secondary\";s:15:\"secondary-ghost\";s:17:\"Secondary (Ghost)\";s:5:\"white\";s:5:\"White\";s:11:\"white-ghost\";s:13:\"White (Ghost)\";}s:10:\"allow_null\";i:0;s:12:\"other_choice\";i:0;s:13:\"default_value\";s:7:\"primary\";s:6:\"layout\";s:8:\"vertical\";s:13:\"return_format\";s:5:\"value\";s:17:\"save_other_choice\";i:0;}','Button Class','button_class','publish','closed','closed','','field_5eceb63abcc3a','','','2020-05-27 18:51:11','2020-05-27 18:51:11','',33,'http://localhost:10008/?post_type=acf-field&p=108',0,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (109,1,'2020-05-27 18:52:19','2020-05-27 18:52:19','<!-- wp:paragraph -->\r\n<p>This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:quote -->\r\n<blockquote class=\"wp-block-quote\">\r\n<p>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like piña coladas. (And gettin\' caught in the rain.)</p>\r\n</blockquote>\r\n<!-- /wp:quote -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>...or something like this:</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:quote -->\r\n<blockquote class=\"wp-block-quote\">\r\n<p>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</p>\r\n</blockquote>\r\n<!-- /wp:quote -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>As a new WordPress user, you should go to <a href=\"http://localhost:10008/wp-admin/\">your dashboard</a> to delete this page and create new pages for your content. Have fun!</p>\r\n<!-- /wp:paragraph -->','Sample Page','','inherit','closed','closed','','2-revision-v1','','','2020-05-27 18:52:19','2020-05-27 18:52:19','',2,'http://localhost:10008/2-revision-v1/',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (110,1,'2020-05-27 18:53:26','2020-05-27 18:53:26','a:12:{s:4:\"type\";s:5:\"radio\";s:12:\"instructions\";s:43:\"Choose the color class for this button here\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:7:\"choices\";a:6:{s:7:\"primary\";s:7:\"Primary\";s:13:\"primary-ghost\";s:15:\"Primary (Ghost)\";s:9:\"secondary\";s:9:\"Secondary\";s:15:\"secondary-ghost\";s:17:\"Secondary (Ghost)\";s:5:\"white\";s:5:\"White\";s:11:\"white-ghost\";s:13:\"White (Ghost)\";}s:10:\"allow_null\";i:0;s:12:\"other_choice\";i:0;s:13:\"default_value\";s:7:\"primary\";s:6:\"layout\";s:8:\"vertical\";s:13:\"return_format\";s:5:\"value\";s:17:\"save_other_choice\";i:0;}','Button Class','button_class','publish','closed','closed','','field_5eceb70d0e42d','','','2020-05-27 18:53:26','2020-05-27 18:53:26','',27,'http://localhost:10008/?post_type=acf-field&p=110',0,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (111,1,'2020-05-27 18:54:23','2020-05-27 18:54:23','<!-- wp:paragraph -->\r\n<p>This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:quote -->\r\n<blockquote class=\"wp-block-quote\">\r\n<p>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like piña coladas. (And gettin\' caught in the rain.)</p>\r\n</blockquote>\r\n<!-- /wp:quote -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>...or something like this:</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:quote -->\r\n<blockquote class=\"wp-block-quote\">\r\n<p>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</p>\r\n</blockquote>\r\n<!-- /wp:quote -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>As a new WordPress user, you should go to <a href=\"http://localhost:10008/wp-admin/\">your dashboard</a> to delete this page and create new pages for your content. Have fun!</p>\r\n<!-- /wp:paragraph -->','Sample Page','','inherit','closed','closed','','2-revision-v1','','','2020-05-27 18:54:23','2020-05-27 18:54:23','',2,'http://localhost:10008/2-revision-v1/',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (112,1,'2020-05-27 18:54:34','2020-05-27 18:54:34','<!-- wp:paragraph -->\r\n<p>This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:quote -->\r\n<blockquote class=\"wp-block-quote\">\r\n<p>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like piña coladas. (And gettin\' caught in the rain.)</p>\r\n</blockquote>\r\n<!-- /wp:quote -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>...or something like this:</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:quote -->\r\n<blockquote class=\"wp-block-quote\">\r\n<p>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</p>\r\n</blockquote>\r\n<!-- /wp:quote -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>As a new WordPress user, you should go to <a href=\"http://localhost:10008/wp-admin/\">your dashboard</a> to delete this page and create new pages for your content. Have fun!</p>\r\n<!-- /wp:paragraph -->','Sample Page','','inherit','closed','closed','','2-revision-v1','','','2020-05-27 18:54:34','2020-05-27 18:54:34','',2,'http://localhost:10008/2-revision-v1/',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (113,1,'2020-05-27 18:56:07','2020-05-27 18:56:07','a:12:{s:4:\"type\";s:5:\"radio\";s:12:\"instructions\";s:43:\"Choose the color class for this button here\";s:8:\"required\";i:0;s:17:\"conditional_logic\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"field\";s:19:\"field_5ec563f3abc26\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:1:\"1\";}}}s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:7:\"choices\";a:6:{s:7:\"primary\";s:7:\"Primary\";s:13:\"primary-ghost\";s:15:\"Primary (Ghost)\";s:9:\"secondary\";s:9:\"Secondary\";s:15:\"secondary-ghost\";s:17:\"Secondary (Ghost)\";s:5:\"white\";s:5:\"White\";s:11:\"white-ghost\";s:13:\"White (Ghost)\";}s:10:\"allow_null\";i:0;s:12:\"other_choice\";i:0;s:13:\"default_value\";s:7:\"primary\";s:6:\"layout\";s:8:\"vertical\";s:13:\"return_format\";s:5:\"value\";s:17:\"save_other_choice\";i:0;}','Button Class','banner_button_class','publish','closed','closed','','field_5eceb79de42a0','','','2020-05-27 18:56:07','2020-05-27 18:56:07','',36,'http://localhost:10008/?post_type=acf-field&p=113',9,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (114,1,'2020-05-27 18:59:08','2020-05-27 18:59:08','<!-- wp:paragraph -->\r\n<p>This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:quote -->\r\n<blockquote class=\"wp-block-quote\">\r\n<p>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like piña coladas. (And gettin\' caught in the rain.)</p>\r\n</blockquote>\r\n<!-- /wp:quote -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>...or something like this:</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:quote -->\r\n<blockquote class=\"wp-block-quote\">\r\n<p>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</p>\r\n</blockquote>\r\n<!-- /wp:quote -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>As a new WordPress user, you should go to <a href=\"http://localhost:10008/wp-admin/\">your dashboard</a> to delete this page and create new pages for your content. Have fun!</p>\r\n<!-- /wp:paragraph -->','Sample Page','','inherit','closed','closed','','2-revision-v1','','','2020-05-27 18:59:08','2020-05-27 18:59:08','',2,'http://localhost:10008/2-revision-v1/',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (115,1,'2020-05-27 19:00:38','2020-05-27 19:00:38','a:12:{s:4:\"type\";s:5:\"radio\";s:12:\"instructions\";s:43:\"Choose the color class for this button here\";s:8:\"required\";i:0;s:17:\"conditional_logic\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"field\";s:19:\"field_5ea73e44afcff\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:1:\"1\";}}}s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:7:\"choices\";a:6:{s:7:\"primary\";s:7:\"Primary\";s:13:\"primary-ghost\";s:15:\"Primary (Ghost)\";s:9:\"secondary\";s:9:\"Secondary\";s:15:\"secondary-ghost\";s:17:\"Secondary (Ghost)\";s:5:\"white\";s:5:\"White\";s:11:\"white-ghost\";s:13:\"White (Ghost)\";}s:10:\"allow_null\";i:0;s:12:\"other_choice\";i:0;s:13:\"default_value\";s:7:\"primary\";s:6:\"layout\";s:8:\"vertical\";s:13:\"return_format\";s:5:\"value\";s:17:\"save_other_choice\";i:0;}','Button Class','button_class','publish','closed','closed','','field_5eceb8b223dd1','','','2020-05-27 19:00:38','2020-05-27 19:00:38','',49,'http://localhost:10008/?post_type=acf-field&p=115',2,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (116,1,'2020-05-27 19:03:02','2020-05-27 19:03:02','a:12:{s:4:\"type\";s:5:\"radio\";s:12:\"instructions\";s:43:\"Choose the color class for this button here\";s:8:\"required\";i:0;s:17:\"conditional_logic\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"field\";s:19:\"field_5ea74f40af3cd\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:1:\"1\";}}}s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:7:\"choices\";a:6:{s:7:\"primary\";s:7:\"Primary\";s:13:\"primary-ghost\";s:15:\"Primary (Ghost)\";s:9:\"secondary\";s:9:\"Secondary\";s:15:\"secondary-ghost\";s:17:\"Secondary (Ghost)\";s:5:\"white\";s:5:\"White\";s:11:\"white-ghost\";s:13:\"White (Ghost)\";}s:10:\"allow_null\";i:0;s:12:\"other_choice\";i:0;s:13:\"default_value\";s:7:\"primary\";s:6:\"layout\";s:8:\"vertical\";s:13:\"return_format\";s:5:\"value\";s:17:\"save_other_choice\";i:0;}','Button Class','text_image_split_button_class','publish','closed','closed','','field_5eceb93bdf880','','','2020-05-27 19:03:02','2020-05-27 19:03:02','',53,'http://localhost:10008/?post_type=acf-field&p=116',8,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (117,1,'2020-05-27 19:04:52','2020-05-27 19:04:52','a:12:{s:4:\"type\";s:5:\"radio\";s:12:\"instructions\";s:43:\"Choose the color class for this button here\";s:8:\"required\";i:0;s:17:\"conditional_logic\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"field\";s:19:\"field_5ea7571198230\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:1:\"1\";}}}s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:7:\"choices\";a:6:{s:7:\"primary\";s:7:\"Primary\";s:13:\"primary-ghost\";s:15:\"Primary (Ghost)\";s:9:\"secondary\";s:9:\"Secondary\";s:15:\"secondary-ghost\";s:17:\"Secondary (Ghost)\";s:5:\"white\";s:5:\"White\";s:11:\"white-ghost\";s:13:\"White (Ghost)\";}s:10:\"allow_null\";i:0;s:12:\"other_choice\";i:0;s:13:\"default_value\";s:7:\"primary\";s:6:\"layout\";s:8:\"vertical\";s:13:\"return_format\";s:5:\"value\";s:17:\"save_other_choice\";i:0;}','Button Class','button_class','publish','closed','closed','','field_5eceb9b6b907f','','','2020-05-27 19:04:52','2020-05-27 19:04:52','',65,'http://localhost:10008/?post_type=acf-field&p=117',3,'acf-field','',0);
INSERT INTO `wp_posts` VALUES (118,1,'2020-05-27 19:06:07','2020-05-27 19:06:07','<!-- wp:paragraph -->\r\n<p>This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:quote -->\r\n<blockquote class=\"wp-block-quote\">\r\n<p>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like piña coladas. (And gettin\' caught in the rain.)</p>\r\n</blockquote>\r\n<!-- /wp:quote -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>...or something like this:</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:quote -->\r\n<blockquote class=\"wp-block-quote\">\r\n<p>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</p>\r\n</blockquote>\r\n<!-- /wp:quote -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>As a new WordPress user, you should go to <a href=\"http://localhost:10008/wp-admin/\">your dashboard</a> to delete this page and create new pages for your content. Have fun!</p>\r\n<!-- /wp:paragraph -->','Sample Page','','inherit','closed','closed','','2-revision-v1','','','2020-05-27 19:06:07','2020-05-27 19:06:07','',2,'http://localhost:10008/2-revision-v1/',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (119,1,'2020-05-27 19:17:18','2020-05-27 19:17:18',' ','','','publish','closed','closed','','119','','','2020-05-27 19:17:18','2020-05-27 19:17:18','',0,'http://localhost:10008/?p=119',1,'nav_menu_item','',0);
INSERT INTO `wp_posts` VALUES (120,1,'2020-05-27 19:17:18','2020-05-27 19:17:18',' ','','','publish','closed','closed','','120','','','2020-05-27 19:17:18','2020-05-27 19:17:18','',0,'http://localhost:10008/?p=120',2,'nav_menu_item','',0);
INSERT INTO `wp_posts` VALUES (121,1,'2020-05-27 19:17:18','2020-05-27 19:17:18',' ','','','publish','closed','closed','','121','','','2020-05-27 19:17:18','2020-05-27 19:17:18','',0,'http://localhost:10008/?p=121',3,'nav_menu_item','',0);
INSERT INTO `wp_posts` VALUES (122,1,'2020-05-27 19:18:00','2020-05-27 19:18:00',' ','','','publish','closed','closed','','122','','','2020-05-27 19:25:58','2020-05-27 19:25:58','',0,'http://localhost:10008/?p=122',1,'nav_menu_item','',0);
INSERT INTO `wp_posts` VALUES (123,1,'2020-05-27 19:18:00','2020-05-27 19:18:00',' ','','','publish','closed','closed','','123','','','2020-05-27 19:25:58','2020-05-27 19:25:58','',0,'http://localhost:10008/?p=123',4,'nav_menu_item','',0);
INSERT INTO `wp_posts` VALUES (124,1,'2020-05-27 19:18:00','2020-05-27 19:18:00',' ','','','publish','closed','closed','','124','','','2020-05-27 19:25:58','2020-05-27 19:25:58','',0,'http://localhost:10008/?p=124',8,'nav_menu_item','',0);
INSERT INTO `wp_posts` VALUES (125,1,'2020-05-27 19:25:58','2020-05-27 19:25:58','','Sample Link','','publish','closed','closed','','sample-link','','','2020-05-27 19:25:58','2020-05-27 19:25:58','',0,'http://localhost:10008/?p=125',2,'nav_menu_item','',0);
INSERT INTO `wp_posts` VALUES (126,1,'2020-05-27 19:25:58','2020-05-27 19:25:58','','Sample Link','','publish','closed','closed','','sample-link-2','','','2020-05-27 19:25:58','2020-05-27 19:25:58','',0,'http://localhost:10008/?p=126',3,'nav_menu_item','',0);
INSERT INTO `wp_posts` VALUES (127,1,'2020-05-27 19:25:58','2020-05-27 19:25:58','','Sample Link','','publish','closed','closed','','sample-link-3','','','2020-05-27 19:25:58','2020-05-27 19:25:58','',0,'http://localhost:10008/?p=127',5,'nav_menu_item','',0);
INSERT INTO `wp_posts` VALUES (128,1,'2020-05-27 19:25:58','2020-05-27 19:25:58','','Sample Link','','publish','closed','closed','','sample-link-4','','','2020-05-27 19:25:58','2020-05-27 19:25:58','',0,'http://localhost:10008/?p=128',6,'nav_menu_item','',0);
INSERT INTO `wp_posts` VALUES (129,1,'2020-05-27 19:25:58','2020-05-27 19:25:58','','Sample Link','','publish','closed','closed','','sample-link-5','','','2020-05-27 19:25:58','2020-05-27 19:25:58','',0,'http://localhost:10008/?p=129',7,'nav_menu_item','',0);
INSERT INTO `wp_posts` VALUES (130,1,'2020-05-27 19:25:58','2020-05-27 19:25:58','','Sample Link','','publish','closed','closed','','sample-link-6','','','2020-05-27 19:25:58','2020-05-27 19:25:58','',0,'http://localhost:10008/?p=130',9,'nav_menu_item','',0);
INSERT INTO `wp_posts` VALUES (131,1,'2020-05-27 19:25:58','2020-05-27 19:25:58','','Sample Link','','publish','closed','closed','','sample-link-7','','','2020-05-27 19:25:58','2020-05-27 19:25:58','',0,'http://localhost:10008/?p=131',10,'nav_menu_item','',0);
INSERT INTO `wp_posts` VALUES (132,1,'2020-05-27 19:27:44','2020-05-27 19:27:44','','facebook','','publish','closed','closed','','facebook','','','2020-05-27 19:27:44','2020-05-27 19:27:44','',0,'http://localhost:10008/?p=132',1,'nav_menu_item','',0);
INSERT INTO `wp_posts` VALUES (133,1,'2020-05-27 19:27:44','2020-05-27 19:27:44','','linkedin','','publish','closed','closed','','linkedin','','','2020-05-27 19:27:44','2020-05-27 19:27:44','',0,'http://localhost:10008/?p=133',2,'nav_menu_item','',0);
INSERT INTO `wp_posts` VALUES (134,1,'2020-05-27 19:27:44','2020-05-27 19:27:44','','instagram','','publish','closed','closed','','instagram','','','2020-05-27 19:27:44','2020-05-27 19:27:44','',0,'http://localhost:10008/?p=134',3,'nav_menu_item','',0);
INSERT INTO `wp_posts` VALUES (135,1,'2020-05-27 19:27:44','2020-05-27 19:27:44','','twitter','','publish','closed','closed','','twitter','','','2020-05-27 19:27:44','2020-05-27 19:27:44','',0,'http://localhost:10008/?p=135',4,'nav_menu_item','',0);
INSERT INTO `wp_posts` VALUES (136,1,'2020-05-27 19:27:44','2020-05-27 19:27:44','','youtube','','publish','closed','closed','','youtube','','','2020-05-27 19:27:44','2020-05-27 19:27:44','',0,'http://localhost:10008/?p=136',5,'nav_menu_item','',0);
/*!40000 ALTER TABLE `wp_posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_smush_dir_images`
--

DROP TABLE IF EXISTS `wp_smush_dir_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `wp_smush_dir_images` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `path` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `path_hash` char(32) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `resize` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `lossy` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `error` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `image_size` int(10) unsigned DEFAULT NULL,
  `orig_size` int(10) unsigned DEFAULT NULL,
  `file_time` int(10) unsigned DEFAULT NULL,
  `last_scan` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `meta` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  UNIQUE KEY `id` (`id`),
  UNIQUE KEY `path_hash` (`path_hash`),
  KEY `image_size` (`image_size`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_smush_dir_images`
--

LOCK TABLES `wp_smush_dir_images` WRITE;
/*!40000 ALTER TABLE `wp_smush_dir_images` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_smush_dir_images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_term_relationships`
--

DROP TABLE IF EXISTS `wp_term_relationships`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_term_relationships`
--

LOCK TABLES `wp_term_relationships` WRITE;
/*!40000 ALTER TABLE `wp_term_relationships` DISABLE KEYS */;
INSERT INTO `wp_term_relationships` VALUES (7,1,0);
INSERT INTO `wp_term_relationships` VALUES (18,1,0);
INSERT INTO `wp_term_relationships` VALUES (30,1,0);
INSERT INTO `wp_term_relationships` VALUES (36,1,0);
INSERT INTO `wp_term_relationships` VALUES (47,1,0);
INSERT INTO `wp_term_relationships` VALUES (53,1,0);
INSERT INTO `wp_term_relationships` VALUES (63,1,0);
INSERT INTO `wp_term_relationships` VALUES (70,1,0);
INSERT INTO `wp_term_relationships` VALUES (90,1,0);
INSERT INTO `wp_term_relationships` VALUES (93,3,0);
INSERT INTO `wp_term_relationships` VALUES (95,2,0);
INSERT INTO `wp_term_relationships` VALUES (95,4,0);
INSERT INTO `wp_term_relationships` VALUES (119,5,0);
INSERT INTO `wp_term_relationships` VALUES (120,5,0);
INSERT INTO `wp_term_relationships` VALUES (121,5,0);
INSERT INTO `wp_term_relationships` VALUES (122,6,0);
INSERT INTO `wp_term_relationships` VALUES (123,6,0);
INSERT INTO `wp_term_relationships` VALUES (124,6,0);
INSERT INTO `wp_term_relationships` VALUES (125,6,0);
INSERT INTO `wp_term_relationships` VALUES (126,6,0);
INSERT INTO `wp_term_relationships` VALUES (127,6,0);
INSERT INTO `wp_term_relationships` VALUES (128,6,0);
INSERT INTO `wp_term_relationships` VALUES (129,6,0);
INSERT INTO `wp_term_relationships` VALUES (130,6,0);
INSERT INTO `wp_term_relationships` VALUES (131,6,0);
INSERT INTO `wp_term_relationships` VALUES (132,7,0);
INSERT INTO `wp_term_relationships` VALUES (133,7,0);
INSERT INTO `wp_term_relationships` VALUES (134,7,0);
INSERT INTO `wp_term_relationships` VALUES (135,7,0);
INSERT INTO `wp_term_relationships` VALUES (136,7,0);
/*!40000 ALTER TABLE `wp_term_relationships` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_term_taxonomy`
--

DROP TABLE IF EXISTS `wp_term_taxonomy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_term_taxonomy`
--

LOCK TABLES `wp_term_taxonomy` WRITE;
/*!40000 ALTER TABLE `wp_term_taxonomy` DISABLE KEYS */;
INSERT INTO `wp_term_taxonomy` VALUES (1,1,'category','',0,0);
INSERT INTO `wp_term_taxonomy` VALUES (2,2,'category','',0,1);
INSERT INTO `wp_term_taxonomy` VALUES (3,3,'category','',0,1);
INSERT INTO `wp_term_taxonomy` VALUES (4,4,'post_tag','',0,1);
INSERT INTO `wp_term_taxonomy` VALUES (5,5,'nav_menu','',0,3);
INSERT INTO `wp_term_taxonomy` VALUES (6,6,'nav_menu','',0,10);
INSERT INTO `wp_term_taxonomy` VALUES (7,7,'nav_menu','',0,5);
/*!40000 ALTER TABLE `wp_term_taxonomy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_termmeta`
--

DROP TABLE IF EXISTS `wp_termmeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_termmeta`
--

LOCK TABLES `wp_termmeta` WRITE;
/*!40000 ALTER TABLE `wp_termmeta` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_termmeta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_terms`
--

DROP TABLE IF EXISTS `wp_terms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_terms`
--

LOCK TABLES `wp_terms` WRITE;
/*!40000 ALTER TABLE `wp_terms` DISABLE KEYS */;
INSERT INTO `wp_terms` VALUES (1,'Uncategorized','uncategorized',0);
INSERT INTO `wp_terms` VALUES (2,'Category 1','category-1',0);
INSERT INTO `wp_terms` VALUES (3,'Category 2','category-2',0);
INSERT INTO `wp_terms` VALUES (4,'Tag 1','tag-1',0);
INSERT INTO `wp_terms` VALUES (5,'Primary Menu','primary-menu',0);
INSERT INTO `wp_terms` VALUES (6,'Footer Menu','footer-menu',0);
INSERT INTO `wp_terms` VALUES (7,'Social Menu','social-menu',0);
/*!40000 ALTER TABLE `wp_terms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_usermeta`
--

DROP TABLE IF EXISTS `wp_usermeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_usermeta`
--

LOCK TABLES `wp_usermeta` WRITE;
/*!40000 ALTER TABLE `wp_usermeta` DISABLE KEYS */;
INSERT INTO `wp_usermeta` VALUES (1,1,'nickname','factor1admin');
INSERT INTO `wp_usermeta` VALUES (2,1,'first_name','');
INSERT INTO `wp_usermeta` VALUES (3,1,'last_name','');
INSERT INTO `wp_usermeta` VALUES (4,1,'description','');
INSERT INTO `wp_usermeta` VALUES (5,1,'rich_editing','true');
INSERT INTO `wp_usermeta` VALUES (6,1,'syntax_highlighting','true');
INSERT INTO `wp_usermeta` VALUES (7,1,'comment_shortcuts','false');
INSERT INTO `wp_usermeta` VALUES (8,1,'admin_color','fresh');
INSERT INTO `wp_usermeta` VALUES (9,1,'use_ssl','0');
INSERT INTO `wp_usermeta` VALUES (10,1,'show_admin_bar_front','true');
INSERT INTO `wp_usermeta` VALUES (11,1,'locale','');
INSERT INTO `wp_usermeta` VALUES (12,1,'wp_capabilities','a:1:{s:13:\"administrator\";b:1;}');
INSERT INTO `wp_usermeta` VALUES (13,1,'wp_user_level','10');
INSERT INTO `wp_usermeta` VALUES (14,1,'dismissed_wp_pointers','');
INSERT INTO `wp_usermeta` VALUES (15,1,'show_welcome_panel','1');
INSERT INTO `wp_usermeta` VALUES (17,1,'wp_dashboard_quick_press_last_post_id','4');
INSERT INTO `wp_usermeta` VALUES (18,1,'community-events-location','a:1:{s:2:\"ip\";s:9:\"127.0.0.0\";}');
INSERT INTO `wp_usermeta` VALUES (20,1,'_yoast_wpseo_profile_updated','1590526926');
INSERT INTO `wp_usermeta` VALUES (21,1,'closedpostboxes_page','a:1:{i:0;s:10:\"wpseo_meta\";}');
INSERT INTO `wp_usermeta` VALUES (22,1,'metaboxhidden_page','a:3:{i:0;s:11:\"postexcerpt\";i:1;s:16:\"commentstatusdiv\";i:2;s:7:\"slugdiv\";}');
INSERT INTO `wp_usermeta` VALUES (23,1,'meta-box-order_page','a:4:{s:15:\"acf_after_title\";s:0:\"\";s:4:\"side\";s:36:\"submitdiv,pageparentdiv,postimagediv\";s:6:\"normal\";s:83:\"acf-group_5ecd9179ac374,wpseo_meta,postexcerpt,commentstatusdiv,commentsdiv,slugdiv\";s:8:\"advanced\";s:0:\"\";}');
INSERT INTO `wp_usermeta` VALUES (24,1,'screen_layout_page','2');
INSERT INTO `wp_usermeta` VALUES (25,1,'wp_user-settings','editor=tinymce&libraryContent=browse&hidetb=1&editor_plain_text_paste_warning=2&imgsize=full&advImgDetails=show');
INSERT INTO `wp_usermeta` VALUES (26,1,'wp_user-settings-time','1614883555');
INSERT INTO `wp_usermeta` VALUES (28,1,'managenav-menuscolumnshidden','a:5:{i:0;s:11:\"link-target\";i:1;s:11:\"css-classes\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";i:4;s:15:\"title-attribute\";}');
INSERT INTO `wp_usermeta` VALUES (29,1,'metaboxhidden_nav-menus','a:2:{i:0;s:12:\"add-post_tag\";i:1;s:15:\"add-post_format\";}');
INSERT INTO `wp_usermeta` VALUES (31,1,'gform_recent_forms','a:2:{i:0;s:1:\"2\";i:1;s:1:\"1\";}');
INSERT INTO `wp_usermeta` VALUES (32,1,'session_tokens','a:1:{s:64:\"7a96c85fa188a54ae7d7feebdc2e94f34d6b433b4ea8cd93f5601b2b8cc6a1d2\";a:4:{s:10:\"expiration\";i:1615056353;s:2:\"ip\";s:9:\"127.0.0.1\";s:2:\"ua\";s:121:\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.192 Safari/537.36\";s:5:\"login\";i:1614883553;}}');
/*!40000 ALTER TABLE `wp_usermeta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_users`
--

DROP TABLE IF EXISTS `wp_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_users`
--

LOCK TABLES `wp_users` WRITE;
/*!40000 ALTER TABLE `wp_users` DISABLE KEYS */;
INSERT INTO `wp_users` VALUES (1,'factor1admin','$P$BzNTue4Du93GRuxotv41lt3VTbnF85.','factor1admin','development@factor1studios.com','http://localhost:10008','2020-05-26 20:44:50','',0,'factor1admin');
/*!40000 ALTER TABLE `wp_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_yoast_indexable`
--

DROP TABLE IF EXISTS `wp_yoast_indexable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `wp_yoast_indexable` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `permalink` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `permalink_hash` varchar(40) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `object_id` bigint(20) DEFAULT NULL,
  `object_type` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `object_sub_type` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `author_id` bigint(20) DEFAULT NULL,
  `post_parent` bigint(20) DEFAULT NULL,
  `title` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `breadcrumb_title` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `is_public` tinyint(1) DEFAULT NULL,
  `is_protected` tinyint(1) DEFAULT '0',
  `has_public_posts` tinyint(1) DEFAULT NULL,
  `number_of_pages` int(11) unsigned DEFAULT NULL,
  `canonical` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `primary_focus_keyword` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `primary_focus_keyword_score` int(3) DEFAULT NULL,
  `readability_score` int(3) DEFAULT NULL,
  `is_cornerstone` tinyint(1) DEFAULT '0',
  `is_robots_noindex` tinyint(1) DEFAULT '0',
  `is_robots_nofollow` tinyint(1) DEFAULT '0',
  `is_robots_noarchive` tinyint(1) DEFAULT '0',
  `is_robots_noimageindex` tinyint(1) DEFAULT '0',
  `is_robots_nosnippet` tinyint(1) DEFAULT '0',
  `twitter_title` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `twitter_image` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `twitter_description` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `twitter_image_id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `twitter_image_source` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `open_graph_title` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `open_graph_description` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `open_graph_image` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `open_graph_image_id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `open_graph_image_source` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `open_graph_image_meta` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `link_count` int(11) DEFAULT NULL,
  `incoming_link_count` int(11) DEFAULT NULL,
  `prominent_words_version` int(11) unsigned DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `blog_id` bigint(20) NOT NULL DEFAULT '1',
  `language` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `region` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `schema_page_type` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `schema_article_type` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `has_ancestors` tinyint(1) DEFAULT '0',
  `estimated_reading_time_minutes` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `object_type_and_sub_type` (`object_type`,`object_sub_type`),
  KEY `object_id_and_type` (`object_id`,`object_type`),
  KEY `permalink_hash_and_object_type` (`permalink_hash`,`object_type`),
  KEY `subpages` (`post_parent`,`object_type`,`post_status`,`object_id`),
  KEY `prominent_words` (`prominent_words_version`,`object_type`,`object_sub_type`,`post_status`)
) ENGINE=InnoDB AUTO_INCREMENT=133 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_yoast_indexable`
--

LOCK TABLES `wp_yoast_indexable` WRITE;
/*!40000 ALTER TABLE `wp_yoast_indexable` DISABLE KEYS */;
INSERT INTO `wp_yoast_indexable` VALUES (1,'http://localhost/author/factor1admin/','37:d21a420ce87f7be7aa0a5f6fa04aece3',1,'user',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,NULL,NULL,NULL,'https://0.gravatar.com/avatar/f37bc6d8177bd155ce11a2ba7d3a64af?s=500&d=mm&r=g',NULL,NULL,'gravatar-image',NULL,NULL,'https://0.gravatar.com/avatar/f37bc6d8177bd155ce11a2ba7d3a64af?s=500&d=mm&r=g',NULL,'gravatar-image',NULL,NULL,NULL,NULL,'2020-05-26 20:47:35','2021-03-05 01:44:55',1,NULL,NULL,NULL,NULL,0,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (3,'http://localhost:10008/','22:b6ec64da6e8c7068e6c54bc97b39bc0c',2,'post','page',1,0,NULL,NULL,'Sample Page','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,90,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,NULL,'2020-05-26 20:47:35','2021-03-04 18:43:22',1,NULL,NULL,NULL,NULL,0,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (6,'http://localhost:10008/category/uncategorized/','46:b6948cc26782a00d6492b4d40d467796',1,'term','category',NULL,NULL,NULL,NULL,'Uncategorized',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,'2020-05-26 20:47:35','2021-03-05 01:52:34',1,NULL,NULL,NULL,NULL,0,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (7,NULL,NULL,NULL,'system-page','404',NULL,NULL,'Page not found %%sep%% %%sitename%%',NULL,'Error 404: Page not found',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,0,1,0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-26 20:47:35','2021-03-05 01:46:27',1,NULL,NULL,NULL,NULL,0,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (8,NULL,NULL,NULL,'system-page','search-result',NULL,NULL,'You searched for %%searchphrase%% %%page%% %%sep%% %%sitename%%',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,0,1,0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-26 20:47:35','2021-03-05 01:46:27',1,NULL,NULL,NULL,NULL,0,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (9,NULL,NULL,NULL,'date-archive',NULL,NULL,NULL,'%%date%% %%page%% %%sep%% %%sitename%%','',NULL,NULL,0,0,NULL,NULL,NULL,NULL,NULL,NULL,0,1,0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-26 20:47:35','2021-03-05 01:46:27',1,NULL,NULL,NULL,NULL,0,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (10,'http://localhost:10008/','22:b6ec64da6e8c7068e6c54bc97b39bc0c',NULL,'home-page',NULL,NULL,NULL,'%%sitename%% %%page%% %%sep%% %%sitedesc%%','','Home',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,'','','','',NULL,NULL,NULL,NULL,NULL,'2020-05-26 20:47:35','2021-03-04 18:43:22',1,NULL,NULL,NULL,NULL,0,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (11,'http://localhost:10008/?post_type=acf-field-group&p=7','52:b9220869b3c1c0aee6b91e9eeca9a253',7,'post','acf-field-group',1,0,NULL,NULL,'Flex Layouts','acf-disabled',0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,'2020-05-26 21:41:37','2021-03-04 18:43:22',1,NULL,NULL,NULL,NULL,0,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (12,'http://localhost:10008/?post_type=acf-field&p=8','46:013b2696912e59d0218ba6944efe7cb7',8,'post','acf-field',1,7,NULL,NULL,'Page Sections','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-26 21:41:37','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (13,'http://localhost:10008/?post_type=acf-field&p=9','46:d2cfb834ca4453c8cf51edacfbd20e9a',9,'post','acf-field',1,8,NULL,NULL,'Flex Block','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-26 21:41:37','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (14,'http://localhost:10008/?post_type=acf-field&p=10','47:80306a30d354b6cd797813dc35b8e739',10,'post','acf-field',1,8,NULL,NULL,'Flex Banner','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-26 21:41:37','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (15,'http://localhost:10008/?post_type=acf-field&p=11','47:17e45db95a89a490e0741caf25f1d753',11,'post','acf-field',1,8,NULL,NULL,'Flex Slider','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-26 21:41:37','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (16,'http://localhost:10008/?post_type=acf-field&p=12','47:cdf6a3de6954ffc590c69392a0e28e9f',12,'post','acf-field',1,8,NULL,NULL,'Flex Split','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-26 21:41:37','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (17,'http://localhost:10008/?post_type=acf-field&p=13','47:bd2756576c734dedde5b6ff0a4d6d54e',13,'post','acf-field',1,8,NULL,NULL,'Flex Grid','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-26 21:41:37','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (19,'http://localhost:10008/?post_type=acf-field&p=15','47:c1ea8eec1e4a1e77a0f80e0d1a52656d',15,'post','acf-field',1,8,NULL,NULL,'Flex Newsletter','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-26 21:41:37','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (22,'http://localhost:10008/?post_type=acf-field-group&p=18','53:3352ec71602d48adf7bc1df0e46013bf',18,'post','acf-field-group',1,0,NULL,NULL,'Hero (Global)','acf-disabled',0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,'2020-05-26 21:41:37','2021-03-04 18:43:22',1,NULL,NULL,NULL,NULL,0,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (23,'http://localhost:10008/?post_type=acf-field&p=19','47:310b69da7093ebd614157183f53bb8b0',19,'post','acf-field',1,18,NULL,NULL,'Background','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-26 21:41:37','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (24,'http://localhost:10008/?post_type=acf-field&p=20','47:148ef807fb3609063a380814aa1b40f9',20,'post','acf-field',1,18,NULL,NULL,'Horizontal Background Alignment','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-26 21:41:37','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (25,'http://localhost:10008/?post_type=acf-field&p=21','47:d498662c7418f49a04f340fcd693de57',21,'post','acf-field',1,18,NULL,NULL,'Vertical Background Alignment','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-26 21:41:37','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (26,'http://localhost:10008/?post_type=acf-field&p=22','47:0418f470bcd095ef85bcedc8ec193ada',22,'post','acf-field',1,18,NULL,NULL,'Column Span','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-26 21:41:37','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (27,'http://localhost:10008/?post_type=acf-field&p=23','47:e701992900a497204d4cdc1fd706266a',23,'post','acf-field',1,18,NULL,NULL,'Column Alignment','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-26 21:41:37','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (28,'http://localhost:10008/?post_type=acf-field&p=24','47:06105cc0f7c66671e86cd089f5a9ab83',24,'post','acf-field',1,18,NULL,NULL,'Video Toggle','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-26 21:41:37','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (29,'http://localhost:10008/?post_type=acf-field&p=25','47:9af8cfc4cce6d1a0a2a912afd8048e1d',25,'post','acf-field',1,18,NULL,NULL,'Video','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-26 21:41:37','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (30,'http://localhost:10008/?post_type=acf-field&p=26','47:16c2801a48d9c0eb104c0b5fa093f738',26,'post','acf-field',1,18,NULL,NULL,'Content','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-26 21:41:37','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (31,'http://localhost:10008/?post_type=acf-field&p=27','47:2e1d9b0b1e94ea4e64ae9c501b6516ec',27,'post','acf-field',1,18,NULL,NULL,'Buttons','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-26 21:41:37','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (32,'http://localhost:10008/?post_type=acf-field&p=28','47:2209f9ca61333f02b3cc92fa67acfe97',28,'post','acf-field',1,27,NULL,NULL,'Button','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-26 21:41:37','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (33,'http://localhost:10008/?post_type=acf-field&p=29','47:1597b548dd3486f0ded4795fff5f92a2',29,'post','acf-field',1,18,NULL,NULL,'Button Alignment','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-26 21:41:37','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (34,'http://localhost:10008/?post_type=acf-field-group&p=30','53:2048a159c319db7f24eaba74bea0ac40',30,'post','acf-field-group',1,0,NULL,NULL,'Centered Text Block (Global)','acf-disabled',0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,'2020-05-26 21:41:37','2021-03-04 18:43:22',1,NULL,NULL,NULL,NULL,0,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (35,'http://localhost:10008/?post_type=acf-field&p=31','47:9fbfba48cf9084532ca18ecf23f17737',31,'post','acf-field',1,30,NULL,NULL,'Column Span','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-26 21:41:37','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (36,'http://localhost:10008/?post_type=acf-field&p=32','47:d09b96fb6e38047a262816e86fc2e6f6',32,'post','acf-field',1,30,NULL,NULL,'Content','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-26 21:41:37','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (37,'http://localhost:10008/?post_type=acf-field&p=33','47:7956a575c7a2ffb68f20104520b25973',33,'post','acf-field',1,30,NULL,NULL,'Buttons','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-26 21:41:37','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (38,'http://localhost:10008/?post_type=acf-field&p=34','47:f208e20d19b7871cd0df7270fcdc184b',34,'post','acf-field',1,33,NULL,NULL,'Button','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-26 21:41:37','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (39,'http://localhost:10008/?post_type=acf-field&p=35','47:60774c067434c8ecd434da5771b3cdb4',35,'post','acf-field',1,30,NULL,NULL,'Button Alignment','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-26 21:41:37','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (40,'http://localhost:10008/?post_type=acf-field-group&p=36','53:89b41eb0453b452fd9e3fc879c067da2',36,'post','acf-field-group',1,0,NULL,NULL,'Banner (Global)','acf-disabled',0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,'2020-05-26 21:41:37','2021-03-04 18:43:22',1,NULL,NULL,NULL,NULL,0,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (41,'http://localhost:10008/?post_type=acf-field&p=37','47:079c11fed542578d87a524beac64a191',37,'post','acf-field',1,36,NULL,NULL,'Background','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-26 21:41:37','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (42,'http://localhost:10008/?post_type=acf-field&p=38','47:acd0499d2c251c8fc86393507c03bdfc',38,'post','acf-field',1,36,NULL,NULL,'Width Option','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-26 21:41:37','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (43,'http://localhost:10008/?post_type=acf-field&p=39','47:50ad2aeb0aa25cb89f7f8dc4bf4caf1e',39,'post','acf-field',1,36,NULL,NULL,'Padding','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-26 21:41:37','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (44,'http://localhost:10008/?post_type=acf-field&p=40','47:9102405a7d74e7cba86839da4d1c2386',40,'post','acf-field',1,36,NULL,NULL,'Horizontal Background Alignment','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-26 21:41:37','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (45,'http://localhost:10008/?post_type=acf-field&p=41','47:ced62ddaa4609776295ae5c9d46da39d',41,'post','acf-field',1,36,NULL,NULL,'Vertical Background Alignment','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-26 21:41:37','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (46,'http://localhost:10008/?post_type=acf-field&p=42','47:79d16c2cde10f9092d897021239cb55b',42,'post','acf-field',1,36,NULL,NULL,'Column Span','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-26 21:41:37','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (47,'http://localhost:10008/?post_type=acf-field&p=43','47:64a0c775981f7254e0e52413bdc222dd',43,'post','acf-field',1,36,NULL,NULL,'Content','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-26 21:41:37','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (48,'http://localhost:10008/?post_type=acf-field&p=44','47:38520b1679d1e8b314ea5a2ecbd3259a',44,'post','acf-field',1,36,NULL,NULL,'Button Toggle','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-26 21:41:37','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (49,'http://localhost:10008/?post_type=acf-field&p=45','47:ccc19199591cf46850640812de435f12',45,'post','acf-field',1,36,NULL,NULL,'Button Alignment','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-26 21:41:37','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (50,'http://localhost:10008/?post_type=acf-field&p=46','47:8a499b588b2453a8aba9b88905fbc044',46,'post','acf-field',1,36,NULL,NULL,'Button','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-26 21:41:37','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (51,'http://localhost:10008/?post_type=acf-field-group&p=47','53:0e2e36de60718830d9fdb5c9db8702b7',47,'post','acf-field-group',1,0,NULL,NULL,'Slider (Global)','acf-disabled',0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,'2020-05-26 21:41:37','2021-03-04 18:43:22',1,NULL,NULL,NULL,NULL,0,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (52,'http://localhost:10008/?post_type=acf-field&p=48','47:110fe85725bdc78381d5e8b77a45d198',48,'post','acf-field',1,47,NULL,NULL,'Intro Content','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-26 21:41:37','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (53,'http://localhost:10008/?post_type=acf-field&p=49','47:f9424c552aeb25f5f7117f5c5a9c3fc5',49,'post','acf-field',1,47,NULL,NULL,'Slider','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-26 21:41:37','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (54,'http://localhost:10008/?post_type=acf-field&p=50','47:347396f7a03b37e551ba9e737faf19e2',50,'post','acf-field',1,49,NULL,NULL,'Content','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-26 21:41:37','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (55,'http://localhost:10008/?post_type=acf-field&p=51','47:eb4f8499f465e01597c6db7f1d2c72ac',51,'post','acf-field',1,49,NULL,NULL,'Button Toggle','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-26 21:41:37','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (56,'http://localhost:10008/?post_type=acf-field&p=52','47:fbd2077aafbdd5e1dde8bacf4e08b21b',52,'post','acf-field',1,49,NULL,NULL,'Button','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-26 21:41:37','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (57,'http://localhost:10008/?post_type=acf-field-group&p=53','53:0c5573b20a0b3806756da9aa2beaef74',53,'post','acf-field-group',1,0,NULL,NULL,'Text/Image Split (Global)','acf-disabled',0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,'2020-05-26 21:41:37','2021-03-04 18:43:22',1,NULL,NULL,NULL,NULL,0,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (58,'http://localhost:10008/?post_type=acf-field&p=54','47:b100939dee17690f80c9510791103cb0',54,'post','acf-field',1,53,NULL,NULL,'Layout Option','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-26 21:41:37','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (59,'http://localhost:10008/?post_type=acf-field&p=55','47:6cc1e80344d472f2ada96408fa3ceacc',55,'post','acf-field',1,53,NULL,NULL,'Width Option','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-26 21:41:37','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (60,'http://localhost:10008/?post_type=acf-field&p=56','47:f49e642fd3c1c27d71d6df86c3110e11',56,'post','acf-field',1,53,NULL,NULL,'Margin Option','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-26 21:41:37','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (61,'http://localhost:10008/?post_type=acf-field&p=57','47:7fd119ba4b7a276da1ee1dbe85f40a03',57,'post','acf-field',1,53,NULL,NULL,'Background Color','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-26 21:41:37','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (62,'http://localhost:10008/?post_type=acf-field&p=58','47:2d4acb5f7570c7a6dfa1e921a82fc7c8',58,'post','acf-field',1,53,NULL,NULL,'Image','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-26 21:41:37','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (63,'http://localhost:10008/?post_type=acf-field&p=59','47:718342e6ae1a20323ff49c7b72ea3152',59,'post','acf-field',1,53,NULL,NULL,'Content','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-26 21:41:37','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (64,'http://localhost:10008/?post_type=acf-field&p=60','47:6d5d03398084ae3a981e17250d1eb0ad',60,'post','acf-field',1,53,NULL,NULL,'Button Toggle','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-26 21:41:37','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (65,'http://localhost:10008/?post_type=acf-field&p=61','47:393c78a78d83c3740d95d2aa79a2e229',61,'post','acf-field',1,53,NULL,NULL,'Button Alignment','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-26 21:41:37','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (66,'http://localhost:10008/?post_type=acf-field&p=62','47:a44bd8f938dec6539d0d4c3ee8e541b1',62,'post','acf-field',1,53,NULL,NULL,'Button','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-26 21:41:37','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (67,'http://localhost:10008/?post_type=acf-field-group&p=63','53:50a60011abdb0568cc3dedcd7dcb1f21',63,'post','acf-field-group',1,0,NULL,NULL,'3-Column Grid (Global)','acf-disabled',0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,'2020-05-26 21:41:37','2021-03-04 18:43:22',1,NULL,NULL,NULL,NULL,0,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (68,'http://localhost:10008/?post_type=acf-field&p=64','47:61c6c8243f55a754ae44e03874533054',64,'post','acf-field',1,63,NULL,NULL,'Intro Content','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-26 21:41:37','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (69,'http://localhost:10008/?post_type=acf-field&p=65','47:45042bd00a9e26b37dc96aa7047a3b12',65,'post','acf-field',1,63,NULL,NULL,'Grid','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-26 21:41:37','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (70,'http://localhost:10008/?post_type=acf-field&p=66','47:aca4480d24cf0fb60bd4e38b024b3375',66,'post','acf-field',1,65,NULL,NULL,'Image','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-26 21:41:37','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (71,'http://localhost:10008/?post_type=acf-field&p=67','47:e03a06d8dd3504e84b31eb0f48d357db',67,'post','acf-field',1,65,NULL,NULL,'Content','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-26 21:41:37','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (72,'http://localhost:10008/?post_type=acf-field&p=68','47:f92fd785617e729108de6a0e86d3867a',68,'post','acf-field',1,65,NULL,NULL,'Button Toggle','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-26 21:41:37','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (73,'http://localhost:10008/?post_type=acf-field&p=69','47:c0604ad17acb963e5408c4986ddbcadb',69,'post','acf-field',1,65,NULL,NULL,'Button','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-26 21:41:37','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (74,'http://localhost:10008/?post_type=acf-field-group&p=70','53:88222a7cc7ef7b03715896bcf1904096',70,'post','acf-field-group',1,0,NULL,NULL,'Newsletter Signup (Global)','acf-disabled',0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,'2020-05-26 21:41:37','2021-03-04 18:43:22',1,NULL,NULL,NULL,NULL,0,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (75,'http://localhost:10008/?post_type=acf-field&p=71','47:edd0828721fb4dfd90476d7bec1b0670',71,'post','acf-field',1,70,NULL,NULL,'Intro','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-26 21:41:37','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (76,'http://localhost:10008/?post_type=acf-field&p=72','47:fe8e8c6494f2cb12b82c4f2ec9bd7cdc',72,'post','acf-field',1,70,NULL,NULL,'Form','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-26 21:41:37','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (77,'http://localhost:10008/?post_type=acf-field-group&p=73','53:a6b6463fd13c5570ca667b499567c7dc',73,'post','acf-field-group',1,0,NULL,NULL,'Default Template','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-26 22:00:25','2021-03-04 18:43:22',1,NULL,NULL,NULL,NULL,0,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (78,'http://localhost:10008/?post_type=acf-field&p=74','47:bea4f33e9dbb4c21c781cf757c8a1e52',74,'post','acf-field',1,73,NULL,NULL,'Hero','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-26 22:01:39','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (79,'http://localhost:10008/?post_type=acf-field&p=75','47:9c234b6caae065c048d06b6b8ed0dc1a',75,'post','acf-field',1,73,NULL,NULL,'Default Hero','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-26 22:01:39','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (80,'http://localhost:10008/?post_type=acf-field&p=76','47:baf7c07151591a580d43b35eb8c7badd',76,'post','acf-field',1,73,NULL,NULL,'Page Sections','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-26 22:01:39','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (81,'http://localhost:10008/?post_type=acf-field&p=77','47:f6713b99a3045dd15592317a94ad74d9',77,'post','acf-field',1,73,NULL,NULL,'Default Sections','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-26 22:01:39','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (82,'http://localhost:10008/?post_type=acf-field-group&p=78','53:1a33367ee19a47fb1ee596b661c6ab76',78,'post','acf-field-group',1,0,NULL,NULL,'Site Options','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-26 22:03:36','2021-03-04 18:43:22',1,NULL,NULL,NULL,NULL,0,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (83,'http://localhost:10008/?post_type=acf-field&p=79','47:7bbc19bdc2731c468cd6aab13f9606ae',79,'post','acf-field',1,78,NULL,NULL,'Header','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-26 22:07:44','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (84,'http://localhost:10008/?post_type=acf-field&p=80','47:cf3b8f38769335672487b5530c59fffe',80,'post','acf-field',1,78,NULL,NULL,'Header Logo','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-26 22:07:44','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (85,'http://localhost:10008/?post_type=acf-field&p=81','47:5b5ff58e9985b8bff718d3eec48bd3d2',81,'post','acf-field',1,78,NULL,NULL,'Footer','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-26 22:07:44','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (86,'http://localhost:10008/?post_type=acf-field&p=82','47:a62235128e57e4af83b3ac000f6af320',82,'post','acf-field',1,78,NULL,NULL,'Footer Logo','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-26 22:07:44','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (87,'http://localhost:10008/?post_type=acf-field&p=83','47:749c3259ac589e8cf70e51cb6ab447b2',83,'post','acf-field',1,78,NULL,NULL,'404','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-26 22:07:44','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (88,'http://localhost:10008/?post_type=acf-field&p=84','47:e0736b44439038a1d97dfb66a75e6d08',84,'post','acf-field',1,78,NULL,NULL,'404 Content','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-26 22:07:44','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (89,'http://localhost:10008/styleguide/','33:56b61a1a5b165d8e0330269f7c1a44f9',85,'post','page',1,0,NULL,NULL,'Styleguide','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,'2020-05-26 22:49:27','2021-03-04 18:43:22',1,NULL,NULL,NULL,NULL,0,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (90,'http://localhost:10008/blog/','27:652a5c18bdcbccd016c7aec6f9b4cd9a',87,'post','page',1,0,NULL,NULL,'Blog','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,'2020-05-26 22:49:48','2021-03-04 18:43:22',1,NULL,NULL,NULL,NULL,0,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (91,'http://localhost:10008/category/category-1/','43:06ebc8a1779072ad32c15579feac31d7',2,'term','category',NULL,NULL,NULL,NULL,'Category 1',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,'2020-05-27 17:41:14','2021-03-05 01:52:34',1,NULL,NULL,NULL,NULL,0,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (92,'http://localhost:10008/category/category-2/','43:cd3088fca3df796a15446f6e2996aab9',3,'term','category',NULL,NULL,NULL,NULL,'Category 2',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,'2020-05-27 17:41:19','2021-03-05 01:52:34',1,NULL,NULL,NULL,NULL,0,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (93,'http://localhost:10008/?post_type=acf-field-group&p=90','53:171da18036d471ecc721c6457e04bc3c',90,'post','acf-field-group',1,0,NULL,NULL,'Blog','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,'2020-05-27 17:48:45','2021-03-04 18:43:22',1,NULL,NULL,NULL,NULL,0,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (95,'http://localhost:10008/?post_type=acf-field&p=92','47:0fe24f735f827058d00a13ad2b38d01d',92,'post','acf-field',1,90,NULL,NULL,'Intro Text','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-27 17:48:45','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (96,'http://localhost:10008/post-1/','29:c22d66f51c76169ee4cf3917d9b400ec',93,'post','post',1,0,NULL,NULL,'Post 1','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,30,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,'2020-05-27 17:51:14','2021-03-04 18:43:22',1,NULL,NULL,NULL,NULL,0,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (97,'http://localhost:10008/post-2/','29:9c9822f01a6ed2b54bfd0112a61e4c36',95,'post','post',1,0,NULL,NULL,'Post 2','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,30,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,'2020-05-27 17:51:32','2021-03-04 18:43:22',1,NULL,NULL,NULL,NULL,0,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (100,'http://localhost:10008/tag/tag-1/','33:0fb77c8f7f43879ababa8bd5c44e5d18',4,'term','post_tag',NULL,NULL,NULL,NULL,'Tag 1',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,'2020-05-27 18:09:14','2021-03-05 01:52:34',1,NULL,NULL,NULL,NULL,0,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (101,'http://localhost:10008/?post_type=acf-field&p=99','47:6241d406bdba31aa425caad78ebb4cfd',99,'post','acf-field',1,90,NULL,NULL,'Blog Page Intro','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-27 18:20:38','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (102,'http://localhost:10008/?post_type=acf-field&p=100','48:d9cea1806dea50d45e34e1e8b1e9cf96',100,'post','acf-field',1,90,NULL,NULL,'Post List','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-27 18:20:38','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (103,'http://localhost:10008/?post_type=acf-field&p=101','48:2f2e84cd755008ecbb989f5dd4a8dc24',101,'post','acf-field',1,90,NULL,NULL,'Post Meta Data','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-27 18:20:38','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (109,'http://localhost:10008/?post_type=acf-field&p=108','48:cab0667b73f21f661837bdff2d199c92',108,'post','acf-field',1,33,NULL,NULL,'Button Class','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-27 18:51:11','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (110,'http://localhost:10008/?post_type=acf-field&p=110','48:1236b4ac0a375f7b24a1245b7197e9ea',110,'post','acf-field',1,27,NULL,NULL,'Button Class','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-27 18:53:26','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (111,'http://localhost:10008/?post_type=acf-field&p=113','48:9f96dc05d8f3bcbec9a811bcbe832a1e',113,'post','acf-field',1,36,NULL,NULL,'Button Class','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-27 18:56:07','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (112,'http://localhost:10008/?post_type=acf-field&p=115','48:55ddb7d38242c825d2948f26fa51534a',115,'post','acf-field',1,49,NULL,NULL,'Button Class','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-27 19:00:38','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (113,'http://localhost:10008/?post_type=acf-field&p=116','48:88b9f56d22e4f304ea08dfe212c77a53',116,'post','acf-field',1,53,NULL,NULL,'Button Class','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-27 19:03:02','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (114,'http://localhost:10008/?post_type=acf-field&p=117','48:b30df97df43796417229f0ed04a2edfe',117,'post','acf-field',1,65,NULL,NULL,'Button Class','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-27 19:04:52','2021-03-04 18:49:06',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (115,'http://localhost:10008/119/','26:7268896daa9ac1b36b51f56a4b7e6ad1',119,'post','nav_menu_item',1,0,NULL,NULL,'','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-27 19:17:16','2021-03-04 18:43:22',1,NULL,NULL,NULL,NULL,0,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (116,'http://localhost:10008/120/','26:9c139897439da6ee2393a964257a215c',120,'post','nav_menu_item',1,0,NULL,NULL,'','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-27 19:17:17','2021-03-04 18:43:22',1,NULL,NULL,NULL,NULL,0,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (117,'http://localhost:10008/121/','26:8df660c1c21e7e67122a0c460b37bae1',121,'post','nav_menu_item',1,0,NULL,NULL,'','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-27 19:17:17','2021-03-04 18:43:22',1,NULL,NULL,NULL,NULL,0,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (118,'http://localhost:10008/122/','26:0e8e4ad77cea8d19f3461cfcaafa9e5b',122,'post','nav_menu_item',1,0,NULL,NULL,'','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-27 19:17:58','2021-03-04 18:43:22',1,NULL,NULL,NULL,NULL,0,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (119,'http://localhost:10008/123/','26:3d6533ecd19cf865edf6416adc91c5b6',123,'post','nav_menu_item',1,0,NULL,NULL,'','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-27 19:17:58','2021-03-04 18:43:22',1,NULL,NULL,NULL,NULL,0,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (120,'http://localhost:10008/124/','26:48597635fbf3bcae69de4d2aef83a32e',124,'post','nav_menu_item',1,0,NULL,NULL,'','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-27 19:17:58','2021-03-04 18:43:22',1,NULL,NULL,NULL,NULL,0,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (121,'http://localhost:10008/sample-link/','34:95c6ef442247f13d0e1c8466dcdad94b',125,'post','nav_menu_item',1,0,NULL,NULL,'Sample Link','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-27 19:25:09','2021-03-04 18:43:22',1,NULL,NULL,NULL,NULL,0,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (122,'http://localhost:10008/sample-link-2/','36:57acba11b3dbf1857a0b579609302a66',126,'post','nav_menu_item',1,0,NULL,NULL,'Sample Link','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-27 19:25:17','2021-03-04 18:43:22',1,NULL,NULL,NULL,NULL,0,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (123,'http://localhost:10008/sample-link-3/','36:ac4008376a50ad6763de0ba7437003cb',127,'post','nav_menu_item',1,0,NULL,NULL,'Sample Link','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-27 19:25:23','2021-03-04 18:43:22',1,NULL,NULL,NULL,NULL,0,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (124,'http://localhost:10008/sample-link-4/','36:bcff4f8f7c5a14c57b5a3c8542aac060',128,'post','nav_menu_item',1,0,NULL,NULL,'Sample Link','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-27 19:25:32','2021-03-04 18:43:22',1,NULL,NULL,NULL,NULL,0,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (125,'http://localhost:10008/sample-link-5/','36:8ae669831f2a89bde8c9aa638dc0cd83',129,'post','nav_menu_item',1,0,NULL,NULL,'Sample Link','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-27 19:25:38','2021-03-04 18:43:22',1,NULL,NULL,NULL,NULL,0,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (126,'http://localhost:10008/sample-link-6/','36:0d7be0d1caa942378a95047a7f3ea1d5',130,'post','nav_menu_item',1,0,NULL,NULL,'Sample Link','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-27 19:25:47','2021-03-04 18:43:22',1,NULL,NULL,NULL,NULL,0,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (127,'http://localhost:10008/sample-link-7/','36:df8e2c67166933691652ed8851d61756',131,'post','nav_menu_item',1,0,NULL,NULL,'Sample Link','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-27 19:25:54','2021-03-04 18:43:22',1,NULL,NULL,NULL,NULL,0,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (128,'http://localhost:10008/facebook/','31:c5e722098b9b49e2cc9e99d3cf571780',132,'post','nav_menu_item',1,0,NULL,NULL,'facebook','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-27 19:26:26','2021-03-04 18:43:22',1,NULL,NULL,NULL,NULL,0,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (129,'http://localhost:10008/linkedin/','31:fb7be1b805512f3bb30efa92ae800840',133,'post','nav_menu_item',1,0,NULL,NULL,'linkedin','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-27 19:26:34','2021-03-04 18:43:22',1,NULL,NULL,NULL,NULL,0,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (130,'http://localhost:10008/instagram/','32:b8f3bd89c12245ae7c83d003f0c6f68c',134,'post','nav_menu_item',1,0,NULL,NULL,'instagram','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-27 19:26:41','2021-03-04 18:43:22',1,NULL,NULL,NULL,NULL,0,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (131,'http://localhost:10008/twitter/','30:ba1eaeb035be38efc9f4b6e93ce3c44b',135,'post','nav_menu_item',1,0,NULL,NULL,'twitter','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-27 19:26:50','2021-03-04 18:43:22',1,NULL,NULL,NULL,NULL,0,NULL);
INSERT INTO `wp_yoast_indexable` VALUES (132,'http://localhost:10008/youtube/','30:0b7054df80770e8e2869f610bfb8b536',136,'post','nav_menu_item',1,0,NULL,NULL,'youtube','publish',NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-05-27 19:26:58','2021-03-04 18:43:22',1,NULL,NULL,NULL,NULL,0,NULL);
/*!40000 ALTER TABLE `wp_yoast_indexable` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_yoast_indexable_hierarchy`
--

DROP TABLE IF EXISTS `wp_yoast_indexable_hierarchy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `wp_yoast_indexable_hierarchy` (
  `indexable_id` int(11) unsigned NOT NULL,
  `ancestor_id` int(11) unsigned NOT NULL,
  `depth` int(11) unsigned DEFAULT NULL,
  `blog_id` bigint(20) NOT NULL DEFAULT '1',
  PRIMARY KEY (`indexable_id`,`ancestor_id`),
  KEY `indexable_id` (`indexable_id`),
  KEY `ancestor_id` (`ancestor_id`),
  KEY `depth` (`depth`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_yoast_indexable_hierarchy`
--

LOCK TABLES `wp_yoast_indexable_hierarchy` WRITE;
/*!40000 ALTER TABLE `wp_yoast_indexable_hierarchy` DISABLE KEYS */;
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (12,11,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (13,11,2,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (13,12,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (14,11,2,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (14,12,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (15,11,2,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (15,12,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (16,11,2,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (16,12,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (17,11,2,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (17,12,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (19,11,2,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (19,12,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (23,22,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (24,22,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (25,22,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (26,22,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (27,22,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (28,22,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (29,22,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (30,22,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (31,22,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (32,22,2,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (32,31,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (33,22,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (35,34,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (36,34,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (37,34,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (38,34,2,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (38,37,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (39,34,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (41,40,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (42,40,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (43,40,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (44,40,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (45,40,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (46,40,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (47,40,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (48,40,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (49,40,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (50,40,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (52,51,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (53,51,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (54,51,2,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (54,53,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (55,51,2,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (55,53,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (56,51,2,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (56,53,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (58,57,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (59,57,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (60,57,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (61,57,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (62,57,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (63,57,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (64,57,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (65,57,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (66,57,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (68,67,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (69,67,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (70,67,2,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (70,69,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (71,67,2,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (71,69,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (72,67,2,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (72,69,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (73,67,2,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (73,69,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (75,74,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (76,74,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (78,77,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (79,77,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (80,77,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (81,77,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (83,82,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (84,82,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (85,82,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (86,82,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (87,82,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (88,82,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (95,93,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (101,93,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (102,93,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (103,93,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (109,34,2,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (109,37,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (110,22,2,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (110,31,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (111,40,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (112,51,2,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (112,53,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (113,57,1,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (114,67,2,1);
INSERT INTO `wp_yoast_indexable_hierarchy` VALUES (114,69,1,1);
/*!40000 ALTER TABLE `wp_yoast_indexable_hierarchy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_yoast_migrations`
--

DROP TABLE IF EXISTS `wp_yoast_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `wp_yoast_migrations` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `version` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_wp_yoast_migrations_version` (`version`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_yoast_migrations`
--

LOCK TABLES `wp_yoast_migrations` WRITE;
/*!40000 ALTER TABLE `wp_yoast_migrations` DISABLE KEYS */;
INSERT INTO `wp_yoast_migrations` VALUES (1,'20171228151840');
INSERT INTO `wp_yoast_migrations` VALUES (2,'20171228151841');
INSERT INTO `wp_yoast_migrations` VALUES (3,'20190529075038');
INSERT INTO `wp_yoast_migrations` VALUES (4,'20191011111109');
INSERT INTO `wp_yoast_migrations` VALUES (5,'20200408101900');
INSERT INTO `wp_yoast_migrations` VALUES (6,'20200420073606');
INSERT INTO `wp_yoast_migrations` VALUES (7,'20200428123747');
INSERT INTO `wp_yoast_migrations` VALUES (8,'20200428194858');
INSERT INTO `wp_yoast_migrations` VALUES (9,'20200429105310');
INSERT INTO `wp_yoast_migrations` VALUES (10,'20200430075614');
INSERT INTO `wp_yoast_migrations` VALUES (11,'20200430150130');
INSERT INTO `wp_yoast_migrations` VALUES (12,'20200507054848');
INSERT INTO `wp_yoast_migrations` VALUES (13,'20200513133401');
INSERT INTO `wp_yoast_migrations` VALUES (14,'20200609154515');
INSERT INTO `wp_yoast_migrations` VALUES (15,'20200616130143');
INSERT INTO `wp_yoast_migrations` VALUES (16,'20200617122511');
INSERT INTO `wp_yoast_migrations` VALUES (17,'20200702141921');
INSERT INTO `wp_yoast_migrations` VALUES (18,'20200728095334');
INSERT INTO `wp_yoast_migrations` VALUES (19,'20201202144329');
INSERT INTO `wp_yoast_migrations` VALUES (20,'20201216124002');
INSERT INTO `wp_yoast_migrations` VALUES (21,'20201216141134');
/*!40000 ALTER TABLE `wp_yoast_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_yoast_primary_term`
--

DROP TABLE IF EXISTS `wp_yoast_primary_term`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `wp_yoast_primary_term` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) DEFAULT NULL,
  `term_id` bigint(20) DEFAULT NULL,
  `taxonomy` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `blog_id` bigint(20) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `post_taxonomy` (`post_id`,`taxonomy`),
  KEY `post_term` (`post_id`,`term_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_yoast_primary_term`
--

LOCK TABLES `wp_yoast_primary_term` WRITE;
/*!40000 ALTER TABLE `wp_yoast_primary_term` DISABLE KEYS */;
INSERT INTO `wp_yoast_primary_term` VALUES (1,93,3,'category','2020-05-27 17:51:29','2020-05-27 17:51:29',1);
INSERT INTO `wp_yoast_primary_term` VALUES (2,95,2,'category','2020-05-27 17:51:47','2020-05-27 18:09:14',1);
/*!40000 ALTER TABLE `wp_yoast_primary_term` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_yoast_seo_links`
--

DROP TABLE IF EXISTS `wp_yoast_seo_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `wp_yoast_seo_links` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_id` bigint(20) unsigned NOT NULL,
  `target_post_id` bigint(20) unsigned NOT NULL,
  `type` varchar(8) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `indexable_id` int(11) unsigned DEFAULT NULL,
  `target_indexable_id` int(11) unsigned DEFAULT NULL,
  `height` int(11) unsigned DEFAULT NULL,
  `width` int(11) unsigned DEFAULT NULL,
  `size` int(11) unsigned DEFAULT NULL,
  `language` varchar(32) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `region` varchar(32) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `link_direction` (`post_id`,`type`),
  KEY `indexable_link_direction` (`indexable_id`,`type`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_yoast_seo_links`
--

LOCK TABLES `wp_yoast_seo_links` WRITE;
/*!40000 ALTER TABLE `wp_yoast_seo_links` DISABLE KEYS */;
INSERT INTO `wp_yoast_seo_links` VALUES (6,'http://localhost:10008/wp-admin/',2,0,'internal',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `wp_yoast_seo_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_yoast_seo_meta`
--

DROP TABLE IF EXISTS `wp_yoast_seo_meta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `wp_yoast_seo_meta` (
  `object_id` bigint(20) unsigned NOT NULL,
  `internal_link_count` int(10) unsigned DEFAULT NULL,
  `incoming_link_count` int(10) unsigned DEFAULT NULL,
  UNIQUE KEY `object_id` (`object_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_yoast_seo_meta`
--

LOCK TABLES `wp_yoast_seo_meta` WRITE;
/*!40000 ALTER TABLE `wp_yoast_seo_meta` DISABLE KEYS */;
INSERT INTO `wp_yoast_seo_meta` VALUES (1,0,0);
INSERT INTO `wp_yoast_seo_meta` VALUES (2,1,0);
INSERT INTO `wp_yoast_seo_meta` VALUES (3,0,0);
INSERT INTO `wp_yoast_seo_meta` VALUES (4,0,0);
INSERT INTO `wp_yoast_seo_meta` VALUES (5,0,0);
INSERT INTO `wp_yoast_seo_meta` VALUES (6,0,0);
INSERT INTO `wp_yoast_seo_meta` VALUES (7,0,0);
INSERT INTO `wp_yoast_seo_meta` VALUES (14,0,0);
INSERT INTO `wp_yoast_seo_meta` VALUES (16,0,0);
INSERT INTO `wp_yoast_seo_meta` VALUES (17,0,0);
INSERT INTO `wp_yoast_seo_meta` VALUES (18,0,0);
INSERT INTO `wp_yoast_seo_meta` VALUES (30,0,0);
INSERT INTO `wp_yoast_seo_meta` VALUES (36,0,0);
INSERT INTO `wp_yoast_seo_meta` VALUES (47,0,0);
INSERT INTO `wp_yoast_seo_meta` VALUES (53,0,0);
INSERT INTO `wp_yoast_seo_meta` VALUES (63,0,0);
INSERT INTO `wp_yoast_seo_meta` VALUES (70,0,0);
INSERT INTO `wp_yoast_seo_meta` VALUES (85,0,0);
INSERT INTO `wp_yoast_seo_meta` VALUES (87,0,0);
INSERT INTO `wp_yoast_seo_meta` VALUES (90,0,0);
INSERT INTO `wp_yoast_seo_meta` VALUES (91,0,0);
INSERT INTO `wp_yoast_seo_meta` VALUES (93,0,0);
INSERT INTO `wp_yoast_seo_meta` VALUES (95,0,0);
INSERT INTO `wp_yoast_seo_meta` VALUES (97,0,0);
INSERT INTO `wp_yoast_seo_meta` VALUES (98,0,0);
INSERT INTO `wp_yoast_seo_meta` VALUES (103,0,0);
INSERT INTO `wp_yoast_seo_meta` VALUES (104,0,0);
INSERT INTO `wp_yoast_seo_meta` VALUES (105,0,0);
INSERT INTO `wp_yoast_seo_meta` VALUES (106,0,0);
INSERT INTO `wp_yoast_seo_meta` VALUES (107,0,0);
/*!40000 ALTER TABLE `wp_yoast_seo_meta` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-03-04 11:54:31
