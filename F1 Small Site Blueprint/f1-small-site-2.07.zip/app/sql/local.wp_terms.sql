/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `wp_terms` VALUES
(1,"Uncategorized","uncategorized",0),
(2,"Category 1","category-1",0),
(3,"Category 2","category-2",0),
(4,"Tag 1","tag-1",0),
(5,"Primary Menu","primary-menu",0),
(6,"Footer Menu","footer-menu",0),
(7,"Social Menu","social-menu",0);
