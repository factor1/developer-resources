<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'local' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', 'root' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'g/f/F0BSO0BG+vTCZbWjV6OIpzObeEW+yPJfyYLx/a4PNmU1bm/iceJNfxzQEsatVVcTkialM2OB7FG53KtC5g==');
define('SECURE_AUTH_KEY',  'fA53kT5AZFarZZY9qxMLP2oWkwgAnxnI961o5uUmM34hlCrKlbc/DPhpkPca1z9wALbx9Gbse3wwjWV0uQzcPg==');
define('LOGGED_IN_KEY',    'RkAlTfZM4x0rGkbnWQqMbzzsGrsS8W1IK3Gzo8vE6yC7vfEcXRB8CRAUOk5jDLUVokYoag2x/oYmNZxtUWe/Bw==');
define('NONCE_KEY',        'yn0fBKRRmgBrZMVfcTBcODsuw983YOKNhy9JPmcGkBLh8JqYUTEzjF4voS31ejaioW35+1ynNnawE3c9B6tSGg==');
define('AUTH_SALT',        'kN1GwWVHexq902/6GyenzSIgvPJuAM7g7NR1esTn92U56cxAb7QOyGTRsvFdGIV3xMbbAoIcov5xWNp0vRk5Jw==');
define('SECURE_AUTH_SALT', 'edFKbuG4pe6+5AS15G0JMHxl55QV3QMvJHcarIj/iSxfBZX1rz4FzF1yncPkQiQnUCkcmXW2SNLHEWAYVlX41Q==');
define('LOGGED_IN_SALT',   'aAeqzkzXGjkadKuabjPwTJIZe77x/vl+bcim0GjKoXXGekvqN6P2Y1kUdYBL3kf6WlB1DA4qr8JHyBeqgfo40g==');
define('NONCE_SALT',       'kQtILZzU6JQFbIYQJ1Pv9rFGTt2bbYraf0VL8KH8nCv9PvIswfNqVKklQ8OVDzpbEPIQRdTrKSyjgQjXZ0l7oA==');

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';




define( 'WP_ENVIRONMENT_TYPE', 'local' );
/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) )
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
