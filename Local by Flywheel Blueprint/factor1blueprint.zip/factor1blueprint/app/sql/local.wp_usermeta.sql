/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `wp_usermeta` VALUES
(1,1,"nickname","factor1admin"),
(2,1,"first_name",""),
(3,1,"last_name",""),
(4,1,"description",""),
(5,1,"rich_editing","true"),
(6,1,"syntax_highlighting","true"),
(7,1,"comment_shortcuts","false"),
(8,1,"admin_color","fresh"),
(9,1,"use_ssl","0"),
(10,1,"show_admin_bar_front","true"),
(11,1,"locale",""),
(12,1,"wp_capabilities","a:1:{s:13:\"administrator\";b:1;}"),
(13,1,"wp_user_level","10"),
(14,1,"dismissed_wp_pointers",""),
(15,1,"show_welcome_panel","1"),
(16,1,"session_tokens","a:1:{s:64:\"0a0c0908516b2e3a67b7089e16d686807f391e048b81795dfaf98aac53b4f88a\";a:4:{s:10:\"expiration\";i:1523571473;s:2:\"ip\";s:9:\"127.0.0.1\";s:2:\"ua\";s:121:\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36\";s:5:\"login\";i:1523398673;}}"),
(17,1,"wp_dashboard_quick_press_last_post_id","3"),
(18,1,"community-events-location","a:1:{s:2:\"ip\";s:12:\"192.168.75.0\";}"),
(19,1,"wp_yoast_notifications","a:3:{i:0;a:2:{s:7:\"message\";s:172:\"Don\'t miss your crawl errors: <a href=\"http://factor1blueprint.local/wp-admin/admin.php?page=wpseo_search_console&tab=settings\">connect with Google Search Console here</a>.\";s:7:\"options\";a:8:{s:4:\"type\";s:7:\"warning\";s:2:\"id\";s:17:\"wpseo-dismiss-gsc\";s:5:\"nonce\";N;s:8:\"priority\";d:0.5;s:9:\"data_json\";a:0:{}s:13:\"dismissal_key\";N;s:12:\"capabilities\";s:20:\"wpseo_manage_options\";s:16:\"capability_check\";s:3:\"all\";}}i:1;a:2:{s:7:\"message\";s:285:\"You still have the default WordPress tagline, even an empty one is probably better. <a href=\"http://factor1blueprint.local/wp-admin/customize.php?url=http%3A%2F%2Ffactor1blueprint.local%2Fwp-admin%2Foptions-reading.php%3Fsettings-updated%3Dtrue\">You can fix this in the customizer</a>.\";s:7:\"options\";a:8:{s:4:\"type\";s:5:\"error\";s:2:\"id\";s:28:\"wpseo-dismiss-tagline-notice\";s:5:\"nonce\";N;s:8:\"priority\";d:0.5;s:9:\"data_json\";a:0:{}s:13:\"dismissal_key\";N;s:12:\"capabilities\";s:20:\"wpseo_manage_options\";s:16:\"capability_check\";s:3:\"all\";}}i:2;a:2:{s:7:\"message\";s:226:\"<strong>Huge SEO Issue: You\'re blocking access to robots.</strong> You must <a href=\"http://factor1blueprint.local/wp-admin/options-reading.php\">go to your Reading Settings</a> and uncheck the box for Search Engine Visibility.\";s:7:\"options\";a:8:{s:4:\"type\";s:5:\"error\";s:2:\"id\";s:32:\"wpseo-dismiss-blog-public-notice\";s:5:\"nonce\";N;s:8:\"priority\";i:1;s:9:\"data_json\";a:0:{}s:13:\"dismissal_key\";N;s:12:\"capabilities\";s:20:\"wpseo_manage_options\";s:16:\"capability_check\";s:3:\"all\";}}}");
