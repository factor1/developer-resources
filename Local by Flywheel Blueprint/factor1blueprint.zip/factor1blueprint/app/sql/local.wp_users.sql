/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `wp_users` VALUES
(1,"factor1admin","$P$BoEy7zdu30HzSWF/NYMY4qfTepH8We0","factor1admin","development@factor1studios.com","","2018-04-10 22:17:35","",0,"factor1admin");
