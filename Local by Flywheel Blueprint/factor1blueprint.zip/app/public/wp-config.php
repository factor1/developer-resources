<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'local' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', 'root' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'GxgaS6w8GL1ClaL9pMYC5ciQ5LmMmG4etB7Z2YN3r96jHX0Q39ftoU+FH4kcag3q2H58UmOrM8EG+foDBkUIuQ==');
define('SECURE_AUTH_KEY',  'ACkKFPhca+AFrjresbHoOOcp6m56UjqhbuKf8JhAbMUY2AFcHiYVeyfLL+yABEqgg8kLFL2PyEYsr/mHp3CpVg==');
define('LOGGED_IN_KEY',    '+khXNx6ljam83V90UPa0avoQuAEz8bi+JqIbAVI5h9XA95KgvhCOz31vzp6pd6GVd72BQV/pMY1heE38owEM7Q==');
define('NONCE_KEY',        'nE0LwNmj3eE7rxlw237CWAaQlIdh3DqmgSfn6BIlFW9vBGKsabFw4ctci8Q3HuHKl630C968o+xbwCLE+V1/Yg==');
define('AUTH_SALT',        'nI1ibPS0sRBv2X6NJ9qT5Gr4t2zfUzfB0blDdL3iie3YvQG/bl2e8G2KFi86BLf9rh3Oiw6VlPkwbHGe6P83Bg==');
define('SECURE_AUTH_SALT', 'rLgjK0m6FmYqQcXmvxYWBo6kS1OjxEfORB3QG/d/uQ4umT8dk9uXUOOgMY+cFOY0kC7fP2HuKZ1AQGIK3oOimQ==');
define('LOGGED_IN_SALT',   'TyrWNvegKH8srzTJ7NgIeTjb6Jp1mgIWRAfi7pnlmkyxUppYj15ujBZhM5bYXzMsS7JxRLiltjyBKCLleIBuRw==');
define('NONCE_SALT',       'LKcCwPmMnGJvu7q/jve1GUTKxBhpdf+jQMwC8tWYtCfLtuO6qEc0vK7decBSzxfAkSuScUFyOJxJw+ux9mo6KA==');

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';





/* Inserted by Local by Flywheel. See: http://codex.wordpress.org/Administration_Over_SSL#Using_a_Reverse_Proxy */
if ( isset( $_SERVER['HTTP_X_FORWARDED_PROTO'] ) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https' ) {
	$_SERVER['HTTPS'] = 'on';
}

/* Inserted by Local by Flywheel. Fixes $is_nginx global for rewrites. */
if ( ! empty( $_SERVER['SERVER_SOFTWARE'] ) && strpos( $_SERVER['SERVER_SOFTWARE'], 'Flywheel/' ) !== false ) {
	$_SERVER['SERVER_SOFTWARE'] = 'nginx/1.10.1';
}
/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) )
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
