<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'local' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', 'root' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '6493h8u+OIvZ5/8a5AtAyPGueNx10VO31T8UH5JXDPP/pewDdjSTgzq1hsfK0V6p/g4I5nbgj8BP1Y1a1HFXnw==');
define('SECURE_AUTH_KEY',  'K3J16xO39J3VpdL9RyCa3HRSU82TBj2cvFS7puKg40u2qGX6iDs3uwQfTLAfIft1ax/zhko620bJAt1okKDA0A==');
define('LOGGED_IN_KEY',    'aZhCb+OQ6eMVKaezra4BingXd2tJaf50BZUmN2Suslko6MJ14q1+3uKfNcaFJDnZcAUdMi/oj/d9K1+W+lcOgQ==');
define('NONCE_KEY',        '864ewVzpAxUG5Cwdz6BynsC+N3ywpS35gxQ8RBCvTbZS5DlezGYozjA7NhDTCFiYFJIitCAkuUHWMLNMAnljjg==');
define('AUTH_SALT',        'VceRLi9YYhIafQjQ0WJ3FbeQ58g38d1vjCpG317ggml4qShwdC3Y0xOLR5U3VAi5HfHXI5jbtmZLkkYYUpK4Fw==');
define('SECURE_AUTH_SALT', 'XjmJu6ovxv8yec2/CUll3wLX0PwPiiibzfMaElxUcnF3kwTiPSU1Alp0pPzEhj2rBkTLaQhQtgCIc8k00wDMcg==');
define('LOGGED_IN_SALT',   'Mm6uC8qfjCBzOTnqHSwCa1nN31fy1I+3/ttn0bZdVI0jBtb9S4k4kabkyMp0G+4lTQ1V4gyYentry9QxEmn3aA==');
define('NONCE_SALT',       'r8gFNNIW6fDP0GC6MaRT0jWkIWDKnh/TxCFmy/CX9Y+fFKKVSQsCwFM5y34fQRDCizXBBPcGwpmoDwSUeV4gOA==');

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';




/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) )
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
