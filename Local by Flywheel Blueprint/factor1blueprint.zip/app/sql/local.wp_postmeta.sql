/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `wp_postmeta` VALUES
(1,2,"_wp_page_template","default"),
(2,3,"_wp_page_template","default"),
(3,1,"_wp_trash_meta_status","publish"),
(4,1,"_wp_trash_meta_time","1575482858"),
(5,1,"_wp_desired_post_slug","hello-world"),
(6,1,"_wp_trash_meta_comments_status","a:1:{i:1;s:1:\"1\";}"),
(7,2,"_wp_trash_meta_status","publish"),
(8,2,"_wp_trash_meta_time","1575482864"),
(9,2,"_wp_desired_post_slug","sample-page"),
(10,3,"_wp_trash_meta_status","draft"),
(11,3,"_wp_trash_meta_time","1575482866"),
(12,3,"_wp_desired_post_slug","privacy-policy");
