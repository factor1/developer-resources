/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `wp_users` VALUES
(1,"factor1admin","$P$BaoQ8vTkLPnxDMtWqgWkvAnGS6JBeV1","factor1admin","development@factor1studios.com","","2019-12-04 17:58:03","",0,"factor1admin");
